from pathlib import Path
import json,subprocess,shlex,os
r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release';p=Path('/tmp/forgecad-loft-projected-fix')
c=next(x for x in json.loads((b/'compile_commands.json').read_text()) if x['file'].endswith('/tests/test_viewport.cpp'));a=shlex.split(c['command']);a[a.index('-o')+1]=str(p/'replay.o');a[-1]=str(p/'replay.cpp');a=['-O0' if x=='-O3' else x for x in a];print('COMMAND '+shlex.join(a),flush=True);subprocess.run(a,cwd=b,check=True)
a=shlex.split((b/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(p/'replay')
for i,x in enumerate(a):
 if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(p/'replay.o')
 elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(p/'replay.d')
i=a.index('kernel/libforgekernel.a');a[i:i]=[str(p/'fk_loft.o'),str(p/'fk_sketch_projection.o')];print('COMMAND '+shlex.join(a),flush=True);subprocess.run(a,cwd=b,check=True)
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QT_QPA_PLATFORMTHEME='',QT_STYLE_OVERRIDE='Fusion');cmd=[str(p/'replay'),str(p/'fixture/SurfaceModellingExample219.prt')];print('ENV QT_QPA_PLATFORM=offscreen QT_QPA_PLATFORMTHEME= QT_STYLE_OVERRIDE=Fusion\nCOMMAND '+shlex.join(cmd),flush=True);result=subprocess.run(cmd,env=env);print('EXITCODE '+str(result.returncode),flush=True);raise SystemExit(result.returncode)
