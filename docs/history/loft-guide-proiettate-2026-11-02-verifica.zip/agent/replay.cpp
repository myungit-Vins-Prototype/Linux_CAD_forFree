#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "fk_sketch_projection.h"
#include "fk_curve_algo.h"
#include "fk_surface_algo.h"
#include "fk_body_check.h"
#include "fk_body_io.h"
#include <iostream>
#include <stdexcept>
#include "definition.h"
static void require(bool value,const char *message){if(!value)throw std::runtime_error(message);}
int main(int argc,char **argv){QApplication app(argc,argv);using namespace ForgeCad;using namespace Kernel;try{
    DocumentState doc;require(loadDocumentFile(QString::fromLocal8Bit(argv[1]),doc).isEmpty(),"lettura fixture");CadViewport view;view.loadDocument(doc);doc=view.currentDocument();auto loft=makeLoftDefinition(doc);
    const auto originalGuide=doc.extrusions[7].curve;require(originalGuide && isImplicitSketchProjection(*originalGuide),"guida sorgente implicita esatta");
    std::vector<Vec3> before;const auto range=originalGuide->domain();for(int i=0;i<=40;++i)before.push_back(originalGuide->point(range.lo+range.length()*i/40));
    buildGeometry(loft,doc.extrusions.size(),doc.sketches,doc.extrusions);require(loft.forgeBody && loft.error.isEmpty(),qPrintable(loft.error));const auto &shape=*loft.forgeBody;
    require(shape.isSheet() && checkBody(shape).empty(),"B-rep del loft reale valida");double sectionError=0,guideError=0;
    for(const auto &ref:loft.loftSections){std::vector<PathSegment> path;QString error;require(geometryRefPath(ref,doc.extrusions.size(),doc.sketches,doc.extrusions,path,&error),"sezione reale risolta");
        for(const auto &part:path)for(int i=0;i<=20;++i){const auto p=part.curve->point(part.range.lo+part.range.length()*i/20);double nearest=1e100;for(FaceId face:shape.faces())nearest=std::min(nearest,projectPoint(*shape.face(face).surface,p).distance);sectionError=std::max(sectionError,nearest);}}
    for(const auto &ref:loft.loftEdgeGuides){std::vector<PathSegment> path;QString error;require(geometryRefPath(ref,doc.extrusions.size(),doc.sketches,doc.extrusions,path,&error),"guida reale risolta");
        for(const auto &part:path)for(int i=0;i<=80;++i){const auto p=part.curve->point(part.range.lo+part.range.length()*i/80);double nearest=1e100;for(EdgeId edge:shape.edges())nearest=std::min(nearest,projectPoint(*shape.edge(edge).curve,p,shape.edge(edge).range).distance);guideError=std::max(guideError,nearest);}}
    require(sectionError<1e-9,"fedelta' sezioni reali");require(guideError<4e-9,"fedelta' guide reali entro budget loft");
    require(doc.extrusions[7].curve==originalGuide && isImplicitSketchProjection(*doc.extrusions[7].curve),"nessuna sostituzione della sorgente implicita");
    for(int i=0;i<=40;++i)require(distance(before[i],originalGuide->point(range.lo+range.length()*i/40))==0,"sorgente immutata punto per punto");
    auto serialized=readBodyBinary(writeBodyBinary(shape));require(checkBody(serialized).empty()&&serialized.faces().size()==shape.faces().size(),"BodyIO normale superficie NURBS");
    std::cout.precision(17);std::cout<<"PASS CAD reale: faces="<<shape.faces().size()<<" edges="<<shape.edges().size()<<" maxSectionError="<<sectionError<<" maxGuideError="<<guideError<<" exactSourceUnchanged=1 BodyIO=PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
