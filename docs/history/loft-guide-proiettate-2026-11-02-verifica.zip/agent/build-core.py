from pathlib import Path
import json,subprocess,shlex
r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release';p=Path('/tmp/forgecad-loft-projected-fix');commands=json.loads((b/'compile_commands.json').read_text())
for name in ['fk_sketch_projection','fk_loft']:
 c=next(x for x in commands if x['file']==str(r/'kernel'/(name+'.cpp')));a=shlex.split(c['command']);a[a.index('-o')+1]=str(p/(name+'.o'));a[-1]=str(p/'kernel'/(name+'.cpp'));a[1:1]=['-I'+str(r/'kernel')];print(shlex.join(a),flush=True);subprocess.run(a,cwd=b,check=True)
a=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-I'+str(r/'kernel'),str(p/'kernel/tests/test_loft_projected_guides.cpp'),str(p/'fk_loft.o'),str(p/'fk_sketch_projection.o'),str(b/'kernel/libforgekernel.a'),'-pthread','-o',str(p/'kernel-tests')];print(shlex.join(a),flush=True);subprocess.run(a,check=True);result=subprocess.run([str(p/'kernel-tests')]);print('EXITCODE '+str(result.returncode));raise SystemExit(result.returncode)
