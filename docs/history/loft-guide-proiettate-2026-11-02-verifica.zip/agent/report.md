# Loft con guida proiettata implicita — pacchetto congelato

Base `f75015b`. Originale individuato in `/home/myungit/Documenti/Cad_Example/SurfaceModellingExample219.prt`; copia congelata `fixture/SurfaceModellingExample219.prt`, 26918 byte, SHA256 `c0f55b07e446682fe4dcf0f6f982a80bc8ff6b87fabded0dc57c3196ea930b7b`. Nessuna modifica all'originale, ai suoi lock o ai processi utente. Screenshot esaminato. Sorgenti preparati soltanto in `/tmp/forgecad-loft-projected-fix`; integrazione/build app/memoria/mappa sono gestite da root.

## Causa riprodotta

Il loft richiesto ha owner8, sezioni curva3 dello Schizzo8 (sketch index7/storyId8/curve index2) e Curva estratta3D1 (body4/featureId5); guide Curva estratta3D3 (body5/featureId7) e Curva estratta3D5 (body7/featureId9), entrambe G1/influenza1. `definition.h` ricostruisce esattamente questa definizione da una copia del documento.

La seconda guida è una TrimmedCurve della curva proiettata implicita esatta. Le due sezioni, benché riferite come curve3D, sono piane: la prima ha tutti i poli a Z=15, la seconda a X=-80. Il percorso spatial del loft tentava una proiezione2D generica della guida, rifiutata da `planarImage`: errore riprodotto sia dalla sonda geometrica sia dal pannello nativo preparato da root.

## Correzioni

`kernel/fk_loft.cpp`: riconosce la guida implicita e certifica il supporto piano della sezione dai poli delle curve razionali esatte. Il piano è definito da poli, non da campioni né least-squares; tutti gli altri poli devono rispettarlo entro il solo arrotondamento double. Interseca la guida sorgente esatta con questo piano tramite `planeRoots<3>`, poi verifica in3D che il punto appartenga alla curva di sezione. Una sezione rettilinea è definita tramite due piani indipendenti: se la guida è complanare al primo viene intersecato il secondo, senza perdere gli attraversamenti. Sovrapposizioni e attraversamenti multipli restano rifiutati.

La tolleranza di certificazione è `128*epsilon*max(1,norm(origin),length)`. Se questo limite aritmetico supera `min(tolleranzaLocale,kLinearResolution)`, la sezione non viene certificata: una traslazione estrema non amplia il budget. La curva sorgente e il suo tipo implicito vengono conservati. Sono presenti punti di cancellazione nei nuovi cicli.

`kernel/fk_sketch_projection.cpp`: la regressione ruotata e traslata ha individuato un secondo difetto. Una normale piano quasi parallela alla normale di estrusione produceva divisioni per pochi ulp e poteva perdere una radice intermedia. Il nuovo percorso riserva dal budget già passato il contributo massimo della direzione quasi parallela, `abs(dot)*2*sqrt(3)*kSizeBox`; usa la riduzione alle radici della sorgente razionale soltanto se quel contributo occupa al massimo metà del budget, e riduce della stessa quantità il budget della ricerca delle radici. Il limite segue dai size-box già certificati per sorgente e curva risultante. I punti isolati vengono inoltre verificati con il residuo originale. Nessuna tolleranza è stata aumentata.

## Significato geometrico e persistenza

La guida proiettata rimane una curva implicita esatta: non viene convertita in polilinea, mesh o spline approssimata. Gli attraversamenti usano la sua geometria e le sue derivate. La superficie del loft rimane una normale NURBS costruita dal procedimento adattivo preesistente (`followingGuide`, quintiche Hermite, tolleranza1e-9 mm e verifiche di scarto fino a4e-9 mm). Questo è il budget dell'operatore loft, non un'affermazione di coincidenza algebrica globale fra bordo NURBS e curva implicita. Non è stato introdotto un nuovo fit della sorgente, né modificato quel procedimento o i suoi budget.

Nessun nuovo tipo di superficie/curva persistita, enum, header di produzione o formato. Formato nativo60 e BodyIO invariati. Il risultato B-rep conserva superfici NURBS salvabili e ricostruibili con il codec esistente.

## Verifiche effettive

`regressions.log`, con comandi ed exitcode:

- Test nuovo sul kernel precedente: FAIL `planarImage: tipo di curva non gestito`, exit1 al primo caso.
- Solo fix loft, con kernel radici precedente: FAIL per intersezione intermedia nel caso ruotato/traslato, exit1.
- Entrambi i fix: PASS10 gruppi, exit0: due e tre sezioni; rotazione e traslazione; guida orientata contro l'ordine delle sezioni; sezioni rank1; primo piano rank1 coincidente e secondo valido; guida senza incrocio; doppio attraversamento ambiguo; sezione realmente non piana; nonplanarità traslata lontano dall'origine. Controlli di integrità B-rep, fedeltà sezioni/guide e roundtrip BodyIO compresi.
- Regressione proiezione preesistente: PASS21 gruppi, exit0.
- Regressione riferimenti proiettati preesistente: PASS39 casi, exit0.

`replay.log`, verifica indipendente sulla copia CAD reale: PASS1faccia/4bordi; errore massimo misurato sulle sezioni `3.1826049115524521e-14` mm; sulle guide `5.102340613235048e-10` mm; curva sorgente ancora implicita e invariata punto-per-punto; roundtrip BodyIO PASS. I campioni servono a verifica, non a definire la geometria.

Root ha eseguito anche la QA sul pannello nativo con oggetti staged: preview, conferma, Undo/Redo, riapertura con/senza cache e rigenerazione PASS offscreen e Wayland/GL. I log sono nel suo spazio `/tmp/forgecad-loft-projected-qa`; root ripeterà le verifiche dopo integrazione nella build di produzione. Questi esiti sono riportati come verifiche di root, senza attribuire a questa sonda l'aggiornamento dell'app.

## Integrazione

`manifest.json`: hash prima/dopo dei due TU e del nuovo test. `loft-projected.patch`: patch dei soli file di produzione. `integration.txt`: target CTest indipendente e descrizioni architetturali da aggiornare. Nessuna nuova TU di produzione; nessun header/ABI cambia.

Script riproducibili: `build-inspect.py`, `build-core.py`, `build-replay.py`, `run-regressions.py`, `run-sanitizer.py`. La sonda GUI di root usa `definition.h`. Non eseguire dopo l'integrazione il confronto baseline contro la libreria ormai aggiornata pretendendo un fallimento: gli esiti prima/dopo sono congelati in `regressions.log` e negli eseguibili isolati baseline/loft-only.

## Limiti

Le sezioni spatial realmente non planari non sono abilitate per guide implicite da questo cambiamento: vengono rifiutate esplicitamente come non certificabili. Le guide complanari con una sezione curva restano rifiutate con messaggio `giace nel piano`, coerentemente col precedente percorso planare. Una guida interamente sovrapposta a una sezione rettilinea è ambigua. Se l'incertezza double legata alle coordinate globali supera il budget, non si dichiara la planarità. Non si pretende una prova globale di assenza di auto-intersezioni o una rappresentazione NURBS algebricamente esatta di qualunque guida implicita.

## Sanitizer finale

PASS ASan/UBSan dei10gruppi, exitcode0 senza diagnostici (`sanitizer.log`). Strumentati soltanto `kernel/fk_loft.cpp`, `kernel/fk_sketch_projection.cpp` e `kernel/tests/test_loft_projected_guides.cpp`, con `-fsanitize=address,undefined -fno-omit-frame-pointer`; libforgekernel.a e librerie di sistema di supporto non strumentate. `ASAN_OPTIONS=detect_leaks=0:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`. Non è una verifica sanitizer dell'app completa. Hash del package ricontrollati dopo la prova.

Nota fixture: la copia congelata mantiene il checksum iniziale. Al controllo finale il file originale attualmente sul disco ha un checksum diverso da quello acquisito all'inizio; tutti gli strumenti di questa attività hanno scritto soltanto in /tmp, e non è stata effettuata alcuna azione sul file originale. La diagnosi e i dati di fedeltà si riferiscono alla copia congelata esplicitamente identificata sopra.
