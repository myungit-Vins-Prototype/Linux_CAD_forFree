from pathlib import Path
import subprocess,shlex,os
p=Path('/tmp/forgecad-loft-projected-fix');r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release'
def run(cmd,expected=0):
 print('COMMAND '+shlex.join([str(s) for s in cmd]),flush=True);result=subprocess.run(cmd);print('EXITCODE '+str(result.returncode),flush=True);assert result.returncode==expected
base=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-I'+str(r/'kernel')];lib=[str(b/'kernel/libforgekernel.a'),'-pthread']
test=str(p/'kernel/tests/test_loft_projected_guides.cpp')
# Same new assertions: original implementation fails immediately; loft-only fix misses a transformed middle hit.
run(base+[test]+lib+['-o',str(p/'kernel-baseline')]);run([str(p/'kernel-baseline')],1)
run(base+[test,str(p/'fk_loft.o')]+lib+['-o',str(p/'kernel-loft-only')]);run([str(p/'kernel-loft-only')],1)
run([str(p/'kernel-tests')])
for name,source in [('projection21','test_sketch_projection.cpp'),('reference39','test_projected_curve_references.cpp')]:
 run(base+[str(r/'kernel/tests'/source),str(p/'fk_sketch_projection.o')]+lib+['-o',str(p/name)]);run([str(p/name)])
