// Fixture congelata SurfaceModellingExample219.prt, HEAD f75015b.
// Sezioni: Curva 3 di Schizzo 8 (storyId8, index7, curve2), Curva estratta 3D 1 (featureId5,index4).
// Guide: Curva estratta 3D 3 (featureId7,index5), Curva estratta 3D 5 (featureId9,index7), G1/100%.
static ExtrusionObject makeLoftDefinition(DocumentState &document) {
    const auto bodyIndex=[&](const QString &name){for(int i=0;i<document.extrusions.size();++i)if(document.extrusions[i].name==name)return i;throw std::runtime_error("Fixture: feature mancante");};
    const int section=bodyIndex(QStringLiteral("Curva estratta 3D 1")),first=bodyIndex(QStringLiteral("Curva estratta 3D 3")),second=bodyIndex(QStringLiteral("Curva estratta 3D 5"));
    document.extrusions.resize(std::max({section,first,second})+1);
    const auto curve=[&](int i){GeometryRef ref;ref.kind=9;ref.index=i;ref.featureId=document.extrusions[i].featureId;return ref;};
    int sketch=-1;for(int i=0;i<document.sketches.size();++i)if(document.sketches[i].name==QStringLiteral("Schizzo 8"))sketch=i;
    if(sketch<0 || document.sketches[sketch].curves.size()<3)throw std::runtime_error("Fixture: curva sezione dello schizzo mancante");
    GeometryRef profile;profile.kind=7;profile.index=sketch;profile.featureId=document.sketches[sketch].storyId;profile.element={1,2,-1};
    ExtrusionObject loft;loft.feature=BodyFeature::Loft;loft.name=QStringLiteral("Loft proiettato regressione");loft.featureId=100001;
    loft.loftSections={profile,curve(section)};loft.loftEdgeGuides={curve(first),curve(second)};
    loft.loftGuideContinuities={1,1};loft.loftGuideInfluences={1,1};loft.loftSurface=true;loft.loftRuled=false;
    return loft;
}
