from pathlib import Path
import subprocess,shlex,os,json,datetime
p=Path('/tmp/forgecad-loft-projected-fix');r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release'
def run(cmd,env=None):
 print('COMMAND '+shlex.join([str(s) for s in cmd]),flush=True);v=subprocess.run(cmd,env=env);print('EXITCODE '+str(v.returncode),flush=True);assert v.returncode==0
print('UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
print('Instrumented TUs: kernel/fk_loft.cpp, kernel/fk_sketch_projection.cpp, kernel/tests/test_loft_projected_guides.cpp. libforgekernel.a and system libraries uninstrumented; not a whole-app sanitizer build.',flush=True)
a=['c++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffp-contract=off','-Wall','-Wextra','-Wpedantic','-I'+str(r/'kernel')]
for name in ['fk_loft','fk_sketch_projection']:run(a+['-c',str(p/'kernel'/(name+'.cpp')),'-o',str(p/(name+'.asan.o'))])
run(a+[str(p/'kernel/tests/test_loft_projected_guides.cpp'),str(p/'fk_loft.asan.o'),str(p/'fk_sketch_projection.asan.o'),str(b/'kernel/libforgekernel.a'),'-pthread','-o',str(p/'kernel-tests-asan')])
env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1');print('ENV ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1',flush=True);run([str(p/'kernel-tests-asan')],env)
