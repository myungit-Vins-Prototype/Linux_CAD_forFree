from pathlib import Path
import os,subprocess,json,hashlib
q=Path('/tmp/forgecad-loft-projected-qa');b=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');j=json.loads((q/'loft-gui-link.json').read_text());assert not any('fk_loft-staged' in x for x in j['argv'])
objects=[]
for arg in j['argv']:
 if arg.endswith(('.o','.a')):
  p=Path(arg);p=p if p.is_absolute() else b/p
  assert p.is_file(),p;objects.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(q/'final-production-objects.json').write_text(json.dumps(objects,indent=2)+'\n')
original=Path('/home/myungit/Documenti/Cad_Example/SurfaceModellingExample219.prt');data=original.read_bytes();latest=q/'fixture-latest.prt';latest.write_bytes(data);(q/'latest-source.json').write_text(json.dumps({'path':str(original),'copy':str(latest),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'initial_frozen_sha256':'c0f55b07e446682fe4dcf0f6f982a80bc8ff6b87fabded0dc57c3196ea930b7b'},indent=2)+'\n')
base=os.environ.copy();base.update(QT_QPA_PLATFORMTHEME='',QT_STYLE_OVERRIDE='Fusion',XDG_CONFIG_HOME=str(q/'isolated/config'),XDG_CACHE_HOME=str(q/'isolated/cache'))
runs=[]
for platform,fixture,label,gl in [('wayland',Path('/tmp/forgecad-loft-projected-fix/fixture/SurfaceModellingExample219.prt'),'final-wayland',True),('xcb',Path('/tmp/forgecad-loft-projected-fix/fixture/SurfaceModellingExample219.prt'),'final-xcb',True),('offscreen',latest,'final-latest',False)]:
 env=base.copy();env['QT_QPA_PLATFORM']=platform
 if not gl:env['XDG_RUNTIME_DIR']=str(q/'isolated/runtime')
 argv=[str(q/'loft-gui'),str(fixture),str(q/label)]+(['--gl'] if gl else [])
 with (q/(label+'.log')).open('w') as log:p=subprocess.run(argv,env=env,cwd=b,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 runs.append({'platform':platform,'fixture':str(fixture),'label':label,'exit_code':p.returncode,'argv':argv});print(label,'exit',p.returncode,flush=True)
 assert p.returncode==0,(label,(q/(label+'.log')).read_text()[-1500:])
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in objects)
(q/'final-gui-runs.json').write_text(json.dumps({'runs':runs,'production_objects_unchanged':True},indent=2)+'\n')
