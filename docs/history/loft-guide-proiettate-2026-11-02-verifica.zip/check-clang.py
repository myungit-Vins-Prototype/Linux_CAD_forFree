from pathlib import Path
import json,shlex,subprocess,concurrent.futures
r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release';o=Path('/tmp/forgecad-loft-projected-qa');commands=json.loads((b/'compile_commands.json').read_text());files=['kernel/fk_loft.cpp','kernel/fk_sketch_projection.cpp','kernel/tests/test_loft_projected_guides.cpp'];jobs=[]
for name in files:
 c=next(x for x in commands if x['file']==str(r/name));a=shlex.split(c['command']);a[0]='clang++';i=a.index('-o');del a[i:i+2];a=[x for x in a if x not in ['-c','-mno-direct-extern-access']];a.insert(1,'-fsyntax-only');jobs.append({'file':name,'cwd':c['directory'],'argv':a})
(o/'clang-commands.json').write_text(json.dumps(jobs,indent=2)+'\n')
def run(j):
 p=subprocess.run(j['argv'],cwd=j['cwd'],capture_output=True,text=True);(o/('clang-'+Path(j['file']).stem+'.log')).write_text(p.stdout+p.stderr);return j['file'],p.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,jobs))
for f,c in results:print(f,'exit',c)
assert all(c==0 for _,c in results)
