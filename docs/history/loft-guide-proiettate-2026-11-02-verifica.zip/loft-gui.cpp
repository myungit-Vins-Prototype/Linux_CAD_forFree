#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_dialogs.h"
#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_application_theme.h"
#include "fk_body_io.h"
#include "fk_body_check.h"
#include "fk_tessellate.h"
#include <QTemporaryDir>
#include <iostream>
#include <stdexcept>
#include "definition.h"
static void require(bool ok,const QString &message){if(!ok)throw std::runtime_error(message.toStdString());}
class ViewportInteractionTest {public:
static void run(const QString &path,const QString &output,bool gl){
 using namespace ForgeCad;using namespace Kernel;
 DocumentState document;auto error=loadDocumentFile(path,document);require(error.isEmpty(),"caricamento fixture: "+error);
 const ExtrusionObject definition=makeLoftDefinition(document);const int owner=document.extrusions.size();
 for(auto &feature:document.extrusions)if(feature.feature==BodyFeature::DatumPlane)feature.visible=false;
 require(definition.loftSections.size()==2&&definition.loftEdgeGuides.size()==2,"due sezioni e due guide del caso segnalato");
 QMainWindow window;auto *view=new CadViewport(&window);view->tessellationQuality_=0;window.setCentralWidget(view);
 view->loadDocument(document);view->setReferencePlanesVisible(false);view->setGridVisible(false);view->setAxesVisible(false);
 if(gl){require(QGuiApplication::platformName()!="offscreen","piattaforma GL nativa");window.resize(1450,1000);window.show();}
 view->setViewFrame(QVector3D(1,0,0),QVector3D(.7f,-1.f,-.8f));view->fitAll();QApplication::processEvents();QDir().mkpath(output);
 std::exception_ptr failure;bool inspected=false,applied=false;
 const auto verify=[&](const ForgeBody &shape,const QString &phase){require(shape&&shape->isSheet(),phase+": lamina presente");const auto issues=checkBody(*shape,{true,true});require(issues.empty(),phase+": B-rep valida");const auto mesh=tessellate(*shape,{});require(mesh.failedFaces==0,phase+": tassellazione completa");std::cout<<"PASS "<<phase.toStdString()<<" faces="<<shape->faces().size()<<" edges="<<shape->edges().size()<<std::endl;};
 QTimer::singleShot(0,&window,[&]{auto *panel=window.findChild<QDialog *>("loftDialog");try{
  require(panel,"pannello reale Loft di superfici");panel->resize(540,930);QApplication::processEvents();
  if(gl){view->fitAll();view->update();QApplication::processEvents();}
  const auto checked=[](QListWidget *list){int n=0;for(int k=0;k<list->count();++k)n+=list->item(k)->checkState()==Qt::Checked;return n;};
  auto *sections=panel->findChild<QListWidget *>("loftSections"),*guides=panel->findChild<QListWidget *>("loftGuides");require(sections&&guides&&checked(sections)==2&&checked(guides)==2,"selezioni corrette nel pannello");
  QElapsedTimer timer;timer.start();while((view->previewPending()||view->previewRunning_||(view->previewTimer_&&view->previewTimer_->isActive()))&&timer.elapsed()<180000)QApplication::processEvents();
  require(view->preview_.valid&&view->preview_.error.isEmpty(),"anteprima: "+view->previewError());verify(view->preview_.geometry,"preview");
  require(view->preview_.definition.loftGuideContinuities==QVector<int>({1,1}),"G1 per entrambe le guide");
  require(panel->grab().save(output+"/panel.png"),"cattura pannello");if(gl)require(view->grabFramebuffer().save(output+"/preview.png"),"cattura anteprima GL");inspected=true;
  panel->findChild<QDialogButtonBox *>()->button(QDialogButtonBox::Ok)->click();require(applied,"conferma pannello riuscita");
 }catch(...){failure=std::current_exception();if(panel)panel->reject();}});
 const bool accepted=loftDialog(&window,view,"Loft da guida proiettata — verifica",-1,definition,[&](const ExtrusionObject &d){const auto why=view->createBody(d);applied=why.isEmpty();if(!why.isEmpty())std::cerr<<why.toStdString()<<std::endl;return why;});
 if(failure)std::rethrow_exception(failure);
 require(accepted&&inspected&&applied&&view->extrusions_.size()==owner+1,"conferma nuova feature");
 verify(view->extrusions_[owner].forgeBody,"confirmed");const auto exact=writeBodyBinary(*view->extrusions_[owner].forgeBody);
 view->undo();require(view->extrusions_.size()==owner,"Undo rimuove soltanto il loft");view->redo();require(view->extrusions_.size()==owner+1&&writeBodyBinary(*view->extrusions_[owner].forgeBody)==exact,"Redo ripristina B-rep");
 for(bool cache:{true,false}){const auto file=output+(cache?"/SurfaceModellingExample219-loft.prt":"/SurfaceModellingExample219-loft-no-cache.prt");require(saveDocumentFile(file,view->documentState(),cache).isEmpty(),"salvataggio copia loft");DocumentState loaded;require(loadDocumentFile(file,loaded).isEmpty(),"decode copia");CadViewport reopened;reopened.tessellationQuality_=0;reopened.loadDocument(loaded);require(reopened.extrusions_.size()==owner+1&&reopened.extrusions_[owner].error.isEmpty(),"rigenerazione copia: "+reopened.extrusions_.value(owner).error);verify(reopened.extrusions_[owner].forgeBody,cache?"reopened-cache":"reopened-no-cache");}
 if(gl){view->fitAll();QApplication::processEvents();require(view->context()&&view->context()->isValid(),"contesto GL valido");require(view->grabFramebuffer().save(output+"/confirmed.png"),"cattura loft confermato");view->makeCurrent();const auto renderer=reinterpret_cast<const char *>(view->glGetString(GL_RENDERER));std::cout<<"GL renderer="<<(renderer?renderer:"")<<std::endl;require(view->glGetError()==GL_NO_ERROR,"nessun errore GL");view->doneCurrent();}
 std::cout<<"PASS pannello preview conferma Undo Redo codec cache/no-cache e rigenerazione del loft reale"<<std::endl;
}
};
int main(int argc,char **argv){QSurfaceFormat format;format.setRenderableType(QSurfaceFormat::OpenGL);format.setVersion(3,3);format.setProfile(QSurfaceFormat::CoreProfile);format.setDepthBufferSize(24);format.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(format);QApplication app(argc,argv);ForgeCad::initializeApplicationTheme(app);QCoreApplication::setOrganizationName("ForgeCADLoftProjectedQA");QCoreApplication::setApplicationName("GUI");QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());try{ViewportInteractionTest::run(app.arguments().value(1),app.arguments().value(2),app.arguments().contains("--gl"));}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
