# QA preliminare isolata del loft proiettato

Fixture congelata e definizione dello screenshot fornite dall'agente; originale non aperto per modifica. La sonda istanzia CadViewport/QMainWindow e loftDialog di produzione, senza finestra principale del documento, recovery o autosave, con QSettings e cartelle isolate.

- Codice baseline f75015b: exit1, errore identico `Loft non riuscito: planarImage: tipo di curva non gestito` (baseline.log).
- Primo oggetto staged fk_loft.cpp dell'agente, congelato localmente prima del link (staged-link.json): PASS offscreen e Wayland per anteprima, conferma, validità B-rep con controllo geometrico, tassellazione, Undo/Redo e riapertura/rigenerazione con cache e senza cache. Una faccia e quattro bordi.
- Wayland usa OpenGL reale Intel UHD Graphics P630/Mesa; contesto valido e GL_NO_ERROR. La prima cattura ha inquadratura incompleta a causa del pan manuale nella sonda dopo il ridimensionamento del viewport da parte del pannello. Prima della QA finale la sonda è stata corretta: fitAll dopo l'apertura del pannello, piani datum nascosti solo nella copia in memoria. Nessun prodotto modificato per questo problema della sonda.

Questi esiti riguardano un oggetto preliminare e librerie di supporto. Non attestano la patch finale, il nuovo controllo dell'errore aritmetico per origini lontane, né l'applicazione ricompilata. La QA finale deve ricollegarsi esclusivamente agli oggetti di produzione aggiornati e ripetere gli scenari.
