# Verifica finale del pannello Loft

Tre scenari finali PASS: fixture iniziale congelata su Wayland e XCB, seconda copia più recente su Qt offscreen. `final-gui-runs.json` registra comandi, piattaforme e codici di uscita0.

La sonda usa QMainWindow, CadViewport e loftDialog di produzione, sostituendo soltanto il main del runner test. `final-production-objects.json` identifica con SHA256 tutti gli oggetti/librerie effettivamente collegati; nessun oggetto staged è presente nel link finale e gli hash sono invariati dopo le prove. `final-tested-files.json` identifica sorgenti, app completa, runner e kernel.

Verificati nel pannello: due sezioni e due guide esattamente come nello screenshot, entrambe G1/100%; anteprima valida, Conferma, lamina1faccia/4bordi, checkBody geometrico e tassellazione; Undo/Redo con B-rep identica; salvataggio e riapertura con cache e senza cache, rigenerazione senza errori. Wayland: Intel UHD P630/Mesa; XCB: Quadro RTX3000/NVIDIA. Entrambi i contesti validi e GL_NO_ERROR. Pannelli e catture ispezionati; nella vista confermata la lamina del loft è visibile nel modello.

Solo le copie in memoria nascondono i piani datum per rendere leggibili le catture; la prima versione della sonda applicava inoltre un pan manuale e inquadrava male il modello dopo il ridimensionamento del viewport. Il pan è stato rimosso e fitAll richiamato a pannello aperto. Correzione della sonda, non del prodotto. La versione finale usa gli stessi assert geometrici e funzionali.

Non si avviano PdfWindow, recovery o autosave; impostazioni temporanee isolate, nessun processo utente chiuso, nessuna scrittura nel file originale. Il file sorgente è cambiato fra la prima e la seconda lettura; entrambe le copie congelate sono identificate dai rispettivi manifesti, senza attribuire l'autore della modifica. I dati di fedeltà numerica del replay dell'agente riguardano la prima copia.

Copie dimostrative in final-latest/: SurfaceModellingExample219-loft.prt e variante -no-cache.prt. Non vengono aggiunte al repository o all'archivio pubblico dei log. Le sonde provano il percorso descritto e non certificano tutte le combinazioni del loft o tutte le interazioni del mouse: la definizione è inizializzata con i riferimenti dello screenshot e il pulsante Conferma è attivato tramite Qt.
