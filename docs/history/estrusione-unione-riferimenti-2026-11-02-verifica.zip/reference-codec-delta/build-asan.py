from pathlib import Path
import subprocess,shlex,json,os
p=Path('/tmp/forgecad-reference-codec-delta');old=Path('/tmp/forgecad-reference-fix');r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release'
commands=json.loads((b/'compile_commands.json').read_text());flags=shlex.split(next(x['command'] for x in commands if x['file']==str(r/'cad_constraints.cpp')))
print('ASAN/UBSAN instrumented: cad_constraints.cpp + module_probe.cpp (updated tests); prior coherent instrumented modules cad_projected_curve/cad_curve_solver/cad_sketch_refs/cad_datum/cad_document_io + kernel/fk_sketch_projection/fk_intersect/fk_curve_ops. Support modules and libforgekernel/Qt are uninstrumented. Not whole-app sanitizer.',flush=True)
for name in ['cad_constraints','module_probe']:
 args=flags.copy();args[args.index('-o')+1]=str(p/(name+'.asan.o'));args[-1]=str(p/(name+'.cpp'));args=['-O1' if s=='-O3' else s for s in args];args[1:1]=['-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffunction-sections','-fdata-sections']
 print('COMMAND '+shlex.join(args),flush=True);subprocess.run(args,cwd=b,check=True)
args=json.loads((old/'module-link-command.json').read_text());args[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
previous=['cad_projected_curve','cad_curve_solver','cad_sketch_refs','cad_datum','cad_document_io'];kernel=['fk_sketch_projection','fk_intersect','fk_curve_ops']
for i,s in enumerate(args):
 if s==str(old/'module-probe'):args[i]=str(p/'module-probe-asan')
 for n in ['cad_constraints','module_probe']:
  if s==str(old/(n+'.module.o')):args[i]=str(p/(n+'.asan.o'))
 for n in previous:
  if s==str(old/(n+'.module.o')):args[i]=str(old/(n+'.asan.o'))
 for n in kernel:
  if s==str(old/'kernel'/(n+'.o')):args[i]=str(old/'kernel'/(n+'.asan.o'))
print('COMMAND '+shlex.join(args),flush=True);subprocess.run(args,check=True)
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
print('ENV QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1\nCOMMAND '+str(p/'module-probe-asan'),flush=True)
result=subprocess.run([str(p/'module-probe-asan')],env=env);print('EXITCODE '+str(result.returncode),flush=True);raise SystemExit(result.returncode)
