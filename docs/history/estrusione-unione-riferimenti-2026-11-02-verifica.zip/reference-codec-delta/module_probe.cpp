#include "cad_types.h"
#include "cad_projected_curve.h"
#include "cad_sketch_refs.h"
#include "cad_curve_solver.h"
#include "cad_kernel.h"
#include "cad_constraints.h"
#include "cad_datum.h"
#include "cad_document_io.h"
#include "fk_sketch_projection.h"
#include "fk_curve_algo.h"
#include <QCoreApplication>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <stdexcept>
static void require(bool condition,const char *message){if(!condition)throw std::runtime_error(message);}
class ViewportInteractionTest {public:
#include "tests/test_projected_curve_references.h"
};
int main(int argc,char**argv){QCoreApplication application(argc,argv);try{ViewportInteractionTest::projectedCurveReferences();return 0;}catch(const std::exception &error){std::cerr<<"FAIL "<<error.what()<<'\n';return 1;}}
