from pathlib import Path
import json,subprocess,shlex,hashlib,os
p=Path('/tmp/forgecad-reference-codec-delta');old=Path('/tmp/forgecad-reference-fix');r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release'
assert (r/'cad_types.h').read_bytes()==(old/'cad_types.h').read_bytes(),'ABI changed; rebuild coherent support objects first'
(p/'module_probe.cpp').write_bytes((old/'module_probe.cpp').read_bytes())
commands=json.loads((b/'compile_commands.json').read_text());flags=shlex.split(next(x['command'] for x in commands if x['file']==str(r/'cad_constraints.cpp')))
for name in ['cad_constraints','module_probe']:
 args=flags.copy();args[args.index('-o')+1]=str(p/(name+'.o'));args[-1]=str(p/(name+'.cpp'));args=['-O0' if s=='-O3' else s for s in args];args[1:1]=['-g','-ffunction-sections','-fdata-sections']
 print('COMMAND '+shlex.join(args),flush=True);subprocess.run(args,cwd=b,check=True)
args=json.loads((old/'module-link-command.json').read_text())
for i,s in enumerate(args):
 if s==str(old/'module-probe'):args[i]=str(p/'module-probe')
 for name in ['cad_constraints','module_probe']:
  if s==str(old/(name+'.module.o')):args[i]=str(p/(name+'.o'))
print('COMMAND '+shlex.join(args),flush=True);subprocess.run(args,cwd=p,check=True)
print('COMMAND '+str(p/'module-probe'),flush=True);result=subprocess.run([str(p/'module-probe')],cwd=p);print('EXITCODE '+str(result.returncode));raise SystemExit(result.returncode)
