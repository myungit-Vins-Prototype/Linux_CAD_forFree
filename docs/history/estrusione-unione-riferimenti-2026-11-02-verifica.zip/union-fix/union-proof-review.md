# Review read-only — unione extent4 con interni dimostrati disgiunti

Esaminati esclusivamente i cambiamenti di `production/cad_extrude.cpp` e `production/kernel/fk_boolean.{h,cpp}` rispetto al codice precedente. Nessuna modifica alla produzione, al checkout o al pacchetto riferimenti.

**Esito: nessun rilievo bloccante nella prova o nella registrazione della genealogia esaminate.** Esecuzione dei test app demandata al runner coerente della build globale: questa review non sostituisce quella verifica.

## Perché la precondizione è conservata

1. `DisjointLimit` conserva indice e identità dello stesso B-rep immutabile, non una somiglianza geometrica. `provenDisjoint` controlla entrambi e limita il percorso a estrusione, extent4, operation<0.
2. Per un limite nel semispazio posteriore, l'estrusione iniziale resta nel semispazio anteriore: `hi<=0` prova che gli interni non si incontrano. Il ramo che ignora come limite `hi<=kLinearResolution` attesta disgiunzione soltanto per `hi<=0`. La fascia positiva `(0,resolution]` non viene attestata, correttamente.
3. Un'intersezione solida vuota attesta la disgiunzione del risultato corrente rispetto a quel limite. Una sottrazione seguita dalla selezione delle sole shell iniziali conserva un sottoinsieme della differenza. Prima del filtro il controllo delle shell non iniziali rifiuta le cavità orientate negativamente: ometterle avrebbe riempito materiale e invalidato la prova. I successivi passi del ciclo possono soltanto ridurre il risultato.
4. Il merge non modifica il risultato prima di usare la prova. Se tutti i destinatari sono attestati, la loro unione viene prima costruita con la booleana generale: anche se i destinatari si sovrappongono fra loro, il resto resta disgiunto dalla loro unione. Un destinatario senza attestazione costringe invece al percorso generale per l'intera fusione.
5. Il wrapper pubblico `forgeMergeFeatureResult` passa una lista di prove vuota. Le altre condizioni di fine e le altre feature continuano a usare la booleana generale. Per sottrazione il percorso attestato non viene impiegato.

`uniteDisjointBodies` ha una precondizione esplicita nell'header: i controlli In/OnSame e checkBody sono guardie aggiuntive, non la dimostrazione di disgiunzione. L'API non va usata come riconoscitore generale di volumi disgiunti. Il costruttore continua a classificare, assemblare, cucire, calcolare SP-curve e validare il risultato con i budget ordinari.

## Genealogia

La nuova unione chiede BodyHistory al kernel e chiama `registerDeclaredHistory(result,{first,second},history)` sugli stessi puntatori usati dalla costruzione. L'eventuale aggregazione dei destinatari passa da `forgeBooleanWithHistory`, quindi non interrompe la catena di dichiarazioni. Le dichiarazioni delle facce vengono conservate anche attraverso unifySameDomain; la successiva registrazione della feature può ricomporle sui veri operandi extent4/merge. Non è stata introdotta una nuova inferenza per prossimità. Edge e vertici conservano il percorso di ripiego preesistente: non vengono dichiarati tutti esatti da questa review.

## Rischi di regressione da verificare

- Il passaggio map→multimap delle SP-curve e il riuso delle parametrizzazioni coincidendi interessano anche le booleane generali. La scelta resta per curva e per superficie e conserva l'ultima voce corrispondente nell'ordine deterministico delle coppie, ma questa modifica giustifica il CTest completo e i test separati di `sameSurfaceParameterization` già predisposti da root.
- Il riuso della SP-curve è valido soltanto quando `sameSurfaceParameterization` identifica realmente la stessa parametrizzazione, non solo lo stesso supporto geometrico. Nel codice esaminato quel predicato è distinto dal riconoscimento di coincidenza delle superfici e viene usato come guardia.
- La modalità attestata cerca tagli soltanto fra carrier riconosciuti coincidenti. Il caso extent4 fornisce le facce di taglio dalla medesima geometria del limite; contatti fra carrier equivalenti riconosciuti soltanto in parte possono ancora fallire esplicitamente. Non si propone di rimpiazzare con questa API la booleana generale.
- Gli errori e la cancellazione seguono perlopiù i percorsi preesistenti; il nuovo probe automatico rilancia OperationCancelled. Questa review non attribuisce al cambiamento una nuova certificazione globale della cancellazione dei merge, la cui catch esterna era già generica.

## Nuove regressioni app

`tests/test_next_body_union.h`, metodo `nextBodyUnionRegressions()`, SHA256 `c1aee2b6d6a92f0f595c0d299322306318c6967ac0f4d1c72509e09a4e388852`.

Prove sintetiche: unione auto/manuale a limite piano e cilindrico; destinatario laterale separato conservato manualmente ed escluso automaticamente; due limiti complementari; destinatari sovrapposti; verso negativo con prove per semispazio e per differenza; destinatario penetrante escluso dai limiti; wrapper pubblico con volumi realmente sovrapposti; fascia positiva ignorata come limite confrontata al wrapper generale senza prova. Sono controllati volume B-rep, checkBody, componenti, selezione dei destinatari e dichiarazioni genealogiche.

La fascia usa 0.5*kLinearResolution per collocare la fixture lontano dalle due soglie. Non si misura un microvolume teorico e non si pretende di osservare quale API sia stata chiamata tramite la sola geometria: il risultato viene confrontato al percorso ordinario, mentre la condizione stretta di non-attestazione è verificata nella review di cui sopra. Nessun hook di produzione e nessuna tolleranza indebolita.

**Verifica già eseguita:** compile-only del nuovo metodo con gli header correnti, C++17 -Wall -Wextra -Wpedantic, exitcode0 senza warning. Log `tests/union-compile.log`. Nessun link con oggetti di vecchia ABI né esecuzione app dichiarata; root integra il metodo nel runner dopo rebuild globale.
