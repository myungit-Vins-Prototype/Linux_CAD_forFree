from pathlib import Path
import zipfile,hashlib,json
root=Path('/tmp/forgecad-union-fix');repo=Path('/home/myungit/Linux_CAD_forFree');dest=root/'estrusione-unione-riferimenti-2026-11-02-verifica.zip'
allowed={'.cpp','.h','.py','.sh','.md','.json','.log','.txt','.xml','.patch','.png','.cmake'}
files={}
def add(path,arc):
 if path.is_file() and path.suffix in allowed:files[arc]=path
for p in root.iterdir():
 if p.name not in {'report-draft.md','evidence-archive.json'}:add(p,'union-fix/'+p.name)
for directory in ['production','tests','gui-qa','asan-ubsan']:
 for p in (root/directory).rglob('*'):add(p,'union-fix/'+str(p.relative_to(root)))
add(root/'ctest/manifest.json','union-fix/ctest/manifest.json')
for p in (root/'ctest').rglob('CTestTestfile.cmake'):add(p,'union-fix/ctest/'+str(p.relative_to(root/'ctest')))
for dirname,source in [('reference-initial',Path('/tmp/forgecad-reference-fix')),('reference-codec-delta',Path('/tmp/forgecad-reference-codec-delta'))]:
 for p in source.rglob('*'):
  if p.is_file() and p.suffix in allowed and not any(x in {'asan','module-objects','objects','baseline-objects'} for x in p.relative_to(source).parts[:-1]):add(p,dirname+'/'+str(p.relative_to(source)))
add(repo/'docs/estrusione-unione-riferimenti-proiettati-2026-11-02.md','REPORT-FINALE.md')
readme='''Evidenze del 2 novembre 2026: unione fino al corpo e riferimenti proiettati.
REPORT-FINALE.md descrive il risultato verificato e le fasi di test.
union-fix/final-metadata.json identifica i35 sorgenti e app/runner/kernel finali.
union-fix/final-test-summary.json sostituisce i151 risultati app dopo il delta codec,
conservando i12 target kernel della suite completa con libreria byte-identica.
Non e' una seconda singola esecuzione163 dopo il codec.
I log iniziali di compilazione, prototipi e sonde possono fallire: sono diagnosi,
non risultati finali. In particolare fk_boolean_adjacent.cpp e' solo un prototipo
che forzava tutte le unioni nel percorso di contatto: NON e' la produzione.
La produzione kernel applica l'API dedicata solo con precondizione documentata,
ed e' congelata in union-fix/production e nel commit verificato.
reference-initial precede l'ultimo delta di cad_constraints/test; reference-codec-delta
lo corregge e documenta FAIL prima -> PASS dopo, senza geometria fallback.
Log/JUnit mantengono il solo FAIL di sformo gia' preesistente e lo skip offscreen.
CAD originali, copie .prt, B-rep serializzati, binari, oggetti e profili browser
sono esclusi. Manifesti conservano gli hash delle fixture/dimostrazioni.
HTML/JSON della mappa generati restano locali ignorati da Git; qui sono presenti
solo verifiche e catture della mappa, non i due artefatti generati.
I rapporti sanitizer distinguono TU strumentati e supporti non strumentati.
'''
manifest=[{'path':arc,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for arc,p in sorted(files.items())]
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('LEGGIMI.txt',readme);z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 for arc,p in sorted(files.items()):z.write(p,arc)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for x in manifest:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
 assert not any(Path(n).suffix in {'.prt','.body','.o','.a','.so','.html'} for n in z.namelist())
result={'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'entries':len(manifest)+2,'all_hashes_verified':True,'cad_and_binaries_excluded':True}
(root/'evidence-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
