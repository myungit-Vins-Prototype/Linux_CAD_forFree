from pathlib import Path
import json,hashlib
repo=Path('/home/myungit/Linux_CAD_forFree');root=Path('/tmp/forgecad-union-fix');out=root/'final-tests';out.mkdir(exist_ok=True);items=[]
def put(p,b):
 t=out/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);old=repo/p;items.append({'path':p,'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None})
for src,dst,h in [('tests/test_next_body_union.h','tests/test_next_body_union.h','c1aee2b6d6a92f0f595c0d299322306318c6967ac0f4d1c72509e09a4e388852'),('tests/test_disjoint_union.cpp','kernel/tests/test_disjoint_union.cpp','21201c509d082d2169b3da3a2b6467a0297231c430f5558d04b482a1a4e8fc3a')]:
 b=(root/src).read_bytes();assert hashlib.sha256(b).hexdigest()==h;put(dst,b)
p='tests/test_viewport.cpp';s=(repo/p).read_text();needle='#include "test_next_body_union_cache.h"';assert s.count(needle)==1;s=s.replace(needle,needle+'\n#include "test_next_body_union.h"');needle='    if (app.arguments().contains(QStringLiteral("--next-body-union-cache"))) {';assert s.count(needle)==1;s=s.replace(needle,'''    if (app.arguments().contains(QStringLiteral("--next-body-union"))) {
        try { ViewportInteractionTest::nextBodyUnionRegressions(); }
        catch (const std::exception &error) { std::cerr << error.what() << std::endl; return 1; }
        return 0;
    }
'''+needle);put(p,s.encode())
p='CMakeLists.txt';s=(repo/p).read_text();needle='    forgecad_add_view_test(forgecad_next_body_union_cache_tests --next-body-union-cache)';assert s.count(needle)==1;s=s.replace(needle,needle+'''\n    forgecad_add_view_test(forgecad_next_body_union_tests --next-body-union)
    set_tests_properties(forgecad_next_body_union_tests PROPERTIES TIMEOUT 60)''');put(p,s.encode())
p='kernel/CMakeLists.txt';s=(repo/p).read_text().rstrip()+'''\n
add_executable(forgekernel_disjoint_union_tests tests/fk_test_main.cpp tests/test_disjoint_union.cpp)
target_link_libraries(forgekernel_disjoint_union_tests PRIVATE forgekernel)
target_compile_options(forgekernel_disjoint_union_tests PRIVATE -Wall -Wextra -Wpedantic)
set_target_properties(forgekernel_disjoint_union_tests PROPERTIES AUTOMOC OFF AUTOUIC OFF AUTORCC OFF)
add_test(NAME forgekernel_disjoint_union_tests COMMAND forgekernel_disjoint_union_tests)
set_tests_properties(forgekernel_disjoint_union_tests PROPERTIES TIMEOUT 60)
''';put(p,s.encode());(out/'manifest.json').write_text(json.dumps(items,indent=2)+'\n');print(len(items),'final test files')
