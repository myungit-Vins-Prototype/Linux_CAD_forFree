#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "/home/myungit/Linux_CAD_forFree/cad_history_graph.h"
#include "fk_mass.h"
#include <iostream>
#include <stdexcept>
static void require(bool ok,const char *message){if(!ok)throw std::runtime_error(message);}
class ViewportInteractionTest { public:
#include "/tmp/forgecad-union-fix/test_history_graph_next_body.h"
};
int main(int argc,char**argv){QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADStoryboardAudit");QCoreApplication::setApplicationName("Tests");try{ViewportInteractionTest::historyGraphNextBodyRegressions();}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
