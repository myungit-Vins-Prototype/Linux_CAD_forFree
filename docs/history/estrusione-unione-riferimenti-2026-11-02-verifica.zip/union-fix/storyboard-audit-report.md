# Audit dipendenze e grafo — 2 novembre 2026

## Ambito e separazione degli interventi

Audit di genealogia, consumo e rigenerazione per l'estrusione fino al prossimo
corpo con Unione e per i riferimenti associativi alla curva da due schizzi.
Il kernel/unione e' del coordinatore; il riferimento alle curve implicite e'
dell'agente projected_curve. Nessun sorgente del checkout effettivo, CMake o
memoria condivisa e' stato scritto da questo audit.

Dopo la segnalazione e' stata autorizzata una sola patch di produzione,
preparata isolata in `/tmp/forgecad-union-fix/cad_history_graph.cpp`, con
regressione dedicata `test_history_graph_next_body.h`.

## Difetto corretto nel grafo

Per extent4, il grafo diagnostico usava ancora ExtentRef, vuoto per questa
modalita', e ometteva booleanTools. Poteva quindi mostrare un riferimento
mancante fittizio e nascondere le vere dipendenze geometriche.

Ora ogni booleanTool appare come «limite prossimo corpo», i mergeBodies
attivi come «destinatario fusione» e non viene creato un arco ExtentRef.
Quando lo stesso target svolge entrambi i ruoli, rimangono due archi con
etichette distinte verso la stessa identita' di feature. Un limite reale
mancante continua a risultare invalido. Una lista mergeBodies rimasta nei
parametri con mergeOperation=0 non genera destinatari fittizi.

Sonda differenziale Qt offscreen:
`/tmp/forgecad-union-fix/storyboard-audit-build.py` produce before/after,
collegati agli oggetti Release esistenti e sostituendo il solo modulo grafo.
**Prima FAIL, dopo PASS.** Nessuna asserzione o tolleranza preesistente e'
stata modificata.

## Doppio ruolo limite/destinatario

Confermato dal codice: bodyOperands unisce e deduplica le dipendenze,
hiddenOperands consuma solo mergeBodies, inheritedModelBody eredita il primo
destinatario e historyOperands conserva entrambi gli insiemi senza duplicare
l'identita' del target sovrapposto.

La nuova regressione verifica anche una scena reale analitica: profilo
quadrato [0,2]^2 a z=0, target box [-1,3]^2 tra z=4 e z=6 e secondo limite
disgiunto. Entrambi sono booleanTools, solo il primo e' mergeBody manuale.

**PASS:** volume dell'unione 48; proprietario del target conservato; secondo
limite indipendente visibile; dipendenze deduplicate; genealogia effettiva
con entrambi gli ID; Undo/Redo; rollback prima dell'estrusione; codec senza
cache e rigenerazione alla riapertura. Disattivando l'Unione, il volume torna
16, il target resta un limite geometrico e torna visibile come corpo
indipendente. Undo/Redo conserva questa distinzione.

Questa scena non riproduce il problema delle superfici coincidenti libere
del documento utente: quello rimane alla correzione del coordinatore.

## Catena di proiezione e dipendenze sketch/feature

Sonda read-only separata:
`/tmp/forgecad-reference-fix/storyboard-reference-audit.cpp`, compilabile con
`storyboard-reference-build.py`. Input lineari esatti, cosi' il controllo del
scheduler non dipende dal nuovo supporto alle curve implicite:

S0 XY + S1 XZ -> ProjectedCurve mode1 -> S2 con link kind9 -> estrusione
superficie.

**PASS:** modifica di entrambi gli input con z massimo downstream 4 -> 3 ->
6; il refresh della cache S2 avviene prima della costruzione della funzione
successiva; ID stabili; rinomina; riferimenti di ritorno verso entrambi gli
input rifiutati; riordino prima della sorgente o dopo l'utilizzatore
rifiutato; rollback; Undo/Redo; codec con/senza cache e rebuildAll dopo
riapertura. Non e' emersa una patch necessaria al grafo di rigenerazione.

RuledFirst/RuledSecond sono gia' enumerati dalle dipendenze degli schizzi,
dal visitatore delle rimappature e dal codec. Il controllo dell'ordine nella
storyboard protegge il percorso normale dai cicli. Le funzioni curva non
consumano gli schizzi sorgenti.

## Rischi concreti e test trasmessi all'agente projected_curve

1. `sameSketchSource` confronta gia' GeometryRef.element, ma per kind9
   richiede anche coordinate del punto identiche: per un ramo esplicito,
   cliccare punti diversi sullo stesso ramo puo' creare link duplicati.
2. bodyCurveNear e' usato dal resolver, dal percorso e dagli estremi kind10;
   un nuovo selettore di ramo deve essere rispettato da tutti i consumer.
3. **Permutazione di ramo riprodotta:** nello schizzo XY due segmenti x0..4,
   a y0 e y10; nello schizzo XZ un segmento (0,0)->(4,4). Con ruledFirst
   [seg0,seg1], curves[0] sta a y0; invertendo solo la lista, geometria e
   conteggio restano invariati ma curves[0] sta a y10. Un ordinal persistito
   da solo non e' un'identita' genealogica del ramo. Occorre identita' delle
   sorgenti o invalidazione controllata sui cambi d'ordine/topologia, senza
   riaggancio silenzioso per prossimita'. Il riproduttore e' nella sonda.
4. Copertura richiesta al fix implicito: modifica della forma interna con
   estremi fermi; cache esatta S2 aggiornata; tentativo di modificare la
   proiezione per usare il suo S2 downstream rifiutato atomicamente;
   sparizione del ramo; Undo/Redo e riapertura. L'eliminazione attraverso
   link sketch puo' lasciare funzioni in errore, dato che la cascata dei
   corpi segue bodyOperands: non deve lasciare un downstream valido con una
   cache obsoleta. Questi test restano del proprietario del fix implicito.

## Fonti stabili da integrare

- cad_history_graph.cpp SHA256:
  `b734bf9402177466b6185bec3be4a155e86f33cff144242c7e3e9fc84c480049`
- test_history_graph_next_body.h SHA256:
  `5dd16aadbd405f486d08d31739cb4cbe1be2a564fda8acae286d2d3baa55eec9`

Il test espone il metodo friend `historyGraphNextBodyRegressions()`;
nessuna modifica al runner comune e' stata fatta. Gli esiti sopra sono di
sonde Qt offscreen con oggetti Release esistenti, non una build aggiornata
dell'app o una prova grafica OpenGL.
