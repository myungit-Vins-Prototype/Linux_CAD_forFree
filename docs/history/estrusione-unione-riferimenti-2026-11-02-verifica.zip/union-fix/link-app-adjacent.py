from pathlib import Path
import shlex,subprocess
build=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');out=Path('/tmp/forgecad-union-fix');args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());args[args.index('-o')+1]=str(out/'probe-adjacent')
for i,a in enumerate(args):
 if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':args[i]=str(out/'probe.o')
 elif a.startswith('-Wl,--dependency-file='):args[i]='-Wl,--dependency-file='+str(out/'probe-adjacent.d')
args.insert(args.index('kernel/libforgekernel.a'),str(out/'fk_boolean_adjacent.o'));subprocess.run(args,cwd=build,check=True)
