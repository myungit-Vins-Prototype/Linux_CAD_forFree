from pathlib import Path
import subprocess,shlex,json,shutil
repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release';out=Path('/tmp/forgecad-union-fix');prod=out/'production'
for f in ['fk_surface_algo.h','fk_surface_algo.cpp']:shutil.copy2(out/f,prod/'kernel'/f)
commands=json.loads((build/'compile_commands.json').read_text())
for f in ['kernel/fk_boolean.cpp','kernel/fk_surface_algo.cpp','cad_extrude.cpp']:
 c=next(x for x in commands if x['file']==str(repo/f));args=shlex.split(c['command']);args[args.index('-o')+1]=str(prod/(Path(f).stem+'.o'));args[-1]=str(prod/f);args.insert(1,'-I'+str(prod/'kernel'));subprocess.run(args,cwd=build,check=True)
args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());args[args.index('-o')+1]=str(out/'probe-production')
for i,a in enumerate(args):
 if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':args[i]=str(out/'probe.o')
 elif a=='CMakeFiles/forgecad_view_tests.dir/cad_extrude.cpp.o':args[i]=str(prod/'cad_extrude.o')
 elif a.startswith('-Wl,--dependency-file='):args[i]='-Wl,--dependency-file='+str(out/'probe-production.d')
p=args.index('kernel/libforgekernel.a');args[p:p]=[str(prod/'fk_boolean.o'),str(prod/'fk_surface_algo.o')];subprocess.run(args,cwd=build,check=True)
s=(out/'kernel-probe.cpp').read_text().replace('booleanOperation(a,b,BooleanOperation::Unite,options,&h)','uniteDisjointBodies(a,b,options,&h)');(out/'kernel-production-probe.cpp').write_text(s)
subprocess.run(['/usr/bin/c++','-std=c++17','-O2','-ffp-contract=off','-I'+str(prod/'kernel'),'-I'+str(repo/'kernel'),str(out/'kernel-production-probe.cpp'),str(prod/'fk_boolean.o'),str(prod/'fk_surface_algo.o'),str(build/'kernel/libforgekernel.a'),'-lpthread','-o',str(out/'kernel-production-probe')],check=True)
