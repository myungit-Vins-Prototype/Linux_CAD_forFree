from pathlib import Path
import json,hashlib
repo=Path('/home/myungit/Linux_CAD_forFree');out=Path('/tmp/forgecad-union-fix/documentation');out.mkdir(exist_ok=True);items=[]
def put(p,s):
 t=out/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s);old=repo/p;items.append({'path':p,'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None})
p='README.it.md';s=(repo/p).read_text();old='Per i rami impliciti non sono disponibili sweep, conversione in schizzo e STEP/IGES;';new='Anche i rami impliciti si possono usare come riferimenti associativi in altri schizzi con **Converti spigoli**, snap, quote, PointOnCurve e Pierce; sweep, conversione libera in NURBS e STEP/IGES restano indisponibili per questi rami;';assert old in s;s=s.replace(old,new);put(p,s)
p='docs/curva-proiettata-due-schizzi-2026-11-02.md';s=(repo/p).read_text();s=s.replace('## Geometria','''Per usare la curva in un altro schizzo, aprire lo schizzo destinazione e scegliere **Converti spigoli** sulla componente desiderata. Il collegamento resta associativo anche per i rami impliciti: la forma segue entrambi gli schizzi sorgenti. Sono disponibili snap, quote e PointOnCurve; Pierce usa i punti esatti di attraversamento del piano dello schizzo. Se un ramo scompare il riferimento diventa non risolto, senza saltare su un ramo vicino.

Il [successivo fix di unione e riferimenti](estrusione-unione-riferimenti-proiettati-2026-11-02.md) descrive le nuove verifiche. Gli esiti di build e GUI riportati più sotto documentano il primo rilascio.

## Geometria''',1);s=s.replace('**sweep, conversione in schizzo ed esportazione STEP/IGES non sono disponibili**','**sweep, conversione libera in NURBS ed esportazione STEP/IGES non sono disponibili**');put(p,s)
p='docs/superfici-estrusione-2026-11-02.md';s=(repo/p).read_text();needle='## Documento e uso';s=s.replace(needle,'''Il [successivo fix dell’unione e dei riferimenti](estrusione-unione-riferimenti-proiettati-2026-11-02.md) aggiunge **Unione** all’estrusione fino al corpo. I volumi e le verifiche seguenti riguardano il precedente risultato **Corpo nuovo**: non attestavano la fusione con la scocca.

'''+needle,1);put(p,s)
p='tools/generate_architecture.py';s=(repo/p).read_text();replacements={
'Curva 3D da due schizzi: selezione precisa delle entita, proiezioni lungo le normali dei piani e rami esatti; riferimenti persistenti e limiti espliciti per le componenti implicite.':'Curva 3D esatta da due schizzi: input selettivi, chiavi genealogiche di componente indipendenti dall ordine e riferimenti associativi anche ai rami impliciti, senza fit.',
'Booleane B-rep: intersezione e classificazione, assemblaggio che conserva budget e SP-curve dei tratti con parametro invariato.':'Booleane B-rep e unione con interni disgiunti gia dimostrati dal chiamante: classificazione e verifica comuni, carrier con parametrizzazione identica e SP-curve distinte per coppia.',
'Algoritmi sulle superfici: coincidenza delle estrusioni certificata sull intero profilo razionale con coefficienti Bernstein proiettati.':'Algoritmi sulle superfici: coincidenza delle estrusioni certificata e identita stretta della parametrizzazione UV da dati esatti, per riutilizzare SP-curve senza riproiezione.',
'copertura e primo incontro certificati sulle facce rifilate, cavita controllate con volumi orientati; genealogia dei limiti distinta dalla fusione.':'copertura e primo incontro certificati sulle facce rifilate, cavita controllate; prova fresca di disgiunzione per unire gli stessi limiti, genealogia di limite e destinatario distinta.',
'Rappresenta e analizza il grafo delle dipendenze della storia.':'Grafo delle dipendenze della storia: ruoli separati per limite prossimo corpo e destinatario fusione, anche quando coincidono.',
'Costruisce e ricalcola le curve esatte a partire dalle entità dello sketch.':'Costruisce e ricalcola curve esatte dello sketch, comprese immagini affini associative di rami impliciti e derivate per il solver.',
'Risoluzione di piani, assi e riferimenti; le facce libere mantengono identita B-rep senza diventare piani o assi fittizi.':'Risoluzione di piani, assi, facce libere e curve esatte per chiavi genealogiche, senza riaggancio per prossimita.',
'Codec nativo 60 con Zstandard e lettura legacy; definizione, mesh/B-rep e genealogia, tipo solido ripristinato dalla cache e impronte storiche delle tavole conservate.':'Codec nativo60 con Zstandard e lettura legacy; definizioni, B-rep e genealogia; marcatore di curva procedurale ammesso solo con riferimento associativo e cache esatta ricostruita.',
}
for old,new in replacements.items():assert old in s,old;s=s.replace(old,new)
old='Proiezioni e contatti esatti associativi degli schizzi: sorgenti persistenti, spigoli, vertici, piani, assi, origine e sezioni di corpi, refresh delle cache, promozione visibile delle conversioni esplicite senza duplicati e diagnostica.';assert old in s;s=s.replace(old,'Proiezioni, contatti e Pierce esatti associativi degli schizzi: immagini affini delle curve implicite, sorgenti persistenti per chiavi genealogiche, refresh e invalidazione delle cache, conversioni esplicite visibili senza duplicati.')
needle=" 'tests/test_expression.cpp':";pos=s.index(needle);s=s[:pos]+''' 'tests/test_projected_curve_references.h': ('tests', 'Regressioni riferimenti esatti alla curva proiettata: input, quote, PointOnCurve, Pierce, persistenza, ramo mancante e riordino.'),
 'tests/test_next_body_union_cache.h': ('tests', 'Rigenerazione delle vecchie estrusioni extent4 Unione auto con destinatari vuoti, senza invalidare le altre cache.'),
 'tests/test_history_graph_next_body.h': ('tests', 'Grafo extent4, genealogia, consumo del solo destinatario, UndoRedo e persistenza.'),
 'kernel/tests/test_surface_parameterization.cpp': ('tests', 'Identita UV stretta dei carrier: copie e codec, dati diversi e ri-parametrizzazioni rifiutati.'),
 'kernel/tests/test_disjoint_union.cpp': ('tests', 'Unione B-rep con interni disgiunti: contatti parziali e B-spline, cavita, ordini, genealogia e booleana generale.'),
 'tests/test_next_body_union.h': ('tests', 'Estrusione extent4 con fusione automatica e manuale: prove di disgiunzione dai limiti e compatibilita del merge generale.'),
'''+s[pos:];put(p,s)
(out/'manifest.json').write_text(json.dumps(items,indent=2)+'\n');print(len(items),'doc/catalog files staged')
