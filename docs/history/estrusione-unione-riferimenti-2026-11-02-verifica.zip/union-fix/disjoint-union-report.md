# Test permanenti dell'unione con interni disgiunti — 2 novembre 2026

Prodotto soltanto il test proposto
`/tmp/forgecad-union-fix/tests/test_disjoint_union.cpp` e questo rapporto.
Nessuna modifica a produzione, checkout effettivo, CMake, memoria o documenti
CAD originali.

## Collegamento effettivo e risultato

Standalone C++17 senza Qt e OCCT, con `kernel/tests/fk_test_main.cpp`, oggetto
Boolean staged in `production/kernel/fk_boolean.cpp`, oggetto del nuovo
helper `fk_surface_algo.cpp` e libreria kernel Release esistente. Flag:
`-O2 -g -Wall -Wextra -Wpedantic -ffp-contract=off`. Nessun warning.

Eseguibile della sonda: `/tmp/forgecad-union-fix/test-disjoint-union`.
**7/7 gruppi PASS.** I casi positivi vengono ripetuti con entrambi gli ordini
degli operandi, controllano `checkBody({true,true})`, volume analitico,
numero di shell e genealogia delle facce dichiarata rispetto a entrambi gli
operandi, con indici validi e contributi di entrambi.

## Casi coperti

1. Contatto piano completo e contatto di area parziale, con piccolo box
   appoggiato all'interno di una faccia piu' grande: volumi 2 e 1,125,
   una shell. Classificazione di punti dentro la parte aggiunta e fuori
   dalla parte che non tocca.
2. Contatto che attraversa due facce coplanari del target, conservate
   separate da un'Unite ordinaria con unifySameDomain=false: volume 4,
   una shell dopo la saldatura.
3. Carrier B-spline **realmente non piano**
   `S(u,v)=(u,v,1+0.1*u*v)`. Il primo solido sta tra z=0 e la superficie su
   [0,2]^2, il secondo tra la stessa superficie e z=3 su [0.5,1.5]^2.
   Volumi analitici 4,4 e 1,9, risultato 6,3 con una shell. Le superfici sono
   copie indipendenti con stessa parametrizzazione; ripetuto anche dopo
   codec B-rep separato dei due solidi, senza puntatori condivisi.
4. Target con cavita' interna: box 4^3 meno box interno 2^3, aggiunta di un
   plug unitario disgiunto dal materiale che tocca una parete della cavita'.
   Volume finale 57, due shell; punti nella parte residua della cavita'
   restano Outside, quelli nel plug e nella parete sono Inside. Non si
   riempie la cavita' residua.
5. Contatto soltanto lungo uno spigolo, soltanto in un vertice e nessun
   contatto: volume additivo 2 e due shell. Nessuna falsa saldatura di area.
6. Provenienza da una differenza: prisma 2x2x6 meno limitatore intermedio,
   che lascia due componenti positive. Unire al medesimo limitatore e'
   consentito dalla precondizione; risultato volume 48 e una shell.
7. Operandi identici e contenimento vengono rifiutati dalle guardie.
   Separatamente, l'API **generica** booleanOperation(Unite) continua a
   gestire due box con interni sovrapposti: volume 12, una shell, genealogia
   valida in entrambi gli ordini. Questo protegge dalla sostituzione
   accidentale di tutte le Unite con il percorso ristretto.

## Contratto e limiti dei test

La disgiunzione degli interni e' una precondizione dimostrata dal chiamante;
questi test non presentano la nuova API come un rilevatore generale di
sovrapposizioni. Identici e contenimento verificano le osservazioni In e
OnSame coperte dalle guardie; non si promette il rifiuto di ogni ingresso
arbitrario non conforme. Non sono cambiati budget o tolleranze per ottenere
questi risultati.

Queste sono verifiche del kernel staged, non una compilazione dell'app.
Documento utente, anteprima/GUI, consumo della storyboard, persistenza CAD e
integrazione generale restano alle verifiche del coordinatore e degli altri
agenti. Il test permanente e' autosufficiente e non dipende da fixture CAD
esterne.

## Hash congelati

- Test: `21201c509d082d2169b3da3a2b6467a0297231c430f5558d04b482a1a4e8fc3a`
- Boolean cpp verificato:
  `9fae1db37cdf7b5fb2ac6c1f655b0b4bb316b2485520236f39ed9346a2f5fe75`
- Boolean header verificato:
  `de41d7abf40b3b53e68fcad613ec7913fb3e3f5266b61b4d1eb4bafb8df10ec8`
- Helper superficie cpp verificato:
  `fc015cfe0a7b21085efbd7b751dd51fc24183121ca3fd4692e0896e7ffaddb15`

## ASan/UBSan mirati successivi

Eseguite le cinque TU Boolean/surface/test/main strumentate, con supporti
Release precompilati non strumentati. Suite disjoint **7/7 PASS exit 0** e
parameterization **4/4 PASS exit 0**, senza segnalazioni ASan/UBSan. Primo
run disjoint: 7/7 casi riusciti, poi SIGABRT di LeakSanitizer incompatibile
con ptrace; log conservato separatamente. Run finali singoli autorizzati con
`detect_leaks=0:halt_on_error=1` e UBSan halt/stacktrace. Nessuna attestazione
di leak, nessuna modifica ai test o alla produzione. Comandi esatti, hash,
TU, esiti e limiti: `/tmp/forgecad-union-fix/asan-ubsan/report.md`, con
`commands.json`, `commands.sh` e log nella stessa directory.
