from pathlib import Path
import json,shlex,subprocess
root=Path('/home/myungit/Linux_CAD_forFree'); build=root/'forgecad-release'; out=Path('/tmp/forgecad-union-fix')
commands=json.loads((build/'compile_commands.json').read_text())
def compile_file(source,original,obj):
 c=next(c for c in commands if c['file'].endswith('/'+original)); a=shlex.split(c['command']); a[a.index('-o')+1]=str(out/obj); a[-1]=str(out/source);a=['-O0' if x=='-O3' else x for x in a];subprocess.run(a,cwd=build,check=True)
compile_file('storyboard-audit.cpp','tests/test_viewport.cpp','storyboard-audit.o')
compile_file('cad_history_graph.cpp','cad_history_graph.cpp','storyboard-graph.o')
for variant in ['before','after']:
 a=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(out/('storyboard-audit-'+variant))
 for i,x in enumerate(a):
  if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(out/'storyboard-audit.o')
  elif variant=='after' and x=='CMakeFiles/forgecad_view_tests.dir/cad_history_graph.cpp.o':a[i]=str(out/'storyboard-graph.o')
  elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(out/('storyboard-audit-'+variant+'.d'))
 subprocess.run(a,cwd=build,check=True)
