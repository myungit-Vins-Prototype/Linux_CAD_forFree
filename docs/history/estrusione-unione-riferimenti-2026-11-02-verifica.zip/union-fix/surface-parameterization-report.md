# Carrier con la stessa parametrizzazione — 2 novembre 2026

## Contratto e modifica

Helper puro C++17 `sameSurfaceParameterization(const Surface &, const Surface &)`
in `fk_surface_algo.{h,cpp}`. Restituisce true per lo stesso oggetto oppure
per rappresentazioni con dati finiti esattamente uguali. Nessun campione,
fit, distanza o tolleranza aggiunta. Parametri (u,v), punti e derivate hanno
cosi' lo stesso significato: una SP-curve puo' essere riusata senza proiezione.
Il chiamante deve conservare anche `pcurveTolerance` della sorgente.

B-spline: gradi, conteggi, nodi espansi, poli, pesi e presenza esplicita dei
pesi. Estrusioni: direzione e curva base. Curve riconosciute: Line, Circle,
Ellipse, BSpline, Trimmed e Transformed; i wrapper richiedono domini e
trasformazioni identici. Sono confrontati strettamente anche i frame/dati
delle superfici analitiche e asse/meridiano delle rivoluzioni. I tipi curva
sconosciuti sono accettati solo per identita' dello stesso oggetto.

`sameSurface` riconosce adesso le B-spline con questo certificato stretto.
La nozione geometrica piu' generale delle superfici analitiche/estruse resta
invariata e distinta: stessa geometria non autorizza da sola il riuso degli
stessi UV. Inversioni, traslazioni della base lungo la generatrice, domini
traslati, permutazioni U/V o rappresentazioni con nodi aggiunti non vengono
promosse a identita' di parametrizzazione. `Face::sense` resta responsabilita'
della classificazione delle facce, separata dal carrier.

## Verifiche effettive

Standalone senza Qt/OCCT con nuovo oggetto `fk_surface_algo.cpp` e libreria
kernel Release esistente; `-std=c++17 -O2 -Wall -Wextra -Wpedantic
-ffp-contract=off`. Nessun warning. Test dedicato
`tests/test_surface_parameterization.cpp`: **4/4 gruppi PASS**.

Verificati copie indipendenti e codec B-rep di superfici B-spline anche
razionali, tutte le famiglie curva richieste delle estrusioni, rifiuto di
un solo ULP modificato, peso diverso, domini diversi, U invertita e U/V
scambiati, verso della generatrice invertito, curve base invertite, trim
diversi e traslazione lungo la generatrice. Distinta la geometria equivalente
con nodi aggiunti dalla rappresentazione identica. Verificati frame
analitici diversi, tipi sconosciuti conservativi e propagazione della
cancellazione kernel.

Sonda read-only su `/tmp/forgecad-union-fix/extrusion.body` e `target.body`,
serializzati e letti separatamente (puntatori diversi):

- E faccia 2 / T faccia 8: B-spline identica riconosciuta;
- E faccia 3 / T faccia 9: B-spline identica riconosciuta;
- E faccia 4 / T faccia 18: Extrusion identica riconosciuta.

Per i tre carrier, il confronto degli stessi UV delle SP-curve sulle due
superfici ha scarto esattamente zero nella sonda. I punti servono come
verifica del test; il certificato di produzione confronta esclusivamente i
dati completi. Nessuna modifica ai documenti originali.

## Fonti congelate

Copie isolate in `/tmp/forgecad-union-fix/`; nessuna scrittura nei sorgenti
del checkout effettivo o nella booleana del coordinatore.

Before hash, registrati anche in `surface-parameterization-before.json`:

- h: `a3318a775e2993b2ccb64a4b8d6ae9520588beeb09fcda6e0a2c647ebacb4b14`
- cpp: `1da2247f35b6b165919f5b8f20a349a25fcd221db539a3e3c9fd82cd23cd1d79`

After hash:

- h: `4330c9f9e04a034015ab392c77fb2d4e75cf5194c87a4c0a753685d1acd1d2b4`
- cpp: `fc015cfe0a7b21085efbd7b751dd51fc24183121ca3fd4692e0896e7ffaddb15`
- test: `09eca09c56b54cdf53f1dcfe1ab02c0c2eb24ae0edd943e9556bff28cf375373`

Questa prova aggiorna soltanto il modulo e i runner della sonda; la build
completa, CMake, memoria e mappa sono centralizzati dal coordinatore.

## ASan/UBSan mirati successivi

Eseguite le cinque TU Boolean/surface/test/main strumentate, con supporti
Release precompilati non strumentati. Suite disjoint **7/7 PASS exit 0** e
parameterization **4/4 PASS exit 0**, senza segnalazioni ASan/UBSan. Primo
run disjoint: 7/7 casi riusciti, poi SIGABRT di LeakSanitizer incompatibile
con ptrace; log conservato separatamente. Run finali singoli autorizzati con
`detect_leaks=0:halt_on_error=1` e UBSan halt/stacktrace. Nessuna attestazione
di leak, nessuna modifica ai test o alla produzione. Comandi esatti, hash,
TU, esiti e limiti: `/tmp/forgecad-union-fix/asan-ubsan/report.md`, con
`commands.json`, `commands.sh` e log nella stessa directory.
