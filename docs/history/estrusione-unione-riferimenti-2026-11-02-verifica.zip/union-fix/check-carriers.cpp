#include "fk_body_io.h"
#include "fk_surface_algo.h"
#include <fstream>
#include <iostream>
using namespace ForgeCad::Kernel;Body read(const char*p){std::ifstream f(p,std::ios::binary);return readBodyBinary(std::string(std::istreambuf_iterator<char>(f),{}));}int main(){auto a=read("/tmp/forgecad-union-fix/extrusion.body"),b=read("/tmp/forgecad-union-fix/target.body");for(auto x:a.faces())for(auto y:b.faces())if(sameSurfaceParameterization(*a.face(x).surface,*b.face(y).surface))std::cout<<x.index<<" -> "<<y.index<<std::endl;}
