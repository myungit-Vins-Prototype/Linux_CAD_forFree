#include "fk_surface_algo.h"
#include "fk_body_io.h"
#include "fk_precision.h"
#include <fstream>
#include <iostream>
#include <iterator>
using namespace ForgeCad::Kernel;
Body load(const char*path){std::ifstream f(path,std::ios::binary);return readBodyBinary(std::string((std::istreambuf_iterator<char>(f)),{}));}
int main(int argc,char**argv){if(argc!=3)return 2;const auto a=load(argv[1]),b=load(argv[2]);int splines=0,extrusions=0;double deviation=0;
for(auto fa:a.faces())for(auto fb:b.faces()){
 const auto&sa=*a.face(fa).surface;const auto&sb=*b.face(fb).surface;
 if(sa.type()!=SurfaceType::BSpline&&sa.type()!=SurfaceType::Extrusion)continue;
 if(!sameSurfaceParameterization(sa,sb))continue;
 std::cout<<"MATCH first="<<fa.index<<" second="<<fb.index<<" type="<<int(sa.type())<<" same-pointer="<<(&sa==&sb)<<"\n";
 splines+=sa.type()==SurfaceType::BSpline;extrusions+=sa.type()==SurfaceType::Extrusion;
 if(!sameSurface(sa,sb,0))return 3;
 for(auto loop:a.face(fa).loops)for(auto fi:a.loopFins(loop)){const auto&fin=a.fin(fi);const auto&edge=a.edge(fin.edge);if(!fin.pcurve)return 4;for(double t:{edge.range.lo,.5*(edge.range.lo+edge.range.hi),edge.range.hi}){const auto uv=fin.pcurve->point(t);deviation=std::max(deviation,distance(sa.point(uv.x(),uv.y()),sb.point(uv.x(),uv.y())));}}
}
std::cout<<"MATCHES BSP="<<splines<<" Extrusion="<<extrusions<<" carrier-exact-deviation="<<deviation<<"\n";
return splines>=2&&extrusions>=1&&deviation==0?0:1;}
