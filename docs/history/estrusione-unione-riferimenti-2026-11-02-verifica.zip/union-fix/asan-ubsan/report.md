# ASan/UBSan mirati — 2 novembre 2026

## Esito

- `test_disjoint_union.cpp`: **7/7 PASS, exit 0** nel singolo run finale.
- `test_surface_parameterization.cpp`: **4/4 PASS, exit 0**.
- Nessuna segnalazione AddressSanitizer o UndefinedBehaviorSanitizer.
- Nessuna modifica a sorgenti, test, CMake o checkout effettivo.

## Traduzioni strumentate e collegamento

Compilatore effettivo: `/usr/bin/c++`, GCC 16.2.1 20260810.
Compilazione in sequenza, con:

```text
-std=c++17 -O1 -g1 -Wall -Wextra -Wpedantic -ffp-contract=off
-fno-omit-frame-pointer -fsanitize=address,undefined -fno-sanitize-recover=all
```

Cinque translation unit strumentate:

1. `/tmp/forgecad-union-fix/production/kernel/fk_boolean.cpp`
2. `/tmp/forgecad-union-fix/production/kernel/fk_surface_algo.cpp`
3. `/home/myungit/Linux_CAD_forFree/kernel/tests/fk_test_main.cpp`
4. `/tmp/forgecad-union-fix/tests/test_disjoint_union.cpp`
5. `/tmp/forgecad-union-fix/tests/test_surface_parameterization.cpp`

Entrambi gli eseguibili collegano esplicitamente gli oggetti Boolean e
surface strumentati prima di
`/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/libforgekernel.a`.
I moduli di supporto della libreria Release esistente non sono strumentati
in questa verifica. Sono assenti Qt e OCCT.

Argv completi, include, variabili runtime, hash SHA256 delle cinque TU,
exit code e tempi di ogni comando sono registrati in `commands.json`.
`commands.sh` conserva gli stessi comandi in forma shell; i log distinti
sono nella stessa directory. Tutte le compilazioni e i link sono terminati
con exit 0 e senza warning.

## Runtime e limite LeakSanitizer

Il primo run disjoint, con `detect_leaks=1`, ha eseguito **7/7 PASS** senza
segnalazioni ASan/UBSan, poi e' terminato con SIGABRT (return code -6) durante
la chiusura di LeakSanitizer:

```text
LeakSanitizer has encountered a fatal error.
LeakSanitizer does not work under ptrace (strace, gdb, etc)
```

Log conservato separatamente: `run-disjoint.log`. Non e' contato come
processo riuscito e il controllo LSan bloccato non e' stato ripetuto.

Su autorizzazione del coordinatore e' stata eseguita una sola volta ciascuna
suite con la configurazione supportata:

```text
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
```

Log finali: `run-disjoint-no-lsan.log` e
`run-parameterization-no-lsan.log`, entrambi exit 0. Le perdite di memoria
**non sono attestate**; LSan resta escluso per il limite dell'ambiente.

## Revisione e limiti

Le due suite sono rimaste agli hash gia' congelati. Non sono emersi problemi
di memoria o UB nelle TU strumentate e non e' stata necessaria una modifica
al codice dei test. Le fixture sono sintetiche e i controlli di volume,
validita' B-rep, cavita', genealogia e ordinamento degli operandi sono gli
stessi delle esecuzioni normali precedenti.

Questa e' una verifica mirata, non una strumentazione di tutto il kernel o
una compilazione dell'app. Accessi interni ai supporti precompilati non
strumentati non ricevono la copertura completa ASan/UBSan. Nessuna prova
GUI, OpenGL, documento utente o processo dell'app e' attribuita a questi
runner.
