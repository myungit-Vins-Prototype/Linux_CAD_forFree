from pathlib import Path
import subprocess,hashlib,json,shlex,time,os,sys
root=Path('/home/myungit/Linux_CAD_forFree');stage=Path('/tmp/forgecad-union-fix/production/kernel');out=Path('/tmp/forgecad-union-fix/asan-ubsan');testdir=Path('/tmp/forgecad-union-fix/tests')
sources={'boolean':stage/'fk_boolean.cpp','surface':stage/'fk_surface_algo.cpp','main':root/'kernel/tests/fk_test_main.cpp','disjoint':testdir/'test_disjoint_union.cpp','parameterization':testdir/'test_surface_parameterization.cpp'}
common=['/usr/bin/c++','-std=c++17','-O1','-g1','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-sanitize-recover=all','-I'+str(stage),'-I'+str(root/'kernel'),'-I'+str(root/'kernel/tests')]
metadata={'compiler':subprocess.check_output(['/usr/bin/c++','--version'],text=True).splitlines()[0],'sources':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in sources.items()},'support_library':str(root/'forgecad-release/kernel/libforgekernel.a'),'instrumented_support_library':False,'commands':[],'results':{}}
def run(name,args,env=None):
    logfile=out/(name+'.log');metadata['commands'].append({'name':name,'argv':args,'env_overrides':env or {},'log':str(logfile)})
    (out/'commands.json').write_text(json.dumps(metadata,indent=2)+'\n')
    with (out/'commands.sh').open('a') as f:f.write(('env '+ ' '.join(shlex.quote(k+'='+v) for k,v in env.items())+' ' if env else '')+shlex.join(args)+' > '+shlex.quote(str(logfile))+' 2>&1\n')
    print('START '+name,flush=True);start=time.monotonic()
    with logfile.open('w') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,**(env or {})))
    metadata['results'][name]={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start};(out/'commands.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('DONE '+name+' exit='+str(result.returncode),flush=True)
    if result.returncode:
        print(logfile.read_text()[-10000:],flush=True);sys.exit(result.returncode)
(out/'commands.sh').write_text('#!/bin/sh\n# Comandi effettivi eseguiti in sequenza; supporti lib non strumentati.\n')
for name,source in sources.items():run('compile-'+name,common+['-c',str(source),'-o',str(out/(name+'.o'))])
for suite in ['disjoint','parameterization']:
    binary=str(out/('test-'+suite))
    run('link-'+suite,common+[str(out/(suite+'.o')),str(out/'main.o'),str(out/'boolean.o'),str(out/'surface.o'),str(root/'forgecad-release/kernel/libforgekernel.a'),'-pthread','-o',binary])
    run('run-'+suite,[binary],{'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1:strict_string_checks=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
print('PASS suites ASan/UBSan',flush=True)
