from pathlib import Path
p=Path('/tmp/forgecad-union-fix/fk_boolean_adjacent.cpp');s=p.read_text();s=s.replace('std::map<const Curve<3> *, PCurves>','std::multimap<const Curve<3> *, PCurves>')
s=s.replace('out.pcurves[curve.get()] = entry;','out.pcurves.emplace(curve.get(), std::move(entry));')
s=s.replace('''        // Una curva presente in piu' coppie conserva la regola originale:
        // l'ultima voce nell'ordine delle coppie sostituisce la precedente.
        for (auto &[curve, entry] : result.pcurves) pcurves_[curve] = std::move(entry);
''','')
needle='                CurvePtr<2> pcurve = exactPCurve(surface, edge.curve, edge.range, accept);';assert s.count(needle)==1
s=s.replace(needle,'''                CurvePtr<2> pcurve;
                const bool identicalParameters = &surface == by.face(fy).surface.get();
                if (identicalParameters) pcurve = by.fin(f).pcurve;
                if (!pcurve) pcurve = exactPCurve(surface, edge.curve, edge.range, accept);''')
needle='                if (!pcurve) throw std::logic_error("booleanOperation: edge fuori dalla superficie coincidente");';assert s.count(needle)==1
s=s.replace(needle,needle+'''
                if (identicalParameters && by.fin(f).pcurve) {
                    PCurves entry;
                    entry.surface[0]=&surface;entry.surface[1]=by.face(fy).surface.get();
                    entry.pcurve[0]=pcurve;entry.pcurve[1]=pcurve;
                    entry.deviation=by.fin(f).pcurveTolerance;
                    out.pcurves.emplace(edge.curve.get(),std::move(entry));
                }''')
s=s.replace('                    arc.coplanar = true;','                    arc.coplanar = true;\n                    arc.tolerance = fullEdge.tolerance;')
a=s.index('        const auto found = pcurves_.find(result.edge(fin.edge).curve.get());');b=s.index('\n    }\n    // Estremi',a)
s=s[:a]+'''        if(fin.pcurve)continue;
        const auto found = pcurves_.equal_range(result.edge(fin.edge).curve.get());
        const Surface *surface = result.face(result.finFace(f)).surface.get();
        for(auto it=found.first;it!=found.second;++it)for(int k=0;k<2;++k)
            if(it->second.surface[k]==surface && it->second.pcurve[k]){
                fin.pcurve=it->second.pcurve[k];
                fin.pcurveTolerance=std::max(it->second.deviation,std::numeric_limits<double>::min());
            }''' +s[b:]
p.write_text(s)
