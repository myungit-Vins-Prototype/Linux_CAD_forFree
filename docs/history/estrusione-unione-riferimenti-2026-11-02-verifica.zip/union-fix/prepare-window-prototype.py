from pathlib import Path
repo=Path('/home/myungit/Linux_CAD_forFree');out=Path('/tmp/forgecad-union-fix')
s=(repo/'kernel/fk_face_normal_bounds.cpp').read_text();pos=s.index('bool faceHasNonnegativeNormalProjection(');s=s[:pos]+'std::pair<Interval,Interval> faceParameterBounds(const Body &body, FaceId face) { return parameterWindow(body,face); }\n\n'+s[pos:];(out/'fk_face_windows.cpp').write_text(s)
s=(repo/'kernel/fk_boolean.cpp').read_text();s='#include <cstdio>\n#include "fk_nurbs.h"\n'+s;s=s.replace('namespace ForgeCad::Kernel {','namespace ForgeCad::Kernel {\nstd::pair<Interval,Interval> faceParameterBounds(const Body &,FaceId);',1)
needle='const SurfaceIntersection intersection = intersectSurfaces(surfaceA, surfaceB, commonBounds(fa, fb), crossings, options);'
replacement='''const auto wa = faceParameterBounds(bodies_[0],fa), wb = faceParameterBounds(bodies_[1],fb);
    std::unique_ptr<BSplineSurface> clippedA,clippedB;
    if(surfaceA.type()==SurfaceType::BSpline && wa.first.isFinite() && wa.second.isFinite()) clippedA=std::make_unique<BSplineSurface>(toBSplineSurface(surfaceA,wa.first,wa.second));
    if(surfaceB.type()==SurfaceType::BSpline && wb.first.isFinite() && wb.second.isFinite()) clippedB=std::make_unique<BSplineSurface>(toBSplineSurface(surfaceB,wb.first,wb.second));
    std::fprintf(stderr,"WINDOWPAIR %d %d A[%g,%g][%g,%g] B[%g,%g][%g,%g]\\n",fa.index,fb.index,wa.first.lo,wa.first.hi,wa.second.lo,wa.second.hi,wb.first.lo,wb.first.hi,wb.second.lo,wb.second.hi);
    const SurfaceIntersection intersection = intersectSurfaces(clippedA?*clippedA:surfaceA, clippedB?*clippedB:surfaceB, commonBounds(fa, fb), crossings, options);
    std::fprintf(stderr,"DONEPAIR %d %d\\n",fa.index,fb.index);'''
assert s.count(needle)==1;s=s.replace(needle,replacement);(out/'fk_boolean_window.cpp').write_text(s)
