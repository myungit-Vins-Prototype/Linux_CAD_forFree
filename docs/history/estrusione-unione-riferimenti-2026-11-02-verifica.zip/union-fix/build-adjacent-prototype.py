from pathlib import Path
import subprocess,shlex,json
repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release';out=Path('/tmp/forgecad-union-fix')
c=next(x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].endswith('/kernel/fk_boolean.cpp'))
args=shlex.split(c['command']);args[args.index('-o')+1]=str(out/'fk_boolean_adjacent.o');args[-1]=str(out/'fk_boolean_adjacent.cpp');subprocess.run(args,cwd=build,check=True)
c=next(x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].endswith('/kernel/fk_surface_algo.cpp'))
args=shlex.split(c['command']);args[args.index('-o')+1]=str(out/'surface-parameters.o');args[-1]=str(out/'fk_surface_algo.cpp');subprocess.run(args,cwd=build,check=True)
subprocess.run(['/usr/bin/c++','-std=c++17','-O2','-ffp-contract=off','-I'+str(repo/'kernel'),str(out/'kernel-probe.cpp'),str(out/'fk_boolean_adjacent.o'),str(out/'surface-parameters.o'),str(build/'kernel/libforgekernel.a'),'-lpthread','-o',str(out/'kernel-probe-adjacent')],check=True)
