from pathlib import Path
import subprocess,shlex,json
repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release';out=Path('/tmp/forgecad-union-fix');cc=json.loads((build/'compile_commands.json').read_text());objects=[]
for source,temporary in [('fk_face_normal_bounds.cpp','fk_face_windows'),('fk_boolean.cpp','fk_boolean_window')]:
 c=next(x for x in cc if x['file'].endswith('/kernel/'+source));args=shlex.split(c['command']);obj=out/(temporary+'.o');args[args.index('-o')+1]=str(obj);args[-1]=str(out/(temporary+'.cpp'));subprocess.run(args,cwd=build,check=True);objects.append(str(obj))
subprocess.run(['/usr/bin/c++','-std=c++17','-O2','-ffp-contract=off','-I'+str(repo/'kernel'),str(out/'kernel-probe.cpp'),*objects,str(build/'kernel/libforgekernel.a'),'-lpthread','-o',str(out/'kernel-probe-window')],check=True)
