from pathlib import Path
repo=Path('/home/myungit/Linux_CAD_forFree');out=Path('/tmp/forgecad-union-fix/production');(out/'kernel').mkdir(parents=True,exist_ok=True)
s=Path('/tmp/forgecad-union-fix/fk_boolean_adjacent.cpp').read_text()
needle='return operation == BooleanOperation::Unite ? BooleanBuilder(a,b,operation,options).adjacentRun(history) : BooleanBuilder(a, b, operation, options).run(history);';assert s.count(needle)==1;s=s.replace(needle,'return BooleanBuilder(a, b, operation, options).run(history);')
needle='std::vector<Body> splitSheet(';pos=s.index(needle)
s=s[:pos]+'''Body uniteDisjointBodies(const Body &a, const Body &b, const BooleanOptions &options, BodyHistory *history) {
    if (history) *history = BodyHistory();
    return BooleanBuilder(a, b, BooleanOperation::Unite, options).adjacentRun(history);
}

'''+s[pos:]
s=s.replace('    bool adjacentOnly_ = false;','''    // Solo per operandi i cui interni sono gia' dimostrati disgiunti dal
    // chiamante (es. resto di una differenza con lo stesso utensile).
    // I contatti di area sono su carrier coincidenti: nessun attraversamento
    // trasversale va ricercato sui supporti estesi fuori dalle facce.
    bool adjacentOnly_ = false;''')
s=s.replace('uniteDisjointBodies: interiors are not disjoint','uniteDisjointBodies: interni non disgiunti')
s=s.replace('        if(fin.pcurve)continue;','        if (fin.pcurve) continue;')
(out/'kernel/fk_boolean.cpp').write_text(s)
h=(repo/'kernel/fk_boolean.h').read_text();needle='// Curve comuni alle facce dei due corpi';pos=h.index(needle)
h=h[:pos]+'''// Unione di solidi i cui INTERNI sono gia' dimostrati disgiunti dal chiamante.
// Esempio: A e' un sottoinsieme delle componenti del risultato P\\B, senza
// rimuovere shell interne/cavita'. Non e' una prova generale di disgiunzione:
// chiamare la booleana ordinaria per operandi arbitrari o sovrapposti.
// Divide i contatti sui carrier coincidenti, classifica e ricuce con gli
// stessi budget, checkBody e genealogia della booleana ordinaria. Le
// osservazioni In/OnSame sono guardie aggiuntive, non la precondizione.
// Se non c'e' contatto di area i solidi restano componenti separate.
Body uniteDisjointBodies(const Body &a, const Body &b, const BooleanOptions &options = {},
                         BodyHistory *history = nullptr);

'''+h[pos:];(out/'kernel/fk_boolean.h').write_text(h)
s=(repo/'cad_extrude.cpp').read_text();needle='namespace {\n\nInterval curveProjection';assert s.count(needle)==1;s=s.replace(needle,'''namespace {

struct DisjointLimit { int index; ForgeBody geometry; };
using DisjointLimits = QVector<DisjointLimit>;
ForgeBody mergeFeatureResult(ExtrusionObject &body, const ForgeBody &result, int index,
                             const QVector<ExtrusionObject> &bodies, QString *error,
                             const DisjointLimits &disjoint);

Interval curveProjection''')
s=s.replace('const QVector<ExtrusionObject> &bodies, QString *error) {\n    if (body.extrudeSides', 'const QVector<ExtrusionObject> &bodies, QString *error, DisjointLimits &disjoint) {\n    if (body.extrudeSides',1)
s=s.replace('        if (hi <= kLinearResolution) continue;', '''        if (hi <= kLinearResolution) {
            // Solo il semispazio davvero dietro il profilo prova che gli
            // interni non si intersecano. La fascia (0,resolution] non basta.
            if (hi <= 0.0) disjoint.append({target, bodies.at(target).forgeBody});
            continue;
        }''',1)
s=s.replace('        if (overlap->faces().empty()) continue;', '''        if (overlap->faces().empty()) {
            disjoint.append({candidate.index, bodies.at(candidate.index).forgeBody});
            continue;
        }''',1)
needle='        result = forgeKeepShells(cut, base);';assert s.count(needle)==1;s=s.replace(needle,needle+'''
        // Il filtro conserva un sottoinsieme della differenza solo dopo
        // avere escluso shell di cavita': prova valida sugli stessi B-rep.
        disjoint.append({candidate.index, bodies.at(candidate.index).forgeBody});''')
needle='    ForgeBody result;\n    try {\n        if (body.extent == 4)';assert s.count(needle)==1;s=s.replace(needle,'    ForgeBody result;\n    DisjointLimits disjoint;\n    try {\n        if (body.extent == 4)')
s=s.replace('extrusionUntilNext(body, index, sketch, bodies, error);','extrusionUntilNext(body, index, sketch, bodies, error, disjoint);')
needle='    return forgeMergeFeatureResult(body, result, index, bodies, error);';assert s.count(needle)==1;s=s.replace(needle,'    return mergeFeatureResult(body, result, index, bodies, error, disjoint);')
needle='ForgeBody forgeMergeFeatureResult(ExtrusionObject &body, const ForgeBody &result, int index,\n                                  const QVector<ExtrusionObject> &bodies, QString *error) {';assert s.count(needle)==1
s=s.replace(needle,'''namespace {

ForgeBody mergeFeatureResult(ExtrusionObject &body, const ForgeBody &result, int index,
                             const QVector<ExtrusionObject> &bodies, QString *error,
                             const DisjointLimits &disjoint) {''')
needle='    QVector<int> targets;\n    for (int target : body.mergeBodies)';assert s.count(needle)==1;s=s.replace(needle,'''    const auto provenDisjoint = [&](int target) {
        if (body.operation >= 0 || body.feature != BodyFeature::Extrusion || body.extent != 4) return false;
        return std::any_of(disjoint.begin(), disjoint.end(), [&](const DisjointLimit &proof) {
            return proof.index == target && target >= 0 && target < bodies.size()
                && proof.geometry == bodies.at(target).forgeBody;
        });
    };
    const auto disjointUnite = [&](const ForgeBody &first, const ForgeBody &second) {
        Kernel::BodyHistory history;
        auto geometry = std::make_shared<const Body>(uniteDisjointBodies(*first, *second, {}, &history));
        registerDeclaredHistory(geometry, {first, second}, std::move(history));
        return geometry;
    };
    QVector<int> targets;
    for (int target : body.mergeBodies)''')
needle='        if (body.mergeProbe && !forgeSharesMaterial(result, other.forgeBody, subtract)) continue;';assert s.count(needle)==1;s=s.replace(needle,'''        if (body.mergeProbe) {
            bool touching = false;
            if (!subtract && provenDisjoint(target)) {
                try {
                    const Body united = uniteDisjointBodies(*result, *other.forgeBody);
                    touching = united.shells().size() < result->shells().size() + other.forgeBody->shells().size();
                } catch (const OperationCancelled &) { throw; }
                catch (const std::exception &failure) {
                    setError(error, QStringLiteral("Contatto per l'unione automatica non risolto: %1").arg(QString::fromUtf8(failure.what())));
                    return nullptr;
                }
            } else touching = forgeSharesMaterial(result, other.forgeBody, subtract);
            if (!touching) continue;
        }''')
needle='''        if (!subtract) {
            ForgeBody united = result;''';assert s.count(needle)==1;s=s.replace(needle,'''        if (!subtract) {
            if (std::all_of(targets.begin(), targets.end(), provenDisjoint)) {
                // I destinatari possono sovrapporsi tra loro: aggregarli con
                // la booleana generale, poi saldarli al resto gia' disgiunto.
                ForgeBody combinedTargets = bodies.at(targets.front()).forgeBody;
                for (int i = 1; i < targets.size(); ++i)
                    combinedTargets = forgeBooleanWithHistory(combinedTargets, bodies.at(targets[i]).forgeBody, Kernel::BooleanOperation::Unite);
                return disjointUnite(result, combinedTargets);
            }
            ForgeBody united = result;''')
needle='void forgeComponentCounts(';pos=s.index(needle)
s=s[:pos]+'''} // namespace

ForgeBody forgeMergeFeatureResult(ExtrusionObject &body, const ForgeBody &result, int index,
                                  const QVector<ExtrusionObject> &bodies, QString *error) {
    return mergeFeatureResult(body, result, index, bodies, error, {});
}

'''+s[pos:]
(out/'cad_extrude.cpp').write_text(s)
print('Prepared production kernel API + proof-scoped extrusion integration')
