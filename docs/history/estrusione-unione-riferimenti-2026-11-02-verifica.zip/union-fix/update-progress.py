from pathlib import Path
p=Path('/home/myungit/Linux_CAD_forFree/CLAUDE.md');s=p.read_text();start=s.index('0. **02/11');end=s.index('\n1. **02/11',start)
s=s[:start]+'''0. **02/11 — Estrusione/curva e integrazione (in corso).** Checkpoint pubblicato `317b8cb`:
   curva3D esatta, facce libere/trim/shell corretti, formato60. Prove precedenti e limiti in
   [estrusione](docs/superfici-estrusione-2026-11-02.md) e [curva](docs/curva-proiettata-due-schizzi-2026-11-02.md).
   Nuovi fix integrati: extent4 Unione usa contatti B-rep solo quando la differenza appena costruita
   prova gli interni disgiunti dagli stessi limiti; booleana generale invariata. Corretti SP-curve su
   carrier identici e cache delle vecchie unioni automatiche vuote; grafo distingue limite/destinatario.
   Probe produzione sul Superfici corrente: auto/manuale PASS,23facce/1shell; kernel serializzato PASS
   entrambi ordini. Riferimenti proiettati esatti associativi, PointOnCurve/quote/Pierce, chiavi genealogiche,
   cache transitorie ricostruite senza fit. Agente: kernel39+precedenti21, modulo e sanitizer mirati PASS.
   Build app/runner completa avviata per nuova ABI; suite comune e QA nativa finali ancora da eseguire.
   Precedente CTest154 PASS/1 SKIP/1 FAIL preesistente sformo, non attesta i fix in corso. Originali non scritti.
''' + s[end:];assert len(s.encode())<=16384;p.write_text(s);print(len(s.encode()),'bytes')
