from pathlib import Path
import subprocess,json,hashlib,datetime
repo=Path('/home/myungit/Linux_CAD_forFree');out=Path('/tmp/forgecad-union-fix')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=set(subprocess.check_output(['git','diff','--name-only','HEAD','-z'],cwd=repo).decode().split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0'));sources=[]
for f in sorted(paths):
 p=repo/f
 if f and p.is_file() and p.suffix in ['.h','.cpp','.c','.cmake','.py'] or f in ['CMakeLists.txt','kernel/CMakeLists.txt']:
  sources.append({'path':f,'sha256':sha(p),'bytes':p.stat().st_size})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'platform':subprocess.check_output(['uname','-a'],text=True).strip(),'binaries':[],'sources':sources}
for f in ['forgecad-release/forgecad','forgecad-release/forgecad_view_tests','forgecad-release/kernel/libforgekernel.a']:
 p=repo/f;result['binaries'].append({'path':f,'sha256':sha(p),'bytes':p.stat().st_size})
for f in ['configure.log','full-build.log','final-build.log']:
 p=out/f
 if p.exists():result[f]={'sha256':sha(p),'bytes':p.stat().st_size}
(out/'final-metadata.json').write_text(json.dumps(result,indent=2)+'\n');print('Full app/runner/kernel hashes and',len(sources),'source hashes captured')
