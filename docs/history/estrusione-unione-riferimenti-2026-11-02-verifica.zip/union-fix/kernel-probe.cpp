#include "fk_body_io.h"
#include "fk_boolean.h"
#include "fk_history.h"
#include "fk_mass.h"
#include <fstream>
#include <iostream>
#include <chrono>
using namespace ForgeCad::Kernel;
Body read(const char*p){std::ifstream f(p,std::ios::binary);return readBodyBinary(std::string(std::istreambuf_iterator<char>(f),{}));}
int main(int argc,char**argv){Body a=read("/tmp/forgecad-union-fix/extrusion.body"),b=read("/tmp/forgecad-union-fix/target.body");bool reverse=argc>1&&std::atoi(argv[1]);if(reverse)std::swap(a,b);BooleanOptions options;options.threads=1;std::cerr<<"START reverse="<<reverse<<" faces="<<a.faces().size()<<","<<b.faces().size()<<std::endl;const auto start=std::chrono::steady_clock::now();try{BodyHistory h;auto c=booleanOperation(a,b,BooleanOperation::Unite,options,&h);std::cout.precision(17);std::cout<<"PASS volume="<<massProperties(c).volume<<" expected="<<massProperties(a).volume+massProperties(b).volume<<" faces="<<c.faces().size()<<" shells="<<c.shells().size()<<std::endl;std::ofstream("/tmp/forgecad-union-fix/united.body",std::ios::binary)<<writeBodyBinary(c);}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}std::cerr<<"elapsed="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;return 0;}
