from pathlib import Path
import json,hashlib
repo=Path('/home/myungit/Linux_CAD_forFree');p=repo/'CLAUDE.md';s=p.read_text();a=s.index('0. **02/11 — Estrusione');b=s.index('1. **02/11 — Correzioni',a)
entry='''0. **02/11 — Estrusione/curva e integrazione (in corso).** Review `d4f15fc` e funzioni `317b8cb` pubblicate.
   Checkpoint: facce libere/trim/shell/decoder corretti, curva3D esatta da due schizzi, formato60.
   Build app/runner PASS, GUI estrusione9/9 e proiezione2/2; CTest154 PASS/1 SKIP/1 FAIL preesistente
   di sformo (kernel457/458), mappa541file/7437relazioni/255TU, check/HTML PASS.
   [Estrusione](docs/superfici-estrusione-2026-11-02.md) e [curva](docs/curva-proiettata-due-schizzi-2026-11-02.md)
   conservano prove, limiti e salvataggio successivo Superfici verificato, senza scrivere gli originali.
   Nuova richiesta: Unione extent4 e riferimenti della curva in altri schizzi. Riprodotto auto-merge che
   scarta il target dopo errore booleana su superfici coincidenti; manuale fallisce sui semi. Probe kernel
   e fix trim in preparazione. Agente proiezione estende cache esatte/Pierce senza fit; GUI controlla
   riuso della vecchia cache e QA, storyboard corregge grafo doppio ruolo limite/destinatario.
   Nessuna nuova build completa ancora; le verifiche precedenti non attestano i fix in corso.

'''
s=s[:a]+entry+s[b:];assert len(s.encode())<=16384
pkg=Path('/tmp/forgecad-union-fix/memory-progress');pkg.mkdir(exist_ok=True);(pkg/'CLAUDE.md').write_text(s);(pkg/'manifest.json').write_text(json.dumps([{'path':'CLAUDE.md','before_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}]));print(len(s.encode()),'bytes')
