from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/home/myungit/Linux_CAD_forFree');root=Path('/tmp/forgecad-union-fix');ref=Path('/tmp/forgecad-reference-fix');out=root/'integration';out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
items={}
def put(path,data,before='HEAD'):
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 if before=='HEAD':
  r=subprocess.run(['git','show','HEAD:'+path],cwd=repo,capture_output=True);before=sha(r.stdout) if r.returncode==0 else None
 items[path]={'path':path,'before_sha256':before,'after_sha256':sha(data)}
for item in json.loads((ref/'manifest.json').read_text())['files']:
 data=(ref/item['path']).read_bytes();assert sha(data)==item['after_sha256'];put(item['path'],data,item['before_sha256'])
# Merge the independent cache invalidation hunk into the reference-agent TU.
subprocess.run(['patch','--batch','-p1','-d',str(out),'-i',str(root/'gui-qa/unchanged-feature.patch')],check=True)
p='forgeCad2026_viewport_document.cpp';items[p]['after_sha256']=sha((out/p).read_bytes())
for p in ['kernel/fk_boolean.h','kernel/fk_boolean.cpp','kernel/fk_surface_algo.h','kernel/fk_surface_algo.cpp','cad_extrude.cpp']:put(p,(root/'production'/p).read_bytes())
put('cad_history_graph.cpp',(root/'cad_history_graph.cpp').read_bytes())
for source,target in [('gui-qa/test_next_body_union_cache.h','tests/test_next_body_union_cache.h'),('test_history_graph_next_body.h','tests/test_history_graph_next_body.h'),('tests/test_surface_parameterization.cpp','kernel/tests/test_surface_parameterization.cpp')]:put(target,(root/source).read_bytes(),None)
s=(repo/'tests/test_viewport.cpp').read_text();needle='#include "test_sketch_projection_gui.h"';assert s.count(needle)==1
headers=['test_projected_curve_references.h','test_next_body_union_cache.h','test_history_graph_next_body.h']
s=s.replace(needle,needle+'\n'+'\n'.join('#include "'+x+'"' for x in headers))
needle='    if (app.arguments().contains(QStringLiteral("--sketch-projection"))) {';assert s.count(needle)==1
cases=[('projected-curve-references','projectedCurveReferences'),('next-body-union-cache','nextBodyUnionCacheRegressions'),('history-graph-next-body','historyGraphNextBodyRegressions')]
insert=''
for flag,method in cases:insert+='''    if (app.arguments().contains(QStringLiteral("--%s"))) {
        try { ViewportInteractionTest::%s(); }
        catch (const std::exception &error) { std::cerr << error.what() << std::endl; return 1; }
        return 0;
    }
'''%(flag,method)
s=s.replace(needle,insert+needle);put('tests/test_viewport.cpp',s.encode())
s=(repo/'CMakeLists.txt').read_text();needle='    forgecad_add_view_test(forgecad_sketch_projection_tests --sketch-projection)';assert s.count(needle)==1
s=s.replace(needle,needle+'''\n    forgecad_add_view_test(forgecad_projected_curve_reference_tests --projected-curve-references)
    forgecad_add_view_test(forgecad_next_body_union_cache_tests --next-body-union-cache)
    forgecad_add_view_test(forgecad_history_graph_next_body_tests --history-graph-next-body)
    set_tests_properties(forgecad_projected_curve_reference_tests forgecad_next_body_union_cache_tests
                         forgecad_history_graph_next_body_tests PROPERTIES TIMEOUT 60)''');put('CMakeLists.txt',s.encode())
s=(repo/'kernel/CMakeLists.txt').read_text()+'\n# Contatti B-rep e riferimenti esatti alle curve proiettate: solo kernel proprio.\n'
for name,src in [('projected_curve_reference','tests/test_projected_curve_references.cpp'),('surface_parameterization','tests/fk_test_main.cpp tests/test_surface_parameterization.cpp')]:
 t='forgekernel_'+name+'_tests';s+='''add_executable(%s %s)
target_link_libraries(%s PRIVATE forgekernel)
target_compile_options(%s PRIVATE -Wall -Wextra -Wpedantic)
set_target_properties(%s PROPERTIES AUTOMOC OFF AUTOUIC OFF AUTORCC OFF)
add_test(NAME %s COMMAND %s)
set_tests_properties(%s PROPERTIES TIMEOUT 60)
\n'''%(t,src,t,t,t,t,t,t)
put('kernel/CMakeLists.txt',s.encode());(out/'manifest.json').write_text(json.dumps(list(items.values()),indent=2)+'\n');print('Prepared',len(items),'guarded files')
