from pathlib import Path
import hashlib,json,datetime
root=Path('/tmp/forgecad-union-fix');repo=Path('/home/myungit/Linux_CAD_forFree');r=[]
def check(original,copy,expected):
 for p,is_original in [(Path(original),True),(Path(copy),False)]:
  h=hashlib.sha256(p.read_bytes()).hexdigest();same=h==expected
  if not is_original:assert same,p
  r.append({'path':str(p),'original':is_original,'sha256':h,'bytes':p.stat().st_size,'mtime_utc':datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat(),'matches_frozen':same})
for x in json.loads((root/'gui-qa/fixtures-read-originals.json').read_text()):check(x['original_read'],x['copy'],x['sha256'])
for x in json.loads(Path('/tmp/forgecad-fix-fixtures/manifest.json').read_text()):check('/home/myungit/Documenti/File_Esempio/'+x['name'],'/tmp/forgecad-fix-fixtures/'+x['name'],x['sha256'])
for src in (repo/'forgecad-release').rglob('CTestTestfile.cmake'):
 copy=root/'ctest'/src.relative_to(repo/'forgecad-release');assert copy.read_text()==src.read_text().replace('FORGECAD_EXAMPLE_DIR=/home/myungit/Documenti/File_Esempio','FORGECAD_EXAMPLE_DIR=/tmp/forgecad-fix-fixtures')
for x in json.loads((root/'final-metadata.json').read_text())['sources']:
 assert hashlib.sha256((repo/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
result={'files':r,'all_originals_match':all(x['matches_frozen'] for x in r if x['original']),'ctest_manifests_preserved':True,'source_hashes_match':True};(root/'fixtures-final.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS5frozenCADs,5originals match:',result['all_originals_match'],'; CTest manifests and35sourcehashes match')
