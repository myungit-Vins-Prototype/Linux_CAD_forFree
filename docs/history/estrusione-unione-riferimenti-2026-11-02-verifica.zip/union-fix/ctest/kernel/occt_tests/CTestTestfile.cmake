# CMake generated Testfile for 
# Source directory: /home/myungit/Linux_CAD_forFree/kernel/occt_tests
# Build directory: /home/myungit/Linux_CAD_forFree/forgecad-release/kernel/occt_tests
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("forgekernel_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_tests")
set_tests_properties("forgekernel_tests" PROPERTIES  _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/occt_tests/CMakeLists.txt;102;add_test;/home/myungit/Linux_CAD_forFree/kernel/occt_tests/CMakeLists.txt;0;")
