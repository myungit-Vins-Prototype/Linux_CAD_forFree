from pathlib import Path
import json,shlex,subprocess,hashlib
build=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');out=Path('/tmp/forgecad-union-fix/gui-qa');commands=json.loads((build/'compile_commands.json').read_text());types=Path('/home/myungit/Linux_CAD_forFree/cad_types.h');types_hash=hashlib.sha256(types.read_bytes()).hexdigest()
def compile(source,unit,name):
 c=next(c for c in commands if c['file'].endswith('/'+unit));a=shlex.split(c['command']);a[a.index('-o')+1]=str(out/name);a[-1]=str(out/source);a=['-O0' if x=='-O3' else x for x in a];subprocess.run(a,cwd=build,check=True)
compile('cache-probe.cpp','tests/test_viewport.cpp','cache-probe.o')
compile('viewport_document.unchanged-patched.cpp','forgeCad2026_viewport_document.cpp','viewport_document.unchanged-patched.o')
assert hashlib.sha256(types.read_bytes()).hexdigest()==types_hash,'cad_types changed during targeted compilation; wait for full build'
for patched,name in [(False,'cache-probe-baseline'),(True,'cache-probe-patched')]:
 a=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(out/name)
 for i,x in enumerate(a):
  if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(out/'cache-probe.o')
  elif patched and x=='CMakeFiles/forgecad_view_tests.dir/forgeCad2026_viewport_document.cpp.o':a[i]=str(out/'viewport_document.unchanged-patched.o')
  elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(out/(name+'.d'))
 subprocess.run(a,cwd=build,check=True)
