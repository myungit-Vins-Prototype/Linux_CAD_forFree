#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include <QTemporaryDir>
#include <iostream>
#include <stdexcept>
static void require(bool ok,const char*message){if(!ok)throw std::runtime_error(message);}
class ViewportInteractionTest {public:
#include "/tmp/forgecad-union-fix/gui-qa/test_next_body_union_cache.h"
};
int main(int argc,char**argv){QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADUnionCacheProbe");QCoreApplication::setApplicationName("GUI");QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());try{ViewportInteractionTest::nextBodyUnionCacheRegressions();}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
