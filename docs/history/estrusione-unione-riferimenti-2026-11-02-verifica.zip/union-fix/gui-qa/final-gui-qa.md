# QA GUI finale: unione fino al prossimo corpo e riferimenti esatti

Verifica del 2 novembre 2026, conclusa dopo la build definitiva comprendente il delta codec di `cad_constraints.cpp`. **14 scenari finali superati: 12 per l'unione e 2 per i riferimenti.** I risultati precedenti e i loro FAIL rimangono documentati nell'[indagine iniziale](/tmp/forgecad-union-fix/gui-qa/gui-investigation.md); questo rapporto sostituisce le sue sezioni «da eseguire» e «in corso».

## Build e metodo

Le due sonde sono state ricompilate e collegate a tutti gli oggetti di produzione aggiornati del runner `forgecad_view_tests`, sostituendo esclusivamente il suo main test. Nessun oggetto `fixed` delle prove preliminari è stato usato. L'elenco dei 100 oggetti/librerie statiche realmente collegati, con percorso e SHA256, è in [final-production-objects.json](/tmp/forgecad-union-fix/gui-qa/final-production-objects.json); gli hash sono stati nuovamente verificati dopo le esecuzioni.

Sorgenti e comandi delle sonde:

- [union-gui-final.cpp](/tmp/forgecad-union-fix/gui-qa/union-gui-final.cpp), [build-union-gui-final.py](/tmp/forgecad-union-fix/gui-qa/build-union-gui-final.py), [argomenti esatti di link](/tmp/forgecad-union-fix/gui-qa/union-gui-final-link.json).
- [reference-gui-final.cpp](/tmp/forgecad-union-fix/gui-qa/reference-gui-final.cpp), [build-reference-gui-final.py](/tmp/forgecad-union-fix/gui-qa/build-reference-gui-final.py), [argomenti esatti di link](/tmp/forgecad-union-fix/gui-qa/reference-gui-final-link.json).

Le sonde usano QMainWindow/CadViewport, impostazioni temporanee isolate, pannelli di produzione e documenti copiati in `/tmp`. Non istanziano PdfWindow, recovery o autosave e scrivono soltanto i percorsi dimostrativi espliciti in questa cartella. Non è stato chiuso alcun processo utente. Durante questa fase non sono stati modificati sorgenti del prodotto; la precedente patch contestuale di `unchangedFeature` era stata consegnata al coordinatore e integrata da lui.

## Unione: 12/12 PASS

| Scenario sul file attuale | Offscreen | Wayland | XCB |
| --- | --- | --- | --- |
| Nuova Estrusione18, Unisci automatico | PASS | PASS | PASS |
| Nuova Estrusione18, Unisci manuale a Corpo1 | PASS | PASS | PASS |
| Modifica Estrusione18 salvata, automatico | PASS | PASS | PASS |
| Modifica Estrusione18 salvata, manuale | PASS | PASS | PASS |

Ogni caso riparte dalla copia congelata del file attuale. Il pannello reale usa **Fino al prossimo corpo**, direzione **Invertito**, risultato **Unisci ai solidi**; il target è Corpo1/Svuota1, indice16. Sono esercitati anteprima, Conferma, Undo/Redo, salvataggio e riapertura. La modifica automatica parte proprio dalla vecchia definizione con `mergeBodies` vuoto e cache del prisma separato: anteprima e Conferma ora la ricalcolano.

Il risultato è un solido connesso, **23 facce e una shell**. Il volume misurato è `23653.784843978`; la somma indipendente dei volumi iniziali è `21305.81581933 + 2347.9690226117 = 23653.784841942`, con residuo `2.0361658243928e-06`, entro il controllo relativo `1e-8`. Il calcolo di massa viene riutilizzato solo quando l'intera serializzazione `writeBodyBinary` è byte per byte identica a una B-rep già misurata; il log dichiara questo riuso.

Il target16 è persistito in `mergeBodies` anche in automatico. La sua B-rep rimane invariata ed è consumata nella visualizzazione; viene disegnato soltanto il nuovo solido fuso. Undo/Redo ripristinano esattamente geometria e consumo; Undo della modifica recupera anche il vecchio prisma salvato. Codec e riapertura conservano B-rep fusa e relazione col target.

Log finali: [offscreen](/tmp/forgecad-union-fix/gui-qa/final-union-offscreen.log), [Wayland](/tmp/forgecad-union-fix/gui-qa/final-union-wayland.log), [XCB](/tmp/forgecad-union-fix/gui-qa/final-union-xcb.log). Catture in cartelle con lo stesso nome senza `.log`; ispezionati pannelli, anteprime e solidi confermati. [Esempio confermato XCB](/tmp/forgecad-union-fix/gui-qa/final-union-xcb/edit-saved18-auto-confirmed.png).

Il vecchio file minuscolo `superifici.prt` è una fixture distinta: l'indagine iniziale riproduce l'errore del limite che attraversa il piano iniziale. I 12 PASS finali qui sopra riguardano il file attuale `Superfici.prt`; non attestano la correzione di quel diverso caso storico.

## Riferimenti esatti: 2/2 PASS nativi

| Backend | Esito | OpenGL reale |
| --- | --- | --- |
| Wayland | PASS | Intel UHD Graphics P630, Mesa 4.6 Core / Mesa26.2.5-arch3.1 |
| XCB | PASS | Quadro RTX3000, NVIDIA3.3.0 /615.78.08 |

La fixture genera due rami impliciti da due schizzi su piani differenti. Nell'editor reale di un terzo schizzo YZ, **Converti bordi** seleziona con un click il ramo1 e crea un riferimento associativo esplicito di costruzione: `Converted`, grado0, geometria esatta transiente e identità stabile di ramo. Non viene costruita una curva adattata. Sono verificati:

- Undo/Redo della conversione; cache automatica nascosta dell'altro ramo presente, distinta dal riferimento esplicito. Le cache nascoste restano disponibili ai vincoli come previsto dal prodotto. Isolando realmente le sorgenti nel viewport, viene disegnato soltanto il riferimento esplicito tratteggiato: [cattura Wayland](/tmp/forgecad-union-fix/gui-qa/final-reference-wayland/explicit-reference-only-hidden-cache-absent.png).
- Creazione del punto e selezione punto/riferimento tramite eventi mouse reali, vincolo **PointOnCurve**, quota **Distanza** e snap sulla curva esatta. Per la quota viene preparata la selezione punto/origine attraverso lo stato del viewport, poi invocato il comando frontend `addConstraint`; non è una prova di ogni gesto del comando quota. [Cattura XCB](/tmp/forgecad-union-fix/gui-qa/final-reference-xcb/point-on-curve-dimension-snap.png).
- Modifica del controllo interno di ciascuno dei due input mantenendo fermi gli estremi, propagazione al riferimento e Undo/Redo. Le modifiche sono applicate dalla sonda attraverso la storia e i metodi di modifica dello schizzo del viewport, senza simulare il trascinamento del polo. Su 21 campioni, l'errore dell'immagine affine esatta è zero nei log; i vincoli risolvono entro `1e-7`. La precedente istanza condivisa della curva rimane immutabile.
- Riordino dei rami: la chiave persistente continua a individuare lo stesso ramo quando l'indice passa da 1 a 0; Undo/Redo conservano l'associazione.
- **Pierce** nel quarto schizzo sul piano X=1, mediante selezione reale della curva3D. Il punto rispetta il piano e la curva esatta, errore inferiore a `1e-8`; Undo/Redo e codec lo conservano.
- Salvataggio e riapertura con cache B-rep presente e assente. Già nel solo decode, prima della rigenerazione del puntatore transiente, sono conservati **esattamente due vincoli: PointOnCurve e Distanza**. Dopo load il riferimento si risolve nuovamente sul ramo corretto; restano entrambi i vincoli, Pierce e la distinzione di visibilità. [Riapertura XCB](/tmp/forgecad-union-fix/gui-qa/final-reference-xcb/reopened-with-cache.png).

Log finali: [Wayland](/tmp/forgecad-union-fix/gui-qa/final-reference-wayland.log), [XCB](/tmp/forgecad-union-fix/gui-qa/final-reference-xcb.log). Entrambi riportano `constraints=2` a ogni fase, nomi dei due tipi dopo decode/load e il PASS finale. Tutte le catture verificano un contesto valido e `GL_NO_ERROR`. Le prove offscreen dell'unione non sono usate come evidenza di rendering.

## Diagnostici mantenuti separati

La QA nativa ha individuato un **bug reale del decoder**, corretto prima delle esecuzioni finali: la classificazione `Shape::None` del marcatore procedurale senza puntatore transiente faceva scartare PointOnCurve durante la migrazione dei vincoli. Il delta mantiene la categoria strutturale Curve; la geometria resta vuota e il solver rifiuta ancora il riferimento non rigenerato. [Log del difetto prima del fix](/tmp/forgecad-union-fix/gui-qa/reference-codec-failure-before-fix.log).

Due FAIL preliminari appartenevano invece alle sonde: la nuova creazione riutilizzava erroneamente una definizione decodificata con la vecchia cache; un'altra precondizione vietava erroneamente alle cache nascoste di partecipare ai vincoli. Sono conservati con causa in [union-probe-initial-diagnostics.log](/tmp/forgecad-union-fix/gui-qa/union-probe-initial-diagnostics.log) e [reference-probe-initial-diagnostics.log](/tmp/forgecad-union-fix/gui-qa/reference-probe-initial-diagnostics.log). Le correzioni delle sonde riproducono il percorso effettivo senza indebolire gli assert su geometria, rendering, associazioni e vincoli.

## Originali e copie dimostrative

Gli originali sono stati **realmente letti e calcolati nuovamente** al termine delle prove, il 2 novembre alle 17:46 UTC; entrambi corrispondono alla lettura iniziale di questo intervento. Non si tratta soltanto di un confronto delle copie congelate. [Manifesto iniziale](/tmp/forgecad-union-fix/gui-qa/fixtures-read-originals.json), [verifica finale](/tmp/forgecad-union-fix/gui-qa/originals-read-status-after-final-qa.json).

| Originale letto | Byte | SHA256 |
| --- | --- | --- |
| `/home/myungit/Documenti/File_Esempio/superifici.prt` |634171| `ddc692e4f44fc05ce8c72c0febf798878e78af17dd08b82fb8f8b338d323e6da` |
| `/home/myungit/Documenti/File_Esempio/Superfici.prt` |16074185| `56779a6c668258e54d686a9f1e721de03acbea84a2c16d642e1083d364203adf` |

Questa verifica riguarda l'intervallo dell'intervento attuale. La precedente differenza tra l'originale attuale e il vecchio congelato `c566…` resta un evento distinto, senza attribuzione di autore.

Copie dimostrative create soltanto in `/tmp`:

- [Superfici-unione-fino-corpo.prt](/tmp/forgecad-union-fix/gui-qa/Superfici-unione-fino-corpo.prt), derivata dalla modifica automatica XCB della Estrusione18: 16166828 byte, SHA256 `330427a1bf5339fd750ccc41915d1100fae9ae97e50acd8d02634ae25debdaeb`.
- [Curva-proiettata-riferimento-esatto.prt](/tmp/forgecad-union-fix/gui-qa/Curva-proiettata-riferimento-esatto.prt), riferimento esplicito, cache nascosta, PointOnCurve+Distanza e Pierce: 1575 byte, SHA256 `b4e124e2cda7c835d73177f9e11fe4d50b150cc455ac721e18a8b4b9d71a3099`.

## Identità degli artefatti finali

SHA256 e dimensioni completi in [final-artifacts.json](/tmp/forgecad-union-fix/gui-qa/final-artifacts.json):

| Artefatto | SHA256 |
| --- | --- |
| App `forgecad` | `1725da8a957cdf8a5546ab0cff12075d97981b81b55cbcac13bf4f128bf2fb0d` |
| Runner `forgecad_view_tests` | `1b03c541ed4bfb8dbee50e16a7e18924c3abce6d16b8f3d02f4521150e69e427` |
| `libforgekernel.a` | `992d70d5e5a3e4f80570cc1548e6e0c956e9a0bcc9672e6849a200be116079fe` |
| Sonda unione | `af8a9c0ccaf83562c3f524a225d71f30fcf88d5314e68cb0756c1db9a5a56e78` |
| Sonda riferimenti | `884c05b1c81337e137a7b1277da892dee3dd18dd933a54446bb1138b9d2c3745` |

La suite CTest completa, le prove kernel e la mappa architetturale sono gestite dal coordinatore e non sono conteggiate nei 14 scenari di questo rapporto. Queste sonde verificano i percorsi e le fixture descritti; i confronti campionati e le catture non sostituiscono le verifiche analitiche e topologiche del kernel.
