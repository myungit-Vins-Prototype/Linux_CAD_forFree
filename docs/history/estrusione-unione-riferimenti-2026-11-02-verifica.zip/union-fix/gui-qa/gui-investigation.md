# Indagine GUI: estrusione fino al prossimo corpo e unione

Lettura di AGENTS.md e CLAUDE.md aggiornata. Nessun sorgente prodotto modificato: il pannello consente la scelta corretta. Le sonde e i rapporti sono isolati in questa cartella; la memoria centrale resta al coordinatore.

## Provenienza delle copie

Questa volta gli hash sono stati calcolati sui byte **realmente letti dai due originali** e poi copiati:

| Originale letto | Copia isolata | Dimensione | SHA256 |
| --- | --- | --- | --- |
| `/home/myungit/Documenti/File_Esempio/superifici.prt` | `fixtures/superifici-old.prt` | 634171 | `ddc692e4f44fc05ce8c72c0febf798878e78af17dd08b82fb8f8b338d323e6da` |
| `/home/myungit/Documenti/File_Esempio/Superfici.prt` | `fixtures/Superfici-current.prt` | 16074185 | `56779a6c668258e54d686a9f1e721de03acbea84a2c16d642e1083d364203adf` |

Manifesto con percorso originale, copia, hash, dimensioni, mtime e ora UTC della lettura: `fixtures-read-originals.json`. I successivi risultati si riferiscono alle copie con questi hash, senza inferire che gli originali aperti nell'app restino immutati. SHA iniziale dei sorgenti pertinenti in `source-baseline.json`.

## Riproduzione Qt offscreen prima del fix

Sonda `union-gui-probe`, collegata agli oggetti correnti di `forgecad-release`; argomenti di link in `link.json`. Non istanzia PdfWindow, recovery o callback di salvataggio e non salva documenti. Usa QMainWindow/CadViewport, carica soltanto le copie, apre il pannello reale e invia Conferma; ogni caso riparte dal documento congelato.

Nel pannello **Risultato resta abilitato** con extent4. Selezionando Unisci ai solidi, il controllo Automatico e la lista dei corpi sono visibili. Con Automatico attivo la lista è disabilitata, secondo il comportamento previsto; disattivandolo si abilita e il target si spunta correttamente. Nessuna patch GUI richiesta.

### File attuale: Estrusione18, indice17; Corpo1/Svuota1, indice16

La definizione già salvata ha extent4, distance=-1, operation=-1, firstBody=-1, booleanTools={16}, mergeOperation=1, mergeAuto=true e mergeBodies vuoto.

- **Automatico:** anteprima e Conferma riescono ma restituiscono il solo prisma, 5 facce, una shell, volume2347.97. Corpo1 resta visibile. Il callback grezzo ha operation=-1, firstBody=-1, booleanTools={16}, mergeOperation=1, mergeAuto=true, mergeProbe=false, mergeBodies vuoto. `withMergeCandidates` prepara mergeProbe=true e mergeBodies={16}; il controllo di contatto nel calcolo scarta poi il target.
- **Manuale, Corpo1 spuntato:** anteprima e Conferma falliscono con `Fusione con i corpi non riuscita: intersectSurfaces: suddivisione per i semi troppo profonda`. Callback grezzo e preparato: operation=-1, firstBody=-1, booleanTools={16}, mergeOperation=1, mergeAuto=false, mergeProbe=false, mergeBodies={16}. Il documento in memoria resta quello precedente, senza consumo della base.

Log integrale `current-offscreen.log`; catture dei pannelli `current-offscreen/`.

### File vecchio: Estrusione8, indice7; target storico indice4

La definizione salvata è extent3, distance=-1.73362, mergeOperation=2 e mergeAuto=false, mergeBodies={4}.

- Con extent3 e Unisci automatico, anteprima e Conferma restituiscono il solo prisma, 6 facce, una shell, volume0.433405. `withMergeCandidates` include {4,6}, poi nessun target viene fuso.
- Con extent3 e target4 manuale, anteprima e Conferma falliscono: `Fusione con i corpi non riuscita: booleanOperation: risultato non valido (edge lontano dalla superficie: edge 2: fino a 8.65623512451e-07 dalla superficie della faccia 7)`.
- Passando a extent4, sia automatico sia manuale falliscono già nel calcolo del limite: `Un corpo limite attraversa il piano iniziale del profilo.` Questo è distinto dal difetto dell'unione sul modello attuale.

Log integrale `old-offscreen.log`; catture `old-offscreen/`.

## QA finale predisposta, ancora da eseguire

`union-gui-final.cpp` compila come sonda dedicata. Quattro casi sul file attuale: nuova creazione e modifica della Estrusione18 salvata, ciascuna con Unisci automatico e manuale. Verifica pannello e anteprima, Conferma, un solo solido connesso, volume somma di scocca e prisma, target16 persistito e consumato, Undo/Redo esatti, codec e riapertura. La modifica automatica esercita anche il riuso della vecchia cache apparentemente invariata, che non deve conservare il prisma separato salvato prima del fix.

Prove grafiche Wayland/XCB e riferimento esatto della curva proiettata in un altro schizzo da eseguire dopo la build definitiva coordinata. Controlli campionati e rendering non sostituiscono le verifiche analitiche/topologiche del kernel.

## Correzione mirata del riuso della cache

Su incarico successivo del coordinatore, preparata una patch **solo per unchangedFeature** di `forgeCad2026_viewport_document.cpp`, senza scrivere nel checkout. Disgiunta dalla funzione `refreshSurfacePierceSketches` posseduta dall'agente dei riferimenti. Patch contestuale: `unchanged-feature.patch`; SHA della baseline in `unchanged-feature-baseline.json`.

Causa raggiungibile: `requestPreview` e `updateBody` interrogano unchangedFeature. Il metodo normalizza i target automatici sostituendoli con quelli esistenti prima di confrontare la chiave, quindi una vecchia unione extent4 con mergeBodies vuoto viene considerata invariata e conserva la geometria separata salvata, anche dopo la correzione del core.

La guardia proposta riguarda solo una Extrusion extent4, operation<0, mergeOperation=1, mergeAuto=true, mergeBodies vuoto, con almeno un limite booleanTools che è tuttora candidato alla fusione. In quel caso restituisce false e anteprima/conferma ricalcolano. Dopo un'unione riuscita il target persistito disattiva la guardia. Nessuna misura sul display, nessun fit, nessuna modifica di tolleranza o invalidazione globale.

Differenziale su fixture sintetica riproducibile e oggetti attuali:

- `cache-probe-baseline.log`: **FAIL** sul riuso improprio del vecchio prisma.
- `cache-probe-patched.log`: **PASS**, sostituendo soltanto l'oggetto viewport_document compilato dalla patch.

Regressione proposta `test_next_body_union_cache.h`, metodo `nextBodyUnionCacheRegressions()`: controlla chiamata normalizzata e grezza sul vecchio prisma, e preserva il riuso per unione già associata, Corpo nuovo, extent0 e assenza di candidati correnti. Nessuna app definitiva aggiornata da questa compilazione mirata.

Il primo loadDocument conserva ancora la cache tramite buildBody/usedSnapshot. La correzione ne permette il ricalcolo aprendo l'anteprima o confermando/modificando la feature, soddisfacendo il percorso richiesto senza azzerare indiscriminatamente cachedGeometry. Verifica integrata con il nuovo kernel e il nuovo layout CurveObject ancora da eseguire dopo build completa.

## QA integrata in corso: perdita di PointOnCurve nel decoder

Con oggetti tutti ricompilati per la nuova ABI, la QA nativa della conversione esatta è arrivata a conversione reale del ramo scelto, cache nascosta, snap, PointOnCurve e quota, modifiche interne di entrambi gli input con estremi fermi, Undo/Redo, riordino dei rami e Pierce. La geometria e i due vincoli del target2 restano corretti fino al salvataggio. Già nel solo decode, prima di loadDocument, restava però soltanto Distanza: PointOnCurve veniva perso.

Riproduzione minima raggiunta dalla sonda: target YZ con Converted0 esplicita del ramo1, Converted0 nascosta del ramo0, punto2 con PointOnCurve+Distance; saveDocumentFile seguito da loadDocumentFile. Log preservato `reference-codec-failure-before-fix.log`: prima codec2 vincoli; decode3 curve/2 link/1 vincolo Distanza; load conserva il solo Distanza.

Causa confermata insieme all'agente projected_curve: `read(SketchObject)` chiama migrateLegacyConstraints, che elimina i vincoli non wellFormed. La nuova shapeOf classificava come None il marcatore Converted0 privo della cache referenceCurve transiente, quindi eliminava prematuramente PointOnCurve. Il riferimento deve conservare la categoria strutturale Curve fino alla rigenerazione; il solver deve continuare a rifiutare la cache non risolta senza inventare geometria. Fix/regressione affidati all'agente dei riferimenti e al coordinatore. Nessuna modifica locale del prodotto da parte dell'agente GUI.

Un altro precedente FAIL riguardava soltanto una precondizione errata della sonda: il codice documenta esplicitamente che le cache nascoste restano disponibili ai vincoli, con priorità per la geometria visibile. Il test ora verifica la distinzione di rendering e la scelta dell'entità esplicita, senza vietare il comportamento deliberato. Log e causa in `reference-probe-initial-diagnostics.log`.

Il primo FAIL della sonda unione era pure una fixture errata: copiava una definizione appena decodificata per la nuova creazione, trattenendo cachedGeometry=true e il vecchio prisma. La creazione UI reale usa una definizione nuova. La sonda finale riproduce questa distinzione e usa la definizione post-load per la modifica. Log e causa in `union-probe-initial-diagnostics.log`.
