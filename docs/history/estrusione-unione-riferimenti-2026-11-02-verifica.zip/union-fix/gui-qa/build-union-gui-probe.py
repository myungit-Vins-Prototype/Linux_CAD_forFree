from pathlib import Path
import json,shlex,subprocess
build=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');out=Path('/tmp/forgecad-union-fix/gui-qa');name='union-gui-probe'
c=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/tests/test_viewport.cpp'));args=shlex.split(c['command']);args[args.index('-o')+1]=str(out/(name+'.o'));args[-1]=str(out/(name+'.cpp'));args=['-O0' if a=='-O3' else a for a in args];subprocess.run(args,cwd=build,check=True)
args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());args[args.index('-o')+1]=str(out/name)
for i,a in enumerate(args):
 if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':args[i]=str(out/(name+'.o'))
 elif a.startswith('-Wl,--dependency-file='):args[i]='-Wl,--dependency-file='+str(out/(name+'.d'))
(out/'link.json').write_text(json.dumps({'cwd':str(build),'argv':args},indent=2)+'\n');subprocess.run(args,cwd=build,check=True)
