from pathlib import Path
import json,shlex,subprocess,sys
build=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');out=Path('/tmp/forgecad-union-fix/gui-qa');name='union-gui-final'
c=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/tests/test_viewport.cpp'));a=shlex.split(c['command']);a[a.index('-o')+1]=str(out/(name+'.o'));a[-1]=str(out/(name+'.cpp'));a=['-O0' if x=='-O3' else x for x in a];subprocess.run(a,cwd=build,check=True)
if '--compile-only' not in sys.argv:
 a=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(out/name)
 for i,x in enumerate(a):
  if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(out/(name+'.o'))
  elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(out/(name+'.d'))
 (out/(name+'-link.json')).write_text(json.dumps({'cwd':str(build),'argv':a},indent=2)+'\n');subprocess.run(a,cwd=build,check=True)
