from pathlib import Path
repo=Path('/home/myungit/Linux_CAD_forFree');out=Path('/tmp/forgecad-union-fix')
helper=r'''
using SurfaceWindow = std::pair<Interval,Interval>;
BSplineSurface clippedPatchDirection(const BSplineSurface &patch,bool alongU,Interval range) {
    const int lines=alongU?patch.vPoleCount():patch.uPoleCount(),degree=alongU?patch.uDegree():patch.vDegree();
    const auto &knots=alongU?patch.uKnots():patch.vKnots();
    std::vector<BSplineCurve<3>> curves;
    for(int line=0;line<lines;++line){
        cancellationPoint();std::vector<Vec3> poles;std::vector<double> weights;
        for(int k=0;k<(alongU?patch.uPoleCount():patch.vPoleCount());++k){poles.push_back(patch.pole(alongU?k:line,alongU?line:k));weights.push_back(patch.weight(alongU?k:line,alongU?line:k));}
        const auto pieces=rationalBezierPieces(BSplineCurve<3>(degree,knots,poles,weights),range);
        if(pieces.size()!=1)throw std::logic_error("clippedPatchDirection: expected one Bezier piece");
        curves.push_back(pieces.front());
    }
    const int nu=alongU?curves.front().poleCount():patch.uPoleCount(),nv=alongU?patch.vPoleCount():curves.front().poleCount();
    std::vector<Vec3> poles(nu*nv);std::vector<double> weights(nu*nv);
    for(int i=0;i<nu;++i)for(int j=0;j<nv;++j){const auto &c=curves[alongU?j:i];const int k=alongU?i:j;poles[i*nv+j]=c.poles()[k];weights[i*nv+j]=c.weight(k);}
    if(!patch.isRational())weights.clear();
    return BSplineSurface(patch.uDegree(),patch.vDegree(),alongU?curves.front().knots():patch.uKnots(),alongU?patch.vKnots():curves.front().knots(),nu,nv,std::move(poles),std::move(weights));
}
std::vector<BSplineSurface> clippedSeedPatches(const Surface &surface,Interval u,Interval v,const SurfaceWindow *window){
    auto pieces=toBSplineSurface(surface,u,v).bezierPatches();
    if(!window || surface.type()!=SurfaceType::BSpline)return pieces;
    std::vector<BSplineSurface> result;
    for(auto &patch:pieces){
        cancellationPoint();const auto pu=patch.uDomain(),pv=patch.vDomain();
        const Interval cu{std::max(pu.lo,window->first.lo),std::min(pu.hi,window->first.hi)},cv{std::max(pv.lo,window->second.lo),std::min(pv.hi,window->second.hi)};
        if(!(cu.hi>cu.lo)||!(cv.hi>cv.lo))continue;
        if(cu.lo!=pu.lo||cu.hi!=pu.hi)patch=clippedPatchDirection(patch,true,cu);
        if(cv.lo!=pv.lo||cv.hi!=pv.hi)patch=clippedPatchDirection(patch,false,cv);
        result.push_back(std::move(patch));
    }return result;
}
'''
s=(repo/'kernel/fk_marching.cpp').read_text();needle='void subdivisionSeeds(const Surface &a, const Surface &b, const Box &bounds, double tolerance, std::vector<Vec3> &seeds) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\nvoid subdivisionSeeds(const Surface &a, const Surface &b, const Box &bounds, double tolerance, std::vector<Vec3> &seeds,const SurfaceWindow *windows) {')
s=s.replace('const std::vector<BSplineSurface> patchesA = toBSplineSurface(a, ua, va).bezierPatches();','const std::vector<BSplineSurface> patchesA = clippedSeedPatches(a,ua,va,windows?&windows[0]:nullptr);').replace('const std::vector<BSplineSurface> patchesB = toBSplineSurface(b, ub, vb).bezierPatches();','const std::vector<BSplineSurface> patchesB = clippedSeedPatches(b,ub,vb,windows?&windows[1]:nullptr);')
needle='SurfaceIntersection intersectSurfaces(const Surface &a, const Surface &b, const Box &bounds, const std::vector<Vec3> &seeds,\n                                      const SurfaceIntersectionOptions &options) {';assert s.count(needle)==1;s=s.replace(needle,'SurfaceIntersection intersectSurfacesImpl(const Surface &a, const Surface &b, const Box &bounds, const std::vector<Vec3> &seeds,\n                                      const SurfaceIntersectionOptions &options,const SurfaceWindow *windows) {');s=s.replace('subdivisionSeeds(a, b, bounds, options.tolerance, all);','subdivisionSeeds(a, b, bounds, options.tolerance, all,windows);')
pos=s.rfind('\n}');s=s[:pos]+r'''
SurfaceIntersection intersectSurfaces(const Surface&a,const Surface&b,const Box&bounds,const std::vector<Vec3>&seeds,const SurfaceIntersectionOptions&options){return intersectSurfacesImpl(a,b,bounds,seeds,options,nullptr);}
SurfaceIntersection intersectSurfacesOnFaces(const Surface&a,const Surface&b,const Box&bounds,const std::vector<Vec3>&seeds,const SurfaceWindow&wa,const SurfaceWindow&wb,const SurfaceIntersectionOptions&options){const SurfaceWindow windows[]={wa,wb};return intersectSurfacesImpl(a,b,bounds,seeds,options,windows);}
'''+s[pos:];(out/'fk_marching_bounded.cpp').write_text(s)
s=(repo/'kernel/fk_boolean.cpp').read_text();s='#include <cstdio>\n'+s;s=s.replace('namespace ForgeCad::Kernel {','namespace ForgeCad::Kernel {\nstd::pair<Interval,Interval> faceParameterBounds(const Body &,FaceId);\nSurfaceIntersection intersectSurfacesOnFaces(const Surface&,const Surface&,const Box&,const std::vector<Vec3>&,const std::pair<Interval,Interval>&,const std::pair<Interval,Interval>&,const SurfaceIntersectionOptions&);',1)
needle='const SurfaceIntersection intersection = intersectSurfaces(surfaceA, surfaceB, commonBounds(fa, fb), crossings, options);';s=s.replace(needle,'std::fprintf(stderr,"BOUNDEDPAIR %d %d\\n",fa.index,fb.index);\n    const SurfaceIntersection intersection = intersectSurfacesOnFaces(surfaceA,surfaceB,commonBounds(fa,fb),crossings,faceParameterBounds(bodies_[0],fa),faceParameterBounds(bodies_[1],fb),options);\n    std::fprintf(stderr,"DONEPAIR %d %d\\n",fa.index,fb.index);');(out/'fk_boolean_bounded.cpp').write_text(s)
