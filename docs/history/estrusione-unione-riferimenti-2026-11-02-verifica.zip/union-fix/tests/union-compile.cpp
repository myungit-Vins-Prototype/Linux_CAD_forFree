#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "cad_extrude.h"
#include "cad_element_names.h"
#include "fk_mass.h"
#include "fk_body_check.h"
#include "fk_primitives.h"
#include <iostream>
#include <stdexcept>
static void require(bool condition,const char *message){if(!condition)throw std::runtime_error(message);}
class ViewportInteractionTest {public:
#include "test_next_body_union.h"
};
int main(int argc,char **argv){QApplication app(argc,argv);ViewportInteractionTest::nextBodyUnionRegressions();return 0;}
