from pathlib import Path
import json
repo=Path('/home/myungit/Linux_CAD_forFree');g=json.loads((repo/'docs/architecture/graph.json').read_text());assert not g['analysis']['errors']
checks=[('cad_extrude.cpp','kernel/fk_boolean.cpp','uniteDisjointBodies'),('kernel/fk_boolean.cpp','kernel/fk_surface_algo.cpp','sameSurfaceParameterization'),('cad_document_io.cpp','cad_constraints.cpp','migrateLegacyConstraints'),('forgeCad2026_viewport_document.cpp','cad_sketch_refs.cpp','refreshCurvePierce'),('forgeCad2026_viewport_sketch.cpp','cad_sketch_refs.cpp','refreshCurvePierce'),('kernel/fk_curve_ops.cpp','kernel/fk_sketch_projection.cpp','embedSketchProjectionImage'),('cad_projected_curve.cpp','kernel/fk_sketch_projection.cpp','projectSketchOnSketch'),('tests/test_projected_curve_references.h','cad_datum.cpp','bodyCurveForReference')]
r={'files':len(g['nodes']),'edges':len(g['edges']),'units':len(g['analysis']['units']),'errors':g['analysis']['errors'],'boundaries':[],'directions':{}}
for source,target,symbol in checks:
 sites=[s for e in g['edges'] if e['source']==source and e['target']==target and e['kind']=='call' for s in e['sites'] if symbol in s['symbol']];assert sites,(source,target,symbol)
 r['boundaries'].append({'source':source,'target':target,'kind':'call','symbol':symbol,'sites':sites})
for n in ['cad_extrude.cpp','kernel/fk_boolean.cpp','kernel/fk_surface_algo.cpp','cad_sketch_refs.cpp','cad_datum.cpp','cad_constraints.cpp','cad_projected_curve.cpp','kernel/fk_sketch_projection.cpp','cad_document_io.cpp','cad_history_graph.cpp','tests/test_projected_curve_references.h']:
 assert any(x['id']==n for x in g['nodes']);r['directions'][n]={k:{'in':sum(e['count'] for e in g['edges'] if e['target']==n and e['kind']==k),'out':sum(e['count'] for e in g['edges'] if e['source']==n and e['kind']==k)} for k in ['call','include','reference']}
Path('/tmp/forgecad-union-fix/architecture-checked.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS:',r['files'],'files,',r['edges'],'relations,',r['units'],'AST units,',len(checks),'resolved call boundaries; incoming/outgoing call/include/reference recorded separately')
