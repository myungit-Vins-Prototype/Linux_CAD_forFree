from pathlib import Path
import json,xml.etree.ElementTree as ET,hashlib,re,subprocess
root=Path('/tmp/forgecad-union-fix');repo=Path('/home/myungit/Linux_CAD_forFree')
def read(name):
 tree=ET.parse(root/name).getroot();cases={}
 for c in tree.iter('testcase'):
  status='fail' if c.find('failure') is not None else ('skip' if c.find('skipped') is not None else 'pass')
  cases[c.attrib['name']]={'status':status,'time':c.attrib.get('time'),'phase':name}
 return cases
full=read('ctest-full.xml');app=read('ctest-app-final.xml');assert len(full)==163 and len(app)==151
assert set(app)=={x for x in full if x.startswith('forgecad_')}
assert all(v['status']!='fail' for v in app.values());result=dict(full);result.update(app)
counts={s:sum(x['status']==s for x in result.values()) for s in ['pass','skip','fail']};assert counts=={'pass':161,'skip':1,'fail':1},counts
assert {k for k,v in result.items() if v['status']=='fail'}=={'forgekernel_tests'}
metadata=json.loads((root/'final-metadata.json').read_text());before=json.loads((root/'before-codec-delta-metadata.json').read_text());k='forgecad-release/kernel/libforgekernel.a'
assert next(x['sha256'] for x in metadata['binaries'] if x['path']==k)==next(x['sha256'] for x in before['binaries'] if x['path']==k)
assert not subprocess.check_output(['git','diff','--','kernel/tests/test_draft.cpp'],cwd=repo)
for backend in ['offscreen','wayland','xcb']:
 log=(root/f'gui-qa/final-union-{backend}.log').read_text();assert len(re.findall(r'^PASS ',log,re.M))==4
for backend in ['wayland','xcb']:
 log=(root/f'gui-qa/final-reference-{backend}.log').read_text();assert 'PASS native exact references' in log and 'reopened maxReferenceError=0 constraints=2' in log
summary={'consolidated':counts,'full_before_last_codec_delta':{'counts':{s:sum(x['status']==s for x in full.values()) for s in counts},'seconds':566.53},'all_application_tests_after_codec':{'counts':{s:sum(x['status']==s for x in app.values()) for s in counts},'seconds':142.39},'kernel_unchanged_between_phases':True,'not_a_single_repeated_full_run_after_codec':True,'cases':result}
(root/'final-test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
results='''Build Release completa di app e runner: **PASS**, Linux GCC16.2.1 / Qt6.12.
I manifesti registrano gli hash dei 35 sorgenti/test e dei binari effettivi.
La prima integrazione del runner richiedeva l'include esplicito di
`cad_projected_curve.h`: corretto e ricompilato prima dei test comuni.

- Sette nuove regressioni CTest: **7/7 PASS**, anche dopo il delta codec.
  Comprendono quattro percorsi applicativi e tre suite kernel: 39 casi dei
  riferimenti esatti, 4 gruppi della parametrizzazione e 7 dell'unione disgiunta.
- Suite completa prima dell'ultimo delta codec: **161 PASS, 1 SKIP, 1 FAIL su163**,
  566,53s. Dopo il delta sono stati ripetuti **tutti i151 test applicativi**:
  **150 PASS, 1 SKIP, zero FAIL**,142,39s. I12 target kernel della prima fase
  restano riferiti alla stessa libreria, invariata byte per byte.
  Il consolidato finale è161 PASS/1 SKIP/1 FAIL; non è una seconda singola
  esecuzione completa dei163 test dopo il codec.
- Unico FAIL: quello preesistente `DraftCurvedAndConcaveSolids`,
  `kernel/tests/test_draft.cpp:134`:253,5270716475676 contro253,5270734420086,
  scarto1,7944410046766279e-6>1e-6, identico al checkpoint precedente.
  Kernel generale **457/458**; test e tolleranza invariati.
- Skip `forgecad_overlay_uniform_tests` per il contesto offscreen. La verifica
  GL avviene separatamente nelle sessioni native.
- QA unione: **12/12 PASS**, quattro casi creazione/modifica × auto/manuale
  su offscreen, Wayland e XCB;8 casi hanno contesto GL nativo.
  Anteprima, conferma, volume, singolo solido, consumo del destinatario,
  genealogia, Undo/Redo e codec verificati.
- QA riferimenti: **2/2 sessioni native PASS**, Wayland/Intel P630 Mesa e
  XCB/Quadro RTX3000 NVIDIA. Converti spigoli, cache nascosta/rendering,
  snap, PointOnCurve e quota, modifiche interne di entrambi gli input,
  riordino dei rami, Undo/Redo, Pierce su X=1, decode e riapertura con/senza
  cache. Entrambi i vincoli persistono; errore massimo dell'immagine affine
  su21 parametri:0. Catture ispezionate, nessun errore GL. Nessuna prova macOS.
- ASan/UBSan mirati PASS: unione7, parametrizzazione4, riferimenti39 e modulo,
  più regressione finale codec. I rapporti elencano esattamente i TU
  strumentati e i supporti non strumentati: nessuna build sanitizer dell'intera
  app attestata. LeakSanitizer escluso per incompatibilità ptrace; nessuna
  verifica delle perdite di memoria dichiarata.
- Originali realmente riletti a fine prove: entrambi i Superfici e i tre
  esempi CTest corrispondono ai rispettivi snapshot iniziali di questo
  intervento; cinque copie congelate intatte. Le sole modifiche ai manifesti
  CTest copiati riguardano `FORGECAD_EXAMPLE_DIR`, con proprietà e timeout conservati.

Mappa architetturale finale: **548 file,7571 relazioni,258 unità AST,zero errori**.
`--check` PASS; verificati8 confini di chiamata e, separatamente, entrate/uscite
call/include/reference dei moduli interessati. HTML reso e ispezionato su
`cad_extrude.cpp` e `cad_sketch_refs.cpp`. HTML e JSON generati restano locali
e ignorati da Git.

[Archivio delle evidenze](history/estrusione-unione-riferimenti-2026-11-02-verifica.zip):
log/JUnit distinti per fase, manifesti e hash, sonde e rapporti degli agenti,
confronto causale codec FAIL→PASS, sanitizer mirati, catture GUI e mappa,
verifiche degli originali. Prototipi, diagnosi preliminari e risultati finali
sono distinti; non contiene CAD originali o binari.
'''
s=(root/'report-draft.md').read_text();assert '<!-- FINAL_RESULTS -->' in s;s=s.replace('<!-- FINAL_RESULTS -->',results)
out=root/'delivery';(out/'docs').mkdir(parents=True,exist_ok=True);report='docs/estrusione-unione-riferimenti-proiettati-2026-11-02.md';(out/report).write_text(s.rstrip()+'\n')
p=repo/'CLAUDE.md';old=p.read_text();start=old.index('0. **02/11');end=old.index('\n1. **02/11',start)
entry='''0. **02/11 — Unione fino al corpo e riferimenti proiettati (verificato).**
   extent4 Unione auto/manuale usa contatti B-rep soltanto con prova fresca di interni disgiunti dagli
   stessi limiti; booleana generale invariata, SP-curve/UV esatti, cache vecchie ricalcolate alla conferma.
   Riferimenti impliciti associativi senza fit: quote, PointOnCurve e Pierce, chiavi di ramo, formato60.
   QA scopreva perdita PointOnCurve al decode: migrazione strutturale corretta, entrambi i vincoli
   preservati; geometria/solver restano in errore finche la cache non e' risolta. Nuovi7CTest PASS.
   App/runner PASS. Suite completa161PASS/1SKIP/1FAIL; dopo ultimo codec tutti151test app
   ripetuti150PASS/1SKIP/0FAIL, kernel invariato. UnicoFAIL sformo preesistente (kernel457/458).
   GUI unione12/12 (4offscreen+8native), riferimenti2/2 Wayland/XCB; UndoRedo/codec e sanitizer mirati PASS.
   Superfici corrente:23facce/1shell,23653,78484397822mm³; target16 fuso.5copie e5originali verificati intatti.
   Mappa548file/7571relazioni/258AST,0errori,check/HTML e8confini in/out PASS; generati ignorati.
   [Rapporto e archivio](docs/estrusione-unione-riferimenti-proiettati-2026-11-02.md) conservano fasi, hash,
   limiti; base317b8cb. Commit/push richiesti in preparazione.
'''
new=old[:start]+entry+old[end:];assert len(new.encode())<=16384,len(new.encode());(out/'CLAUDE.md').write_text(new)
manifest=[{'path':report,'before_sha256':None},{'path':'CLAUDE.md','before_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}];(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Verified consolidated:',counts,'; final app150PASS/1SKIP. Delivery staged, memory',len(new.encode()),'bytes')
