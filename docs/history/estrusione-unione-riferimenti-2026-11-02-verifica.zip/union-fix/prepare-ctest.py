from pathlib import Path
import json,hashlib,os
source=Path('/home/myungit/Linux_CAD_forFree/forgecad-release');out=Path('/tmp/forgecad-union-fix/ctest');manifest=[]
for src in source.rglob('CTestTestfile.cmake'):
 dst=out/src.relative_to(source);dst.parent.mkdir(parents=True,exist_ok=True)
 original=src.read_text();changed=original.replace('FORGECAD_EXAMPLE_DIR=/home/myungit/Documenti/File_Esempio','FORGECAD_EXAMPLE_DIR=/tmp/forgecad-fix-fixtures');dst.write_text(changed)
 assert dst.read_text()==original.replace('FORGECAD_EXAMPLE_DIR=/home/myungit/Documenti/File_Esempio','FORGECAD_EXAMPLE_DIR=/tmp/forgecad-fix-fixtures')
 manifest.append({'path':str(src.relative_to(source)),'original_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'copy_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for name in ['config','cache','runtime']:
 p=out/name;p.mkdir(exist_ok=True);p.chmod(0o700)
(out/'manifest.json').write_text(json.dumps({'only_change':'FORGECAD_EXAMPLE_DIR -> frozen copies','ctest_files':manifest},indent=2)+'\n');print(len(manifest),'CTest manifests prepared with original commands, properties and timeouts')
