from pathlib import Path
import json,shlex,subprocess
root=Path('/home/myungit/Linux_CAD_forFree');build=root/'forgecad-release';out=Path('/tmp/forgecad-reference-fix')
c=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/tests/test_viewport.cpp'))
a=shlex.split(c['command']);a[a.index('-o')+1]=str(out/'storyboard-reference-audit.o');a[-1]=str(out/'storyboard-reference-audit.cpp');a=['-O0' if x=='-O3' else x for x in a];subprocess.run(a,cwd=build,check=True)
a=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(out/'storyboard-reference-audit')
for i,x in enumerate(a):
 if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(out/'storyboard-reference-audit.o')
 elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(out/'storyboard-reference-audit.d')
subprocess.run(a,cwd=build,check=True)
