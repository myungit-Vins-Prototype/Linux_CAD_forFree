from pathlib import Path
import os,subprocess,shlex,datetime,json,platform
p=Path('/tmp/forgecad-reference-fix');repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release'
log=(p/'evidence.log').open('w',buffering=1)
def record(s):print(s,file=log,flush=True)
def run(cmd,env=None):
 record('COMMAND '+shlex.join([str(s) for s in cmd]));result=subprocess.run(cmd,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT);record('EXITCODE '+str(result.returncode));
 if result.returncode:raise SystemExit(result.returncode)
record('UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat());record('PLATFORM '+platform.platform());record('SNAPSHOT manifest.json; production unchanged since freeze')
record('ENV QT_QPA_PLATFORM=offscreen; ASAN_OPTIONS=detect_leaks=0:halt_on_error=1; UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1')
run(['/usr/bin/c++','--version'])
run([str(p/'kernel39')]);run([str(p/'kernel21')]);run([str(p/'module-probe')])
# Targeted sanitizers. Support application objects are coherent ABI but uninstrumented.
units=['module_probe','cad_projected_curve','cad_curve_solver','cad_constraints','cad_sketch_refs','cad_datum','cad_document_io']
kernel=['fk_sketch_projection','fk_intersect','fk_curve_ops']
record('ASAN_UBSAN_INSTRUMENTED_TU '+', '.join(n+'.cpp' for n in units)+', '+', '.join('kernel/'+n+'.cpp' for n in kernel)+', kernel/tests/test_projected_curve_references.cpp')
record('UNINSTRUMENTED: remaining application support .module.o, libforgekernel.a, Qt6/system libraries. This does not attest the complete application.')
common=['/usr/bin/c++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffunction-sections','-fdata-sections','-Wall','-Wextra','-Wpedantic','-mno-direct-extern-access','-I'+str(p),'-I'+str(p/'kernel')]
flags=(build/'CMakeFiles/forgecad_view_tests.dir/flags.make').read_text().splitlines();qt=[]
for key in ['CXX_DEFINES','CXX_INCLUDES']:qt+=shlex.split(next(s.split('=',1)[1] for s in flags if s.startswith(key+' =')))
for n in kernel:run(common+['-I'+str(repo/'kernel'),'-c',str(p/'kernel'/(n+'.cpp')),'-o',str(p/'kernel'/(n+'.asan.o'))])
for n in units:run(common+qt+['-c',str(p/(n+'.cpp')),'-o',str(p/(n+'.asan.o'))])
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
newkernel=[str(p/'kernel'/(n+'.asan.o')) for n in kernel]
run(common+['-I'+str(repo/'kernel'),str(p/'kernel/tests/test_projected_curve_references.cpp')]+newkernel+[str(build/'kernel/libforgekernel.a'),'-pthread','-o',str(p/'kernel39-asan')])
run([str(p/'kernel39-asan')],env)
link=json.loads((p/'module-link-command.json').read_text());link[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
for i,s in enumerate(link):
 for n in units:
  if s==str(p/(n+'.module.o')):link[i]=str(p/(n+'.asan.o'))
 for n in kernel:
  if s==str(p/'kernel'/(n+'.o')):link[i]=str(p/'kernel'/(n+'.asan.o'))
 if s==str(p/'module-probe'):link[i]=str(p/'module-probe-asan')
run(link);run([str(p/'module-probe-asan')],env)
record('ALL_EVIDENCE_PASS; production hash snapshot unchanged')
