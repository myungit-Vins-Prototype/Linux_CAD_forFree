from pathlib import Path
import json,hashlib,difflib,subprocess,shutil
p=Path('/tmp/forgecad-reference-fix');r=Path('/home/myungit/Linux_CAD_forFree');info=json.loads((p/'initial-hashes.json').read_text());patches=p/'patches';patches.mkdir(exist_ok=True)
entries=[];combined=''
for e in info['files']:
 path=e['path'];after=(p/path).read_bytes();digest=hashlib.sha256(after).hexdigest()
 if digest==e['before_sha256']:continue
 before=subprocess.check_output(['git','show','00072fb:'+path],cwd=r)
 assert hashlib.sha256(before).hexdigest()==e['before_sha256'],path
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 dest=patches/(path.replace('/','__')+'.patch');dest.write_text(patch);combined+=patch
 entries.append(dict(e,after_sha256=digest,patch=str(dest),apply_mode='contextual-patch-only' if path=='forgeCad2026_viewport_document.cpp' else 'hash-checked-replace-or-patch'))
for path in ['tests/test_projected_curve_references.h','kernel/tests/test_projected_curve_references.cpp']:
 entries.append(dict(path=path,before_sha256=None,after_sha256=hashlib.sha256((p/path).read_bytes()).hexdigest(),apply_mode='new'))
(p/'manifest.json').write_text(json.dumps({'head':info['head'],'status':'production frozen; tests passed module + kernel39 + baseline21','files':entries},indent=2)+'\n');(p/'reference-fix.patch').write_text(combined)
