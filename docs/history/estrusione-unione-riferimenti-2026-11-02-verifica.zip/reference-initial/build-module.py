from pathlib import Path
import shlex,subprocess,json,sys
out=Path('/tmp/forgecad-reference-fix');repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release'
flags=(build/'CMakeFiles/forgecad_view_tests.dir/flags.make').read_text().splitlines()
a=['/usr/bin/c++','-std=c++17','-O0','-g','-ffunction-sections','-fdata-sections','-Wall','-Wextra','-Wpedantic','-mno-direct-extern-access','-I'+str(out),'-I'+str(out/'kernel')]
for key in ['CXX_DEFINES','CXX_INCLUDES']:
 a+=shlex.split(next(s.split('=',1)[1] for s in flags if s.startswith(key+' =')))
units=['module_probe']+(out/'module-units.txt').read_text().splitlines()
for name in units:
 obj=out/(name+'.module.o');src=out/(name+'.cpp')
 if not obj.exists() or obj.stat().st_mtime < src.stat().st_mtime or name=='module_probe':
  command=a+['-c',str(src),'-o',str(obj)];print(shlex.join(command),flush=True);subprocess.run(command,check=True)
command=['/usr/bin/c++','-Wl,--gc-sections','-o',str(out/'module-probe')]+[str(out/(n+'.module.o')) for n in units]+[str(out/'kernel'/n) for n in ['fk_sketch_projection.o','fk_intersect.o','fk_curve_ops.o']]+[str(build/'kernel/libforgekernel.a')]+shlex.split(subprocess.check_output(['pkg-config','--libs','Qt6Widgets','Qt6OpenGL','Qt6OpenGLWidgets'],text=True))+['-lz','-lzstd','-pthread']
(out/'module-link-command.json').write_text(json.dumps(command));print(shlex.join(command),flush=True);subprocess.run(command,check=True);subprocess.run([str(out/'module-probe')],check=True)
