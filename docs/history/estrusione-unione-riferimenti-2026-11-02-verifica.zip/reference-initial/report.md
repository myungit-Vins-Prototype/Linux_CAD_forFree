# Riferimenti associativi alla curva di proiezione — pacchetto congelato

Snapshot base `00072fb`, sorgenti preparati esclusivamente sotto `/tmp/forgecad-reference-fix`. Nessun commit, push, modifica al checkout reale o ai CAD originali. Root gestisce integrazione, memoria CLAUDE, mappa architetturale e build globale.

## Causa e soluzione

Le intersezioni implicite esatte delle due superfici estruse erano deliberatamente rifiutate dal percorso che converte una curva in NURBS. Tale rifiuto era corretto ma impediva anche l'uso come riferimento nello schizzo. Ora il percorso associativo conserva una `Curve<2>` esatta, immagine affine della curva 3D, in `CurveObject::referenceCurve`. Il marcatore persistito è Converted con degree=0, due veri estremi, senza nodi/pesi/handle. Gli estremi sono punti per selezione/vincoli, mai poli di una spline di ripiego. La conversione libera `appendProjectedCurve` continua a rifiutare l'implicita: nessun fit aggiunto.

Il solver, le quote e il vincolo PointOnCurve leggono la stessa curva esatta; le tangenti agli estremi leggono le derivate esatte. Rendering e picking usano campioni soltanto per display. L'immersione della curva di riferimento in un altro schizzo conserva una trasformazione affine della sorgente, senza estrarre una NURBS approssimata.

Contatti e Pierce su curva3D intersecano esattamente la curva con il piano. Per un ramo implicito il problema si riduce alle intersezioni di due curve razionali nel piano richiesto; i casi paralleli usano direttamente le radici razionali della sorgente. Piani generali e trasformazioni affini sono supportati. Una curva complanare non genera un punto Pierce arbitrario, una sorgente mancante/soppressa/in errore o senza intersezione produce errore esplicito.

La selezione, la cache di snap e il resolver distinguono i rami attraverso una chiave `projection-branch-v1/<SHA256>`, ricavata da identità dello schizzo/entità e tratti sorgenti della componente; la chiave viaggia nel campo già persistito GeometryRef.point.name. Le curve e le chiavi ricostruite sono transienti. La lista dei componenti può cambiare ordine senza spostare il collegamento su un'altra curva. Se la chiave manca, il resolver fallisce e invalida la cache, senza scegliere il ramo vicino. I riferimenti legacy privi di chiave conservano il comportamento precedente.

## Persistenza e compatibilità

Il formato resta 60 e le enum non cambiano. `referenceCurve` e `curveReferenceKeys` non sono serializzati: vengono ricostruiti dal GeometryRef sorgente e dalla definizione della feature. Il decoder accetta il marcatore procedurale soltanto con geometria minima valida e un collegamento associativo; senza cache ricostruita `curveGeometry` non restituisce geometria e il solver chiede rigenerazione. Il vecchio percorso Converted richiedeva degree>=1: il marcatore degree0 non diventa una falsa retta nei reader precedenti. Nessuna garanzia che una vecchia versione sappia usare questo nuovo riferimento: può rimanere non risolto.

## File e integrazione

`manifest.json` contiene 18 file esistenti e 2 nuovi test con hash iniziali/finali. `patches/` contiene patch per file e `reference-fix.patch` il diff complessivo. In `forgeCad2026_viewport_document.cpp` la modifica è confinata a `refreshSurfacePierceSketches`: applicare soltanto la patch contestuale, preservando `unchangedFeature` dell'agente GUI. `delta-pierce-guard.json` documenta i due file aggiornati dopo il primo freeze.

Nessun nuovo TU di produzione. Due membri aggiunti agli oggetti richiedono un rebuild globale di app e test prima di linkare sonde GUI: gli oggetti compilati con la vecchia ABI non possono essere mescolati. `integration.txt` contiene gli inserimenti test/CMake per root.

## Verifiche effettuate

- Compilati separatamente tutti i TU di produzione modificati, incluse selezione/sketch/document viewport, con gli header coerenti; compilatore C++17, -Wall -Wextra -Wpedantic.
- Kernel nuova regressione: PASS 39 casi, 30 piani obliqui deterministici, piani coordinate/tangenza/estremi, residui, immagine2D, radici di retta2D, reimmersione complanare, piano senza contatto e genealogia indipendente dal riordino degli input.
- Kernel regressione preesistente: PASS 21 gruppi di proiezione schizzo su schizzo, comprese le guardie STEP/IGES e la rappresentazione NURBS esatta.
- Sonda modulo con ABI coerente: PASS conversione associativa esatta su un altro piano, entrambi input modificati internamente con estremi fermi, COW dello snapshot, PointOnCurve e quota, contatto isolato, Pierce, assenza di contatto, sorgente Pierce soppressa/in errore, codec cache/no-cache e rigenerazione, ramo mancante senza riaggancio, riordino di due componenti, riferimento da altro schizzo e piano degenere rifiutato atomicamente.
- Lo snapshot COW è una prova dell'immutabilità dei dati; non è una prova GUI di Undo/Redo. La QA nativa e Undo/Redo reali sono assegnati all'agente GUI dopo rebuild globale. Storyboard ha già verificato scheduler, cicli, riordino e persistenza sul precedente percorso razionale; i risultati impliciti integrati saranno verificati da root/GUI.

`build-module.py`, `module-units.txt`, `module-build.log`, `kernel-commands.json`, `run-evidence.py` ed `evidence.log` rendono le sonde riproducibili. Il log sanitizer dichiara esattamente i TU strumentati e i supporti non strumentati; non attesta l'app completa.

## Limiti reali

Le curve razionali prodotte esattamente continuano a essere NURBS esportabili. La rappresentazione implicita e le sue immagini affini restano riferimenti geometrici esatti: nessuna nuova approssimazione per sweep, STEP/IGES o conversione libera è autorizzata. Le guardie di scambio continuano a riconoscerle anche dopo reimmersione.

La genealogia dipende dalle entità e dai tratti sorgenti: cambi topologici che eliminano la chiave producono riferimento non risolto. Non è stato introdotto un sistema generale di identità persistente delle singole radici critiche o degli indici delle entità dello schizzo. Gli indici degli input interni agli schizzi conservano le regole di rimappatura esistenti.

Restano i limiti del costruttore originale: piani non paralleli, massimo 1024 tratti generati, rifiuto delle tangenze comuni non regolari/ramificazioni ambigue e delle soluzioni fuori dal dominio numerico. Nessuna tolleranza è stata aumentata. Riferimenti su piani complanari non definiscono un'intersezione Pierce isolata.

## Sanitizer — esito finale

PASS ASan/UBSan sulla nuova suite kernel39 e sulla sonda modulo (exitcode0, nessun diagnostico). Strumentati con `-fsanitize=address,undefined -fno-omit-frame-pointer`: `kernel/fk_sketch_projection.cpp`, `kernel/fk_intersect.cpp`, `kernel/fk_curve_ops.cpp`, `kernel/tests/test_projected_curve_references.cpp`, `module_probe.cpp`, `cad_projected_curve.cpp`, `cad_curve_solver.cpp`, `cad_constraints.cpp`, `cad_sketch_refs.cpp`, `cad_datum.cpp`, `cad_document_io.cpp`. I restanti supporti applicativi, libforgekernel.a e Qt/librerie di sistema non sono strumentati. `ASAN_OPTIONS=detect_leaks=0:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`. Il log finale riporta comandi/ambiente/exitcode e hash del pacchetto, inclusa la guardia Pierce sorgente soppressa/in errore. Questa verifica non equivale a una build sanitizer dell'intera app.
