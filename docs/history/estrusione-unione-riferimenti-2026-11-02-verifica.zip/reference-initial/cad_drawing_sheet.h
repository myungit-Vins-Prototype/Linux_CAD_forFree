#ifndef FORGECAD_DRAWING_SHEET_H
#define FORGECAD_DRAWING_SHEET_H
#include "cad_drawing.h"
#include "cad_drawing_tolerances.h"
#include "cad_drawing_axes.h"
#include "cad_drawing_style.h"
#include <QPointF>
#include <QSizeF>
#include <QVector>
#include <QMap>
#include <QStringList>
#include <optional>

namespace ForgeCad {
enum class DrawingDerivedKind { None, Orthographic, Section, Detail, Auxiliary };
enum class DrawingProjectionSide { Left, Right, Above, Below };
enum class DrawingProjectionMethod { FirstAngle, ThirdAngle };
// Intervallo rimosso nel piano della vista (mm modello); gap sul foglio (mm).
struct DrawingViewBreak {
    bool vertical=false;
    double start=0,end=0,gap=6;
};
struct DrawingViewRelation {
    QUuid parentId;
    DrawingDerivedKind kind=DrawingDerivedKind::None;
    DrawingProjectionSide side=DrawingProjectionSide::Right;
    DrawingProjectionMethod method=DrawingProjectionMethod::FirstAngle;
    bool aligned=true;
    QPointF cutStart,cutEnd; // coordinate del piano madre, mm modello, Y verso l’alto
    bool reverse=false,hatch=true;
    QString label;
    QPointF detailCenter; // piano madre, mm modello
    double detailRadius=0; // ritaglio grafico, mai riferimento di quota
    QVector<QPointF> detailOutline; // poligono chiuso implicitamente, piano madre in mm modello; vuoto = cerchio
    std::optional<QPointF> detailLabelOffset; // posizione della lettera rispetto al centro, mm sul foglio
    std::optional<DrawingSectionBend> bend; // angolo verso destra della direzione iniziale, indipendente dalle frecce
    std::optional<DrawingSectionStep> step; // offset nel verso tangente x normale della madre
    double auxiliaryAngle=0; // lato d'osservazione nel piano madre, gradi da +X verso +Y
    bool detailLinked=false; // linea grafica fra contorno sulla madre e bordo del dettaglio
};
enum class DrawingScaleSource { Custom, Sheet, Parent };
struct DrawingViewLayout {
    QUuid viewId;
    QString title;
    QPointF position; // origine del piano sul foglio, in mm (Y verso il basso)
    QVector<quint64> features;
    bool showHiddenLines=false; // presentazione della sola vista, salvata nel .drw
    DrawingViewRelation relation{};
    bool showMesh=false; // facce ombreggiate dalla mesh, mai riferimenti di quota
    bool showCenterMarks=false,showCenterLines=false; // cerchi/ellissi esatti della vista
    bool showCylinderAxes=false; // asse delle superfici cilindriche, sola presentazione
    std::optional<QPointF> titleOffset={}; // origine del titolo rispetto alla vista, mm sul foglio
    std::optional<DrawingViewBreak> interruption={}; // sola presentazione, misure originali
    // Assente nei file storici: indipendente, o madre per le derivate ordinarie.
    std::optional<DrawingScaleSource> scaleSource={};
    std::optional<double> customScale={}; // conserva il valore anche usando foglio/madre
};
inline DrawingScaleSource drawingViewScaleSource(const DrawingViewLayout &view) {
    return view.scaleSource.value_or(!view.relation.parentId.isNull() && view.relation.kind!=DrawingDerivedKind::Detail
        ? DrawingScaleSource::Parent : DrawingScaleSource::Custom);
}
struct DrawingDimensionLayout {
    QUuid dimensionId;
    QPointF position; // posizione del testo sul foglio, indipendente dalla misura
    DrawingDimensionPresentation presentation{};
};
struct DrawingDimensionNumbering {
    bool enabled=false;
    int firstNumber=1;
    double diameter=6,rowTolerance=3; // mm sul foglio; righe ancorate al testo più alto
    bool excludeParenthesized=false;
    bool persistent=false;
    int primaryDirection=0,secondaryDirection=1; // destra, sotto, sinistra, sopra
    QUuid firstDimension;
    QStringList excludePatterns; // glob su prefisso/suffisso, senza distinzione maiuscole
    QMap<QUuid,int> assignments; // comprende quote eliminate: i numeri restano riservati
    int nextNumber=1;
    bool active()const{return enabled||firstNumber!=1||diameter!=6||rowTolerance!=3||excludeParenthesized||persistent; }
};
struct DrawingTitleBlock {
    bool visible=false;
    QString code,organization,author,date; // data dichiarata, non aggiornata all’apertura
};
struct DrawingRevisionNote {
    QUuid checkinId;
    QString description,verifiedBy;
};
struct DrawingRevisionTable {
    bool visible=false;
    QVector<DrawingRevisionNote> notes;
};
enum class DrawingTechnicalKind { Datum, FeatureControl, SurfaceTexture };
enum class DrawingGeometricCharacteristic { Straightness, Flatness, Circularity, Parallelism, Perpendicularity, Position };
enum class DrawingRoughnessParameter { Ra, Rz };
enum class DrawingMaterialRemoval { Any, Required, Prohibited };
struct DrawingSurfaceTexture {
    DrawingRoughnessParameter parameter=DrawingRoughnessParameter::Ra;
    double value=3.2; // limite dichiarato in micrometri, indipendente dalle unità del modello
    DrawingMaterialRemoval removal=DrawingMaterialRemoval::Any;
    QString process; // processo di fabbricazione opzionale
};
struct DrawingTechnicalAnnotation {
    DrawingTechnicalKind kind=DrawingTechnicalKind::Datum;
    QString label; // identificatore del datum: lettere A-Z
    DrawingGeometricCharacteristic characteristic=DrawingGeometricCharacteristic::Straightness;
    double tolerance=0; // valore dichiarato in mm, non misura calcolata
    bool diameter=false;
    QVector<QUuid> datums; // primario, secondario, terziario; mai etichette congelate
    std::optional<DrawingSurfaceTexture> surfaceTexture{};
};
struct DrawingAnnotation {
    QUuid id=QUuid::createUuid(),viewId; // vista nulla per una nota libera sul foglio
    QString text=QStringLiteral("Nota");
    QPointF position{20,20}; // mm sul foglio, angolo superiore sinistro
    double width=45,height=3; // larghezza di impaginazione e altezza nominale del testo, mm
    std::optional<DrawingAttachment> reference; // punta del richiamo, mai coordinate congelate
    std::optional<DrawingTechnicalAnnotation> technical{};
};
struct DrawingSheet {
    DrawingDocument drawing;
    QString title = QStringLiteral("Tavola");
    QSizeF size{297,210};
    QVector<DrawingViewLayout> views;
    QVector<DrawingDimensionLayout> dimensions;
    DrawingTitleBlock titleBlock;
    DrawingRevisionTable revisionTable;
    QVector<DrawingAxis> axes;
    QVector<DrawingAnnotation> annotations;
    DrawingStyle style;
    DrawingDimensionNumbering dimensionNumbering;
    double scale=1.0; // rapporto foglio/modello; le misure restano in mm modello
};
bool drawingUsesSheetScale(const DrawingSheet &sheet);
QString drawingScaleText(double scale);
double drawingSheetScale(const DrawingSheet &sheet);
// Solo metadati del foglio; nessuna duplicazione della geometria del modello.
DrawingAttachmentResolver drawingSheetAttachmentResolver(const DrawingSheet &sheet,const DrawingView &view,
    const DrawingModelSnapshot &model,const std::vector<DrawingCurve> &curves);
QString encodeDrawingSheet(const DrawingSheet &sheet,QByteArray &bytes);
QString decodeDrawingSheet(const QByteArray &bytes,DrawingSheet &sheet);
}
#endif
