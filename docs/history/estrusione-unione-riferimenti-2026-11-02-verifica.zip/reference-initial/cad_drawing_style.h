#pragma once
#include <QString>
#include <QPainterPath>
#include <QFont>
#include <cmath>
namespace ForgeCad {
enum class DrawingTextOrientation { Horizontal, Aligned };
enum class DrawingTextPosition { Centered, Above, Below };
enum class DrawingArrowStyle { Open, Filled, Closed, Tick };
struct DrawingStyle {
    QString fontFamily=QStringLiteral("DejaVu Sans");
    double dimensionHeight=3,viewTitleHeight=3,arrowLength=2,titleGap=6;
    DrawingArrowStyle arrow=DrawingArrowStyle::Open;
    bool titleSnaps=true;
    double extensionGap=0,dimensionOffset=0; // mm sul foglio, zero conserva il layout precedente
    DrawingTextOrientation dimensionTextOrientation=DrawingTextOrientation::Horizontal;
    DrawingTextPosition dimensionTextPosition=DrawingTextPosition::Centered;
    double dimensionTextGap=.8; // mm sul foglio
    double arrowWidth=0; // base totale in mm; zero conserva il rapporto storico 0,65 H
    double arrowBaseWidth()const{return arrowWidth>0?arrowWidth:arrow==DrawingArrowStyle::Tick?arrowLength:.65*arrowLength;}
    bool textLayoutActive()const{return dimensionTextOrientation!=DrawingTextOrientation::Horizontal||dimensionTextPosition!=DrawingTextPosition::Centered||dimensionTextGap!=.8;}
    bool operator==(const DrawingStyle &s)const{return fontFamily==s.fontFamily&&dimensionHeight==s.dimensionHeight&&viewTitleHeight==s.viewTitleHeight&&arrowLength==s.arrowLength&&titleGap==s.titleGap&&arrow==s.arrow&&titleSnaps==s.titleSnaps&&extensionGap==s.extensionGap&&dimensionOffset==s.dimensionOffset&&dimensionTextOrientation==s.dimensionTextOrientation&&dimensionTextPosition==s.dimensionTextPosition&&dimensionTextGap==s.dimensionTextGap&&arrowWidth==s.arrowWidth;}
    bool active()const{return !(*this==DrawingStyle{});}
};
inline QString validateDrawingStyle(const DrawingStyle &s){
    if(!std::isfinite(s.arrowWidth)||s.arrowWidth<0||s.arrowWidth>20||(s.arrowWidth>0&&s.arrowWidth<.1))return QStringLiteral("Base freccia non valida (0,1–20 mm).");
    if(int(s.dimensionTextOrientation)<0||int(s.dimensionTextOrientation)>1||int(s.dimensionTextPosition)<0||int(s.dimensionTextPosition)>2||!std::isfinite(s.dimensionTextGap)||s.dimensionTextGap<0||s.dimensionTextGap>20)return QStringLiteral("Orientamento, posizione o distanza del testo quota non validi.");
    for(double x:{s.extensionGap,s.dimensionOffset})if(!std::isfinite(x)||x<0||x>100)return QStringLiteral("Distanza delle quote non valida (0–100 mm sul foglio).");
    if(s.fontFamily.trimmed().isEmpty()||s.fontFamily.size()>256)return QStringLiteral("Famiglia del carattere non valida.");
    for(auto c:s.fontFamily)if(!c.isPrint())return QStringLiteral("Famiglia del carattere non stampabile.");
    for(double x:{s.dimensionHeight,s.viewTitleHeight,s.arrowLength})if(!std::isfinite(x)||x<.5||x>20)return QStringLiteral("Dimensione di testi o frecce non valida (0,5–20 mm).");
    if(!std::isfinite(s.titleGap)||s.titleGap<0||s.titleGap>100||int(s.arrow)<0||int(s.arrow)>3)return QStringLiteral("Stile di freccia o distanza del titolo non validi.");
    return {};
}
inline QFont drawingFont(const DrawingStyle &s){QFont f(s.fontFamily);f.setPixelSize(12);return f;}
inline QPainterPath drawingArrowPath(const DrawingStyle &s,QPointF tip,QPointF toward){
    QPainterPath path;auto d=toward-tip;const double norm=std::hypot(d.x(),d.y());if(norm<1e-10)return path;d/=norm;const QPointF n(-d.y(),d.x());
    if(s.arrow==DrawingArrowStyle::Tick){path.moveTo(tip+s.arrowLength*.5*d+s.arrowBaseWidth()*.5*n);path.lineTo(tip-s.arrowLength*.5*d-s.arrowBaseWidth()*.5*n);return path;}
    path.moveTo(tip+s.arrowLength*d+s.arrowBaseWidth()*.5*n);path.lineTo(tip);path.lineTo(tip+s.arrowLength*d-s.arrowBaseWidth()*.5*n);
    if(s.arrow!=DrawingArrowStyle::Open)path.closeSubpath();
    return path;
}
}
