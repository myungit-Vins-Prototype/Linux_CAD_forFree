#ifndef FORGECAD_DRAWING_EDITOR_H
#define FORGECAD_DRAWING_EDITOR_H
#include "cad_drawing_sheet.h"
#include "cad_drawing_dimension.h"
#include "cad_drawing_page.h"
#include "cad_drawing_preparation.h"
#include <QHash>
#include <QWidget>
#include <functional>
#include <memory>

class QGraphicsView;
namespace ForgeCad {
class DrawingSheetEditor final : public QWidget {
public:
    DrawingSheetEditor(DrawingSheet sheet,DrawingEditorModel model,QWidget *parent=nullptr);
    ~DrawingSheetEditor() override;
    const DrawingSheet &sheet() const;
    QGraphicsView *canvas() const;
    const std::vector<DrawingCurve> &curves(const QUuid &viewId) const;
    const std::vector<DrawingSection> &sections(const QUuid &viewId) const;
    DrawingDimensionResult dimensionResult(const QUuid &id) const;
    QString insertView(DrawingView view,DrawingViewLayout layout);
    // Anteprima transitoria: segue il mouse, clic inserisce, Esc annulla.
    QString beginViewPlacement(DrawingView view,DrawingViewLayout layout);
    QString beginDerivedViewPlacement(const QUuid &parent,DrawingProjectionSide side,DrawingProjectionMethod method);
    QString setViewBreak(const QUuid &id,std::optional<DrawingViewBreak> interruption);
    QString beginAuxiliaryViewPlacement(const QUuid &parent,double angle);
    QString beginDetailCircle(const QUuid &parent,const QString &label,double scale);
    QString beginDetailViewPlacement(const QUuid &parent,QPointF center,double radius,double scale,const QString &label,const QVector<QPointF> &outline={});
    QString moveDetailLabel(const QUuid &id,QPointF paperPosition);
    QString updateDetailView(const QUuid &id,QPointF center,double radius,double scale,const QString &label);
    // Madre nulla: la linea sul foglio individua la vista proiettata attraversata.
    QString beginSectionLine(const QUuid &parent,const QString &label,bool reverse=false,const QUuid &existing={},DrawingSectionStyle style=DrawingSectionStyle::Removed);
    QString setSectionLine(const QUuid &section,QPointF start,QPointF end);
    QString beginSectionPlacement(const QUuid &parent,QPointF start,QPointF end,const QString &label,bool reverse=false,DrawingSectionStyle style=DrawingSectionStyle::Removed,std::optional<DrawingSectionStep> step={},std::optional<DrawingSectionBend> bend={});
    bool hasSectionLine()const;
    QString detachView(const QUuid &id);
    QString setViewAlignment(const QUuid &id,bool aligned);
    QString setSectionHatch(const QUuid &id,bool visible);
    QString reverseSection(const QUuid &id);
    QString alignSectionOrientation(const QUuid &id);
    QString setSectionStyle(const QUuid &id,DrawingSectionStyle style);
    bool hasViewPlacement() const;
    void cancelViewPlacement();
    // Modifica atomica: ID e quote conservati, ricalcolo delle viste dipendenti il cui piano cambia.
    QString updateView(DrawingView view,DrawingViewLayout layout);
    QString setViewScale(const QUuid &id,DrawingScaleSource source,double customScale);
    enum class ViewAlignment { SameRow, SameColumn };
    QString moveView(const QUuid &id,const QPointF &position);
    QString moveViewTitle(const QUuid &id,const QPointF &position);
    QString resetViewTitle(const QUuid &id);
    QString setDrawingStyle(const DrawingStyle &style);
    QString setDimensionNumbering(const DrawingDimensionNumbering &numbering);
    QString setDimensionObliquity(const QUuid &id,double degrees);
    QString moveDimension(const QUuid &id,const QPointF &position);
    // Centri sul foglio: posizionamento una tantum, senza vincoli persistenti.
    QString alignView(const QUuid &id,const QUuid &reference,ViewAlignment alignment);
    QString removeView(const QUuid &id);
    QString setHiddenLinesVisible(const QUuid &id,bool visible);
    QString setShadedFacesVisible(const QUuid &id,bool visible);
    QString setCenterMarksVisible(const QUuid &id,bool visible);
    QString setCenterLinesVisible(const QUuid &id,bool visible);
    QString setCylinderAxesVisible(const QUuid &id,bool visible);
    QString beginAxis(DrawingAxisKind kind,const QUuid &existing={});
    QString addAxis(DrawingAxis axis);
    QString updateAxis(DrawingAxis axis);
    QString removeAxis(const QUuid &id);
    DrawingAxisResult axisResult(const QUuid &id)const;
    QString beginAnnotation(bool leader,const QUuid &existing={});
    QString addAnnotation(DrawingAnnotation note);
    QString updateAnnotation(DrawingAnnotation note);
    QString moveAnnotation(const QUuid &id,const QPointF &position);
    QString removeAnnotation(const QUuid &id);
    DrawingResolvedAttachment annotationResult(const QUuid &id)const;
    QString setRevisionTable(const DrawingRevisionTable &table);
    bool isComputing()const;
    QString setPageSettings(const QString &title,const QSizeF &size,const DrawingTitleBlock &block,std::optional<double> scale={});
    void setPageContext(DrawingPageContext context);
    DrawingPageContext pageContext()const;
    QString exportPdf(const QString &path,DrawingPdfReport &report)const;
    QString undo();
    QString redo();
    bool canUndo() const;
    bool canRedo() const;
    void markSaved();
    bool isModified() const;
    QString addDimension(DrawingDimension dimension,const QPointF &position);
    QString addDimensionSeries(const QUuid &view,const std::vector<DrawingAttachment> &points,DrawingDimensionSeries kind,const QPointF &baseline);
    QString updateDimension(DrawingDimension dimension);
    QString updateDimension(DrawingDimension dimension,DrawingDimensionPresentation presentation);
    QString addSelectedDimension(DrawingMeasure measure);
    QString updateModel(DrawingEditorModel model);
    void setChangedCallback(std::function<void(const DrawingSheet &)> callback);
    void setModelProvider(std::function<DrawingEditorModel()> provider);
    void fitSheet();
    void setReadOnly(bool readOnly);
    bool isReadOnly() const;
private:
    friend class DrawingWindow;
    // Navigazione/ripristino del contenitore; non e' una mutazione pubblica.
    QString loadSheet(DrawingSheet sheet);
    void installPreparedModel(PreparedDrawingSheet prepared);
    void setDocumentHistory(std::function<QString(bool)> handler,bool undo,bool redo,QString undoLabel={},QString redoLabel={});
    static QString exportPdfPages(const QString &path,const QVector<const DrawingSheetEditor *> &pages,DrawingPdfReport &report);
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
#endif
