#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "fk_classify.h"
#include <iostream>
#include <stdexcept>
static void require(bool ok,const char*m){if(!ok)throw std::runtime_error(m);}
class ViewportInteractionTest {public:
static void run() {
    using namespace ForgeCad; using namespace Kernel;
    DocumentState state;
    SketchObject first,second,target;
    first.name="S0"; first.plane=0; first.storyId=10; first.beforeFeatureId=101;
    second.name="S1"; second.plane=1; second.storyId=20; second.beforeFeatureId=101;
    target.name="S2"; target.plane=1; target.storyId=30; target.beforeFeatureId=102;
    first.segments={{{0,0},{4,0}}}; second.segments={{{0,0},{4,4}}};
    state.sketches={first,second,target};
    ExtrusionObject projection; projection.feature=BodyFeature::ProjectedCurve; projection.projectionMode=1; projection.featureId=101;
    GeometryRef a,b; a.kind=b.kind=7; a.index=0; b.index=1; a.featureId=10; b.featureId=20;
    a.element=b.element={0,0,-1}; projection.ruledFirst={a};projection.ruledSecond={b};
    buildGeometry(projection,0,state.sketches,{}); require(projection.curve && projection.error.isEmpty(),qPrintable(projection.error));
    state.extrusions={projection};
    GeometryRef ref; ref.kind=9; ref.index=0;ref.featureId=101;ref.point={1,0,1};
    const auto error=appendLinkedSketchReference(state.sketches[2],ref,state.sketches,state.extrusions,false,false);
    require(error.isEmpty(),qPrintable(error));
    ExtrusionObject downstream;downstream.featureId=102;downstream.sketchIndex=2;downstream.distance=1;downstream.extrudeSurface=true;
    state.extrusions.append(downstream);
    CadViewport view;view.tessellationQuality_=0;view.loadDocument(state);
    auto check=[&](double z){
      require(view.extrusions_.size()==2 && view.extrusions_[0].featureId==101 && view.extrusions_[1].featureId==102,"feature identita' preservate");
      require(view.sketches_[2].referenceError.isEmpty() && view.extrusions_[1].forgeBody && view.extrusions_[1].error.isEmpty(),"catena associativa valida");
      double high=-1e100;for(auto v:view.extrusions_[1].forgeBody->vertices())high=std::max(high,view.extrusions_[1].forgeBody->vertex(v).point.z());
      std::cout<<"CHAIN expected="<<z<<" actual="<<high<<std::endl;
      require(std::fabs(high-z)<1e-9,"modifica sorgente aggiorna cache S2 prima della feature downstream");
      require(view.sketches_[2].linkedReferences[0]->source.featureId==101,"link persistente verso proiezione invariato");
    };
    check(4);
    for(int input:{0,1}){view.activeSketch_=input;require(!view.allowedSketchReference(ref),"ciclo input->feature->stesso input rifiutato");}
    view.activeSketch_=2;require(view.allowedSketchReference(ref),"riferimento successivo ammesso");view.activeSketch_=-1;
    require(!view.moveStoryboardStep(view.storyboardIndex(true,2),view.storyboardIndex(false,0)).isEmpty(),"riordino prima della propria sorgente rifiutato");
    require(!view.moveStoryboardStep(view.storyboardIndex(true,0),view.storyboardIndex(true,2)).isEmpty(),"input dopo la proiezione rifiutato");
    require(view.renameObject(SceneObjectKind::Sketch,0,"Input rinominato").isEmpty() && view.renameObject(SceneObjectKind::Extrusion,0,"Proiezione rinominata").isEmpty(),"rinomina senza cambiare identita'");check(4);
    view.recordUndo();view.sketches_[0].segments[0].second.setX(3);view.regenerateDependents(0);check(3);
    view.undo();check(4);view.redo();check(3);
    view.recordUndo();view.sketches_[1].segments[0].second.setY(8);view.regenerateDependents(1);check(6);
    view.undo();check(3);view.redo();check(6);
    for(bool cache:{false,true}){QByteArray bytes;require(encodeDocument(view.currentDocument(),bytes,cache).isEmpty(),"codec catena proiezione");DocumentState loaded;require(decodeDocument(bytes,loaded).isEmpty(),"decodifica catena proiezione");view.loadDocument(loaded);check(6);require(view.rebuildAllFeatures()==0,"ricalcolo completo catena dopo riapertura");check(6);}
    view.setHistoryPosition(0);require(!view.isBodyDrawn(0)&&!view.isBodyDrawn(1),"rollback prima proiezione nasconde funzioni future");
    view.setHistoryPosition(2);check(6);
    auto multiSketches=state.sketches; multiSketches[0].segments.append({{0,10},{4,10}});
    auto multi=projection; auto additional=a; additional.element.element=1; multi.ruledFirst={a,additional};
    buildGeometry(multi,0,multiSketches,{}); require(multi.curves.size()==2,"due componenti disgiunte da input distinti");
    const double firstY=multi.curves[0]->point(multi.curves[0]->domain().lo).y();
    std::reverse(multi.ruledFirst.begin(),multi.ruledFirst.end()); buildGeometry(multi,0,multiSketches,{});
    require(multi.curves.size()==2,"stessa topologia dopo permutazione input");
    const double reorderedY=multi.curves[0]->point(multi.curves[0]->domain().lo).y();
    std::cout<<"BRANCH ORDER input permutation firstY="<<firstY<<" reorderedFirstY="<<reorderedY<<std::endl;
    require(std::fabs(firstY-reorderedY)>1,"sonda conferma che il solo ordinal non e' un'identita' genealogica");
    std::cout<<"PASS audit catena lineare S0/S1->proiezione->S2->estrusione, cicli/riordino/rinomina/Undo/Redo/codec/rollback"<<std::endl;
}
};
int main(int argc,char**argv){QApplication app(argc,argv);try{ViewportInteractionTest::run();}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
