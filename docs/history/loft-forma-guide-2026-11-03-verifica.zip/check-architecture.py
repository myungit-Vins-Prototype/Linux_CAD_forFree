from pathlib import Path
import json
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-loft-shape-fix');g=json.loads((r/'docs/architecture/graph.json').read_text());assert not g['analysis']['errors']
checks=[('kernel/fk_loft.cpp','kernel/fk_loft_profiles.cpp','loftParameterPieces'),('kernel/fk_loft.cpp','kernel/fk_loft_profiles.cpp','normalizeLoftParameterJoins'),('kernel/fk_loft.cpp','kernel/fk_loft_profiles.cpp','commonLoftDenominator'),('kernel/tests/test_loft_shape.cpp','kernel/fk_loft.cpp','loftSheet'),('tests/test_document_read.h','cad_document_io.cpp','decodeDocument'),('tests/test_native_revisions.h','cad_native_revisions.cpp','readNativeRevision'),('tests/test_declared_history_cache.h','cad_document_io.cpp','loadDocumentFile')]
result={'files':len(g['nodes']),'relations':len(g['edges']),'units':len(g['analysis']['units']),'errors':g['analysis']['errors'],'boundaries':[],'directions':{}}
for source,target,symbol in checks:
 sites=[s for e in g['edges'] if e['source']==source and e['target']==target and e['kind']=='call' for s in e['sites'] if symbol in s['symbol']];assert sites,(source,target,symbol)
 result['boundaries'].append({'source':source,'target':target,'kind':'call','symbol':symbol,'sites':sites})
for name in ['kernel/fk_loft.cpp','kernel/fk_loft_profiles.h','kernel/fk_loft_profiles.cpp','kernel/tests/test_loft_shape.cpp','cad_document_io.cpp','tests/test_document_read.h','tests/test_native_revisions.h','tests/test_declared_history_cache.h']:
 assert any(x['id']==name for x in g['nodes']),name
 result['directions'][name]={kind:{'in':sum(e['count'] for e in g['edges'] if e['target']==name and e['kind']==kind),'out':sum(e['count'] for e in g['edges'] if e['source']==name and e['kind']==kind)} for kind in ['call','include','reference']}
(o/'architecture-checked.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',result['files'],'files',result['relations'],'relations',result['units'],'AST units',len(checks),'boundaries; all changed modules incoming/outgoing call/include/reference recorded')
