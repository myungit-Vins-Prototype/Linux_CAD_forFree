#include "fk_loft.h"
#include "fk_bspline.h"
#include "fk_surface_algo.h"
#include "fk_body_check.h"
#include <iostream>
#include <stdexcept>
using namespace ForgeCad::Kernel;
static BSplineCurvePtr<3> cubic(std::vector<Vec3>p){return std::make_shared<BSplineCurve<3>>(3,std::vector<double>{0,0,0,0,1,1,1,1},std::move(p));}
static LoftSection section(BSplineCurvePtr<3>c){LoftSection s;s.path={{c,c->domain()}};return s;}
int main(){try{std::cout.precision(15);auto a=cubic({{0,0,0},{0,1,0},{2,2,0},{3,2,0}}),b=cubic({{0,0,4},{0,2,4},{3,3,4},{4,3,4}});auto ar=std::make_shared<BSplineCurve<3>>(a->insertKnot(.37,2)),br=std::make_shared<BSplineCurve<3>>(b->insertKnot(.61,1));auto g1=cubic({{0,0,0},{-1,0,1},{-1,0,3},{0,0,4}}),g2=cubic({{3,2,0},{5,2,1},{5,3,3},{4,3,4}});double worst=0;for(int guides:{0,1,2}){LoftOptions o;o.startContinuity=o.endContinuity=1;if(guides){o.guides.push_back({{g1,g1->domain()}});o.guideConditions.push_back({1,1});}if(guides==2){o.guides.push_back({{g2,g2->domain()}});o.guideConditions.push_back({1,1});}auto base=loftSheet({section(a),section(b)},o),refined=loftSheet({section(ar),section(br)},o);if(!checkBody(base).empty()||!checkBody(refined).empty())throw std::runtime_error("invalid B-rep");if(base.faces().size()!=1||refined.faces().size()!=1)throw std::runtime_error("unexpected faces");const auto &s=*base.face(base.faces()[0]).surface,&r=*refined.face(refined.faces()[0]).surface;double error=0;for(int i=0;i<=50;++i)for(int j=0;j<=50;++j)error=std::max(error,distance(s.point(i/50.,j/50.),r.point(i/50.,j/50.)));worst=std::max(worst,error);std::cout<<"GUIDES "<<guides<<" same-parameter maxDistance="<<error<<std::endl;}std::cout<<"WORST "<<worst<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
