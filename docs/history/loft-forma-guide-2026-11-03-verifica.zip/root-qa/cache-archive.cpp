#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "cad_document_read.h"
#include "fk_primitives.h"
#include "fk_body_io.h"
#include <QTemporaryDir>
#include <QProcess>
#include <iostream>
#include <stdexcept>
static void require(bool ok,const char *m){if(!ok)throw std::runtime_error(m);}
static QByteArray testDocumentUncompress(const QByteArray &d,qsizetype o,qsizetype n=-1){QByteArray r;require(ForgeCad::DocumentReadDetail::uncompress(d.mid(o,n),1024*1024*1024,r,quint8(d.at(6))),"decode fixture");return r;}
static QByteArray testDocumentCompress(const QByteArray &d,const QByteArray &doc){return ForgeCad::DocumentReadDetail::compress(d,quint8(doc.at(6)),9);}
#include "/tmp/forgecad-loft-shape-fix/cache-archive-package/tests/test_document_read.h"
int main(int argc,char **argv){QApplication app(argc,argv);try{documentLoftCacheMigrationTests();std::cout<<"PASS cache moderna, migrazione loft7, snapshot precedente senza loft\n";}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
