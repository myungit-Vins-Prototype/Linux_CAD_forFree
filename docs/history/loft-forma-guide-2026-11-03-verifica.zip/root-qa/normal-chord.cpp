#include "fk_loft.h"
#include "fk_bspline.h"
#include "fk_surface_algo.h"
#include <iostream>
#include <stdexcept>
using namespace ForgeCad::Kernel;
int main(){try{LoftSection a,b;auto c=std::make_shared<BSplineCurve<3>>(3,std::vector<double>{0,0,0,0,1,1,1,1},std::vector<Vec3>{{0,0,0},{0,2,0},{4,2,0},{4,0,0}});auto d=std::make_shared<TransformedCurve>(c,Transform3::translation({0,10,0}));a.path={{c,c->domain()}};b.path={{d,d->domain()}};LoftOptions o;o.startContinuity=o.endContinuity=1;auto shape=loftSheet({a,b},o);auto &s=*shape.face(shape.faces()[0]).surface;Vec3 q[4];s.evaluate(.3,0,1,q);std::cout.precision(15);std::cout<<"firstV norm="<<norm(q[1])<<" vector="<<q[1].x()<<","<<q[1].y()<<","<<q[1].z()<<" nearEndpoint normalZ="<<normalAt(s,.3,1e-6).z()<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
