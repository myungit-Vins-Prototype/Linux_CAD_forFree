#include "fk_loft.h"
#include "fk_bspline.h"
#include "fk_surface_algo.h"
#include "fk_body_check.h"
#include <iostream>
#include <stdexcept>
using namespace ForgeCad::Kernel;
static PathSegment line(Vec3 a,Vec3 b){return {std::make_shared<Line<3>>(a,normalized(b-a)),{0,distance(a,b)}};}
int main(){try{LoftSection a,b;a.path={line({0,0,0},{10,0,0})};b.path={line({0,10,0},{10,10,0})};LoftOptions o;for(double x:{0.,5.,10.}){auto c=std::make_shared<BSplineCurve<3>>(3,std::vector<double>{0,0,0,0,1,1,1,1},std::vector<Vec3>{{x,0,0},{x,3,x==5?6.:2.},{x,7,x==5?6.:2.},{x,10,0}});o.guides.push_back({{c,c->domain()}});o.guideConditions.push_back({1,1});}auto shape=loftSheet({a,b},o);if(shape.faces().size()!=2||!checkBody(shape).empty())throw std::runtime_error("invalid two-face loft");auto &s=*shape.face(shape.faces()[0]).surface,&r=*shape.face(shape.faces()[1]).surface;double gap=0,angle=0;for(int k=1;k<100;++k){double v=k/100.;gap=std::max(gap,distance(s.point(1,v),r.point(0,v)));auto n=normalAt(s,1,v),m=normalAt(r,0,v);angle=std::max(angle,std::atan2(norm(cross(n,m)),dot(n,m))*180/kPi);}std::cout.precision(15);std::cout<<"faces=2 gap="<<gap<<" maximumMiddleGuideNormalJumpDegrees="<<angle<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
