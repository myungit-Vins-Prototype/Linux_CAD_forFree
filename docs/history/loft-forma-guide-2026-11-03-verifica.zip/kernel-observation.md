# Osservazione della suite kernel

Prima dei ritest mirati, root ha letto direttamente il LastTest.log della suite completa:
`459/459 test superati`, `Test time = 357.97 sec`, `Test Passed`.
Il file LastTest.log e' stato poi sostituito da CTest eseguendo i15ritest; non e' un log cumulativo.
L'XML originale ctest-full.xml conserva il successo di forgekernel_tests e357.97s, ma tronca
lo stdout a1024byte. kernel-integrated.log e' quell'estratto troncato, non il log completo.
Nessun secondo giro dei459test e' stato lanciato per ricostruire un log gia' osservato.
