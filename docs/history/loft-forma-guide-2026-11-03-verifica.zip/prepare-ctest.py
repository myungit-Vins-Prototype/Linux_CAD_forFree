from pathlib import Path
import json,hashlib
r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release';o=Path('/tmp/forgecad-loft-shape-fix/ctest');o.mkdir(exist_ok=True);entries=[]
for source in b.rglob('CTestTestfile.cmake'):
 target=o/source.relative_to(b);target.parent.mkdir(exist_ok=True,parents=True);text=source.read_text().replace('FORGECAD_EXAMPLE_DIR=/home/myungit/Documenti/File_Esempio','FORGECAD_EXAMPLE_DIR=/tmp/forgecad-fix-fixtures');target.write_text(text);entries.append({'path':str(source.relative_to(b)),'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'frozen_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for name in ['config','cache','runtime']:(o/name).mkdir(exist_ok=True);(o/name).chmod(0o700)
for x in json.loads(Path('/tmp/forgecad-fix-fixtures/manifest.json').read_text()):assert hashlib.sha256((Path('/tmp/forgecad-fix-fixtures')/x['name']).read_bytes()).hexdigest()==x['sha256']
(o/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n');print(len(entries),'CTest manifests copied;3frozenexampleCADhashes PASS')
