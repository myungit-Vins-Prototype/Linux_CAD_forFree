# Loft9: baseline GUI e geometria interna

Baseline del 3 novembre 2026 sulla copia `/tmp/forgecad-loft-shape-fix/fixture/SurfaceModellingExample219.prt`, SHA256 `5e42109d8e7a7c2f40b0d027b59ab2001a7b62503678d5cc6701051db95dbf48`, 82240 byte. Feature salvata Loft9, indice8/id12, sezioni Schizzo8 curva2 e curva estratta3D id10; guida id11. La variante aggiunge guida id9, senza modificare le sezioni. Start/end G1 e guide G1, influenza1.

Nessuna modifica al repository, kernel, build principale, memoria o CAD originali. La sonda carica soltanto la copia congelata; le modifiche di visibilità e la seconda guida sono applicate in memoria. Non usa il vecchio `definition.h`. Per questa baseline costruisce e visualizza direttamente le due B-rep; le prove finali del pannello/anteprima/conferma/Undo/codec attendono il fix e la build coordinata.

## Esito

Il difetto è riprodotto nella B-rep salvata e rigenerata. La normale analitica ha salti interni persistenti riducendo la distanza parametrica da1e-7 a1e-9. Il controllo topologico e la sola validità della mesh non li rilevano.

| Misura | Una guida | Due guide |
| --- | --- | --- |
| Salto normale al nodo interno U=.5 |14.023663441639°|18.802667004237°|
| Massimo salto normale su nodi interni V |6.1295970919314°|21.680151427489°|
| UV del massimo V |(.425,.14776406290537)|(.88,.31175562924943)|
| Minimo seno tra Su e Sv, griglia interna99×99 |.5330991658393|.18498419882576|
| Facce / problemi checkBody |1 /0|1 /0|
| Facce mesh fallite |0|0|
| Massimo errore vertice mesh/superficie al suo UV |3.2561158711217e-14|3.2561158711217e-14|
| Gradi U,V e poli |3,5 /7×361|3,5 /7×841|

La B-rep con una guida è byte per byte identica a quella salvata: SHA256 `c4eedb5a527080d33076327c3aafb7cb41eea0ed22d50d1d26c8ee901c10643a`. Con due guide: `994d6fe5f782db053b82adba25c88a50dd0c90bf41beef2e2168de1141b333aa`. I vertici della mesh seguono la stessa superficie che contiene la cresta; una qualità di visualizzazione maggiore non la corregge. Il campionamento del Jacobiano non certifica l'assenza globale di pieghe o auto-intersezioni.

## Continuità delle sorgenti reali

Misure delle derivate esatte mediante `evaluateLeft`/`evaluate`, senza ricavare tangenti dalla mesh o dai pixel:

| Sorgente | Nodo | Angolo tangenti | Rapporto velocità sinistra/destra | Gap |
| --- | --- | --- | --- | --- |
| Sezione superiore id10 |1|3.1820225581834°|1.352218803537|0|
| Guida id11 |1|8.9064e-15°|1|0|
| Guida id11 |2|2.6719e-14°|2.4|0|
| Seconda guida id9 |1|3.7453e-15°|1.4592623105761|0|
| Seconda guida id9 |2|3.8094e-14°|4.4354560021954|5.2161e-14|
| Seconda guida id9 |3|1.6627e-15°|1.1248442845187|0|

La sezione superiore contiene quindi un corner geometrico reale; non si attribuisce automaticamente ogni cresta al loft. Le due guide hanno invece direzione tangente continua nei loro nodi, con salti della velocità parametrica: il loft introduce salti della normale molto maggiori, da separare dal corner della sezione. Questa evidenza è stata comunicata all'agente kernel, che sta studiando l'amplificazione parametrica e il fit. Nessuna modifica di tolleranza proposta dalla QA.

## Rendering nativo e viste

Wayland reale: Intel UHD Graphics P630, OpenGL4.6 Core Mesa26.2.5-arch3.1, contesto valido e `GL_NO_ERROR`. Prima acquisizione a qualità0 conservata in `baseline-wayland/`; la qualità0 è minima: deflessione diagonale×4e-3, angolo.5rad. Per il confronto visivo definitivo usare `baseline-wayland-high-zup/`, qualità2: diagonale×2e-4, angolo.1rad. La qualità predefinita1 usa1e-3/.25rad.

Le immagini ad alta qualità sono state ispezionate. Piani, assi, griglia, riferimenti e altri corpi sono nascosti solo nella copia in memoria. Sono mantenuti i frame iniziali `*-clean.png` e `*-reverse.png`; aggiunti due frame con Z rivolto verso l'alto, vettori normalizzati e right ortogonale, da riutilizzare dopo il fix:

- `*-zup-front.png`: normale(-1,-1,.7), right(1,-1,0).
- `*-zup-rear.png`: normale(1,1,.7), right(-1,1,0).

La camera viene adattata ai limiti del corpo, separatamente per variante. I frame sono uguali tra varianti; dimensione e centratura seguono il fit della loro B-rep. [Una guida, Z su](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland-high-zup/one-guide-zup-front.png), [due guide, Z su](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland-high-zup/two-guides-zup-front.png), [due guide, retro](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland-high-zup/two-guides-zup-rear.png).

## Riproducibilità

Sonda [loft-shape-gui.cpp](/tmp/forgecad-loft-shape-fix/gui-qa/loft-shape-gui.cpp), compilazione [build-gui.py](/tmp/forgecad-loft-shape-fix/gui-qa/build-gui.py), [link esatto](/tmp/forgecad-loft-shape-fix/gui-qa/loft-shape-gui-link.json). Sostituito soltanto il main test, collegando gli oggetti di produzione correnti. [Manifesto alto con SHA di tutti gli input collegati e degli artefatti](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-high-linked-artifacts.json); [prima registrazione qualità0](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-linked-objects.json). Nessun oggetto kernel sperimentale collegato.

Log: [prima baseline](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland.log), [alta con misure sorgenti](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland-high.log), [alta con viste Z su](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-wayland-high-zup.log). Le B-rep misurate sono conservate nelle rispettive cartelle come `.body`.

L'originale `/home/myungit/Documenti/Cad_Example/SurfaceModellingExample219.prt` è stato riletto soltanto per SHA e dimensioni nel manifesto alto. Il programma riceve esclusivamente il percorso della copia temporanea e non salva documenti. Le verifiche finali richieste, dopo il fix, rimangono da eseguire sulla produzione ricompilata: pannello/anteprima, conferma e modifica della feature salvata, Undo/Redo, codec con/senza cache, Wayland e XCB, con immagini ad alta qualità confrontabili.
