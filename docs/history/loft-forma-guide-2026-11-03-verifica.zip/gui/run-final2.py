from pathlib import Path
import os, subprocess, json, hashlib, datetime, sys
q=Path('/tmp/forgecad-loft-shape-fix/gui-qa')
platform=sys.argv[1]
assert platform in ['wayland','xcb']
label='final2-'+platform
out=q/label
out.mkdir(exist_ok=True)
link=json.loads((q/'loft-final-gui-link.json').read_text())
objects=[]
for arg in link['argv']:
    if arg.endswith(('.o','.a')):
        p=Path(arg)
        if not p.is_absolute(): p=Path(link['cwd'])/p
        objects.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert not any('/kernel-agent/' in x['path'] for x in objects)
env=os.environ.copy()
env.update(QT_QPA_PLATFORM=platform, QT_QPA_PLATFORMTHEME='', QT_STYLE_OVERRIDE='Fusion')
argv=[str(q/'loft-final-gui'),'/tmp/forgecad-loft-shape-fix/fixture/SurfaceModellingExample219.prt',str(out),'--gl']
with (q/(label+'.log')).open('w') as log:
    p=subprocess.run(argv,cwd=q,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in objects)
meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform,'argv':argv,'exit_code':p.returncode,'linked_inputs':objects,'input_hashes_unchanged':True,'probe_sha256':hashlib.sha256((q/'loft-final-gui').read_bytes()).hexdigest()}
(q/(label+'-run.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(label,'exit',p.returncode,flush=True)
if p.returncode: print((q/(label+'.log')).read_text()[-3000:])
raise SystemExit(p.returncode)
