# Loft9: QA finale della produzione

**Final2 completato sulla build definitiva.** Include la guardia in `cad_document_io.cpp` che limita la migrazione alle copie di lavoro (`checkinId` nullo), preservando gli snapshot delle revisioni archiviate. Entrambi i backend sono stati ricollegati ed eseguiti nuovamente dopo il VIA. Il checkpoint precedente resta in [checkpoint-before-revision-guard-gui-qa.md](/tmp/forgecad-loft-shape-fix/gui-qa/checkpoint-before-revision-guard-gui-qa.md), con i suoi log e hash; kernel e B-rep sono invariati.

**Wayland e XCB: entrambi PASS** sul prodotto ricompilato, con pannello reale e passaggio una→due→una guida. Verifica del 3 novembre 2026, dopo il VIA del coordinatore per la build completa. I risultati di questo rapporto sostituiscono le verifiche preliminari sulle B-rep sperimentali: la produzione finale usa il peso smoothstep e la velocità comune G1; ha B-rep diverse dal candidato precedente.

## Provenienza e isolamento

Fixture `/tmp/forgecad-loft-shape-fix/fixture/SurfaceModellingExample219.prt`, 82240 byte, SHA256 `5e42109d8e7a7c2f40b0d027b59ab2001a7b62503678d5cc6701051db95dbf48`. Loft9 indice8/id12, sezioni Schizzo8 curva2 e curva estratta3D id10; prima guida id11, variante con seconda guida id9. Estremi G1, entrambe le guide G1 e influenza100%.

Sonda [loft-final-gui.cpp](/tmp/forgecad-loft-shape-fix/gui-qa/loft-final-gui.cpp), compilata con [build-final-gui.py](/tmp/forgecad-loft-shape-fix/gui-qa/build-final-gui.py). Collega tutti i moduli di produzione attuali del runner, sostituendo esclusivamente il main test; nessun oggetto del kernel sperimentale. [Comando esatto di link](/tmp/forgecad-loft-shape-fix/gui-qa/loft-final-gui-link.json), [manifesto SHA256 degli input e artefatti](/tmp/forgecad-loft-shape-fix/gui-qa/final2-linked-artifacts.json). I 100 input di produzione sono rimasti identici durante le prove; il main del runner comune è escluso e sostituito dal main della sonda. Il medesimo binario della sonda è usato nei due run final2.

Nessun sorgente del prodotto, build principale, Git o CAD originale modificato dall'agente GUI. Impostazioni della sonda temporanee e isolate. Nessun processo utente chiuso. Visibilità di piani e riferimenti semplificata soltanto in memoria; il programma legge esclusivamente la copia congelata e salva le demo in `/tmp`.

## Percorsi realmente verificati

| Fase | Wayland | XCB |
| --- | --- | --- |
| Decode della fixture: vecchia cache del documento con Loft attivo scartata interamente |PASS|PASS|
| Load: rigenerazione automatica di Loft9, senza modificare la definizione |PASS|PASS|
| Pannello una guida: anteprima, Conferma e update della feature8/id12 |PASS|PASS|
| Aggiunta della guida id9 mediante pulsante e click reale nella vista; Esc termina soltanto il picker |PASS|PASS|
| Pannello due guide: anteprima, Conferma e update della stessa feature |PASS|PASS|
| Ritorno a una guida dal pannello |PASS|PASS|
| Undo/Redo dopo ciascuna Conferma: B-rep precedente e successiva esatte |PASS|PASS|
| Salva/riapri separatamente una e due guide, con cache8 e senza cache |PASS|PASS|
| B-rep riaperta identica byte per byte alla Conferma in entrambi i modi |PASS|PASS|
| Qualità alta2, viste Z su e frontali BROAD, Rivoluzione3 e Loft9 entrambi visibili, GL valido senza errori |PASS|PASS|

Il load automatico produce già la nuova B-rep, prima di aprire il pannello. Il decoder non restituisce più la vecchia geometria con cresta né il resto dello snapshot precedente. Le copie salvate con cache8 conservano invece la B-rep nel decoder; quelle senza cache la rigenerano. Non serve alterare la definizione per recuperare il caso originale. Dopo il passaggio due→una guida, la B-rep torna esattamente uguale a quella nuova generata al primo load. Il numero totale di feature rimane9 e Loft9 mantiene id12.

Log finali: [Wayland](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland.log), [XCB](/tmp/forgecad-loft-shape-fix/gui-qa/final2-xcb.log). Entrambi terminano con il PASS completo. Nessun assert geometrico o di persistenza è stato indebolito.

## Misure indipendenti sulla B-rep finale

| Misura | Una guida, baseline → finale | Due guide, baseline → finale |
| --- | --- | --- |
| Salto normale al nodo interno U=.5, epsilon1e-9 |14.023663° →3.181969°|18.802667° →3.170907°|
| Massimo scarto delle normali sui nodi interni V, epsilon1e-9 |6.129597° →6.6216e-7°|21.680151° →7.9788e-7°|
| Stessa misura V, epsilon1e-7 |6.129596° →6.6216e-5°|21.680146° →7.9787e-5°|
| Minimo seno tra Su e Sv sulla griglia interna99×99 |.533099 →.881169|.184984 →.854164|
| checkBody / facce mesh fallite |0 /0|0 /0|
| Massimo scarto vertice mesh/superficie al suo UV |7.2462e-14 finale|7.3842e-14 finale|

Lo scarto V ora diminuisce di circa100 volte riducendo di100 volte la distanza parametrica: non rimane il salto finito della baseline. Il salto U è nell'ordine del corner geometrico reale della sezione superiore, misurato indipendentemente a3.182022558°. Non si dichiara liscia una sorgente che contiene realmente un angolo. Le guide sono geometricamente G1 ma hanno velocità parametriche discontinue: misure delle sorgenti in [baseline-gui-qa.md](/tmp/forgecad-loft-shape-fix/gui-qa/baseline-gui-qa.md).

I controlli su griglia e normali sono indipendenti dalla mesh, ma rimangono campionati: non certificano l'assenza globale di pieghe o auto-intersezioni. Le verifiche analitiche del kernel, la suite completa e la mappa sono gestite dal coordinatore e non sono conteggiate come prove native di questo rapporto. Il controllo campionato delle distanze da sezioni/guide nel [rapporto candidato](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-gui-qa.md) riguarda quel precedente candidato, non viene attribuito alla produzione finale.

B-rep finali, uguali in preview, Conferma e riaperture di entrambi i backend:

- Una guida: `6969db03967533028a5c3d3124933a8689d903aa53c5d4bc55c533679a57babb`.
- Due guide: `5eece4b12e3864bec18809535fc0778836d1eba90c5ee79c53d5e0c6ce5311fc`.

La vecchia B-rep salvata, SHA `c4eedb5a…`, è conservata nella baseline e non viene riutilizzata nella produzione finale.

## Rendering e catture

Wayland: Intel UHD Graphics P630, OpenGL4.6 Core Mesa26.2.5-arch3.1. XCB: Quadro RTX3000, OpenGL3.3.0 NVIDIA615.78.08. Ogni cattura del viewport verifica contesto valido e `GL_NO_ERROR`. Qualità2 significa deflessione diagonale×2e-4 e angolo.1rad, rispetto alla qualità minima0 usata nella prima baseline.

Ispezionati pannelli, anteprime e risultati. Rivoluzione3 rimane visibile per rendere la vista confrontabile con il modello dell'utente. Frame Z su normalizzati: normale(-1,-1,.7), right(1,-1,0), e vista opposta; conservato anche il frame originale. Aggiunte due viste BROAD per osservare la lamina di faccia: normale(1,-1,.7), right(1,1,0), e normale(-1,1,.7), right(-1,-1,0), sempre normalizzati e ortogonali. Le viste pulite vengono acquisite dopo la chiusura del pannello, quindi non contengono la sfocatura del pannello traslucido. Le anteprime con pannello aperto mostrano invece deliberatamente tale sovrapposizione.

- [Una guida confermata, BROAD Wayland](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland/one-guide-confirmed-zup-broad-front.png).
- [Due guide confermate, BROAD Wayland](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland/two-guides-confirmed-zup-broad-front.png).
- [Due guide confermate, BROAD opposta XCB](/tmp/forgecad-loft-shape-fix/gui-qa/final2-xcb/two-guides-confirmed-zup-broad-rear.png).
- [Una guida confermata, fronte Wayland](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland/one-guide-confirmed-zup-front.png).
- [Due guide confermate, retro Wayland](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland/two-guides-confirmed-zup-rear.png).
- [Due guide confermate, fronte XCB](/tmp/forgecad-loft-shape-fix/gui-qa/final2-xcb/two-guides-confirmed-zup-front.png).
- [Pannello con due guide G1/100%](/tmp/forgecad-loft-shape-fix/gui-qa/final2-wayland/two-guides-panel.png).

Le coppie prima/dopo a identica camera, zoom e pan della verifica preliminare restano in `candidate-wayland/`; per la forma finale usare esclusivamente `final2-wayland/` e `final2-xcb/`.

## Diagnostico della sonda preservato

Il primo run Wayland si era fermato al click della seconda guida: il punto geometrico individuato dal ray picking cadeva sotto il pannello traslucido. Il filtro del pannello bloccava correttamente l'evento. La sonda ora esclude il rettangolo del pannello e clicca un punto realmente accessibile: pixel712,269, pannello16,55,540,930. Il log riporta `checked=2` dopo il click e la successiva pressione di Esc termina il picker senza chiudere il pannello.

Il FAIL iniziale è conservato in [initial-wayland-click-diagnostics.log](/tmp/forgecad-loft-shape-fix/gui-qa/initial-wayland-click-diagnostics.log), con catture nella cartella omonima. È una correzione della sonda, non un difetto del prodotto. Dopo questa correzione i due run finali sono entrambi completi.

## Demo e controllo degli originali

Copie con cache8, derivate dalle conferme del pannello XCB e salvate separatamente:

- [SurfaceModellingExample219-Loft9-una-guida.prt](/tmp/forgecad-loft-shape-fix/gui-qa/SurfaceModellingExample219-Loft9-una-guida.prt), 589508 byte, SHA256 `5bee520a1f11c647e2bae3bcbb603c7badc1adb9c3cb4616af3d7c00e2310510`.
- [SurfaceModellingExample219-Loft9-due-guide.prt](/tmp/forgecad-loft-shape-fix/gui-qa/SurfaceModellingExample219-Loft9-due-guide.prt), 961535 byte, SHA256 `47059b20d698e7831d1ce227fdbd5d6ac686a31ddf7c1ac02ca04915d17fb3e2`.

Le corrispondenti versioni senza cache sono conservate in ciascuna cartella di run. L'originale `/home/myungit/Documenti/Cad_Example/SurfaceModellingExample219.prt` è stato realmente riletto per SHA e dimensioni al termine della QA, alle 09:34:45 UTC del 3 novembre: 82240 byte e SHA `5e42109d…`, identico alla copia congelata. Nessuna scrittura all'originale, nessuna attribuzione ad altri processi.

Identità della build verificata, dettagli e dimensioni nel [manifesto finale](/tmp/forgecad-loft-shape-fix/gui-qa/final2-linked-artifacts.json): app SHA `2371554f96350959c0d4c85b98181fa246f6f8e4d77fe78cac864bac9db0cde0`, kernel statico `56bebfc5d6748ffaa544a55206d7d88647310d989b2c9beb886cb9bc1b73dab8`, sonda `62f8e530f46368928576d25d810c7acd4783e4a15d10fba36238da2ac994b8f4`. Runner finale SHA `1c8d315875528a3eebf3b02959634d75b909e6aa25daec89552c66257d039998`. Tutti gli artefatti elencati sono stati letti stabilmente dopo entrambi i run; il main del runner comune non è collegato alla sonda.
