# Loft9: verifica visiva preliminare del candidato

Esecuzione Wayland del 3 novembre 2026. **Candidato sperimentale, non integrato nell'app.** La sonda legge le due B-rep standalone congelate e le visualizza con gli oggetti di produzione precedenti; nessun oggetto kernel sperimentale è collegato. Non esercita pannello, preview, conferma o rigenerazione del prodotto aggiornato. Queste verifiche finali attendono il VIA del coordinatore.

Le copie sono state lette stabilmente e congelate prima della prova: [manifesto](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-frozen/manifest.json).

| B-rep | Byte | SHA256 |
| --- | --- | --- |
| Una guida |485440| `26a0fe4aabd62be6bd996250e68566dba1bec1b5024473b0c65513612585ea37` |
| Due guide |981304| `a7a32fc880ca89c94a72c26748d5171612f2ffee59ce0547d690b6ee49217988` |

La fixture resta quella SHA `5e42109d8e7a7c2f40b0d027b59ab2001a7b62503678d5cc6701051db95dbf48`, Loft9 indice8/id12. Le sezioni e le guide vengono risolte dalla sua definizione originale; per la variante a due guide si aggiunge soltanto il riferimento esatto alla curva estratta id9.

## Esito indipendente

La forma è visivamente migliorata: nella variante con due guide scompaiono la fascia trasversale e la pinzatura pronunciate della baseline. Rimane un cambio di forma presso la sezione superiore, coerente con il corner reale di3.182° della sorgente. Questa conclusione qualitativa non dichiara liscia una sezione che contiene realmente un angolo e non certifica l'assenza globale di auto-intersezioni.

| Misura interna | Una guida | Due guide |
| --- | --- | --- |
| Massimo salto U a epsilon1e-9 |3.2495936636395°|3.1477521197224°|
| V, distanza epsilon1e-7 |6.2420691e-5°|7.6898748e-5°|
| V, distanza epsilon1e-9 |6.2420969e-7°|7.6898089e-7°|
| Minimo seno Su/Sv, griglia99×99 |.66457264887086|.6492143624372|
| checkBody / facce mesh fallite |0 /0|0 /0|

Il residuo V diminuisce di circa100 volte riducendo la distanza di100 volte: non si osserva più il salto finito di6.13°/21.68° della baseline. Il salto U resta nell'ordine del corner reale della sezione. Le metriche sulla griglia sono campionate e non sono una prova globale di regolarità.

Ulteriore controllo indipendente:11 punti di ogni curva fonte esatta, inclusi gli estremi, proiettati sulla superficie candidata. Massimi scarti sezioni7.26e-14; guida id11 2.12e-10; seconda guida id9 2.92e-10. Si tratta di un controllo campionato, senza fit o variazioni di tolleranza. I vertici della mesh stanno sulla B-rep entro8.08e-14.

## Immagini confrontabili

Qualità2, assi Z verso l'alto, Rivoluzione3 e Loft9 visibili. Per ciascuna coppia prima/dopo sono mantenuti esattamente gli stessi frame, zoom e pan; la baseline determina il fit. Piani, schizzi e altri riferimenti sono nascosti nella sola copia in memoria. Acquisite anche viste aggiuntive con le guide esatte visibili ed evidenziate.

- [Una guida prima](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/baseline-1-guide-zup-front.png) / [una guida candidata](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/candidate-1-guide-zup-front.png).
- [Due guide prima, retro](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/baseline-2-guide-zup-rear.png) / [due guide candidate, retro](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/candidate-2-guide-zup-rear.png).
- [Due guide candidate, fronte](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/candidate-2-guide-zup-front.png), [con guide evidenziate](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland/candidate-2-guide-zup-front-with-guides.png).

Catture ispezionate. Contesto reale Intel UHD Graphics P630, OpenGL4.6 Core Mesa26.2.5-arch3.1, `GL_NO_ERROR`. [Log completo](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-wayland.log).

Sonda [loft-candidate-gui.cpp](/tmp/forgecad-loft-shape-fix/gui-qa/loft-candidate-gui.cpp), [link](/tmp/forgecad-loft-shape-fix/gui-qa/loft-candidate-gui-link.json), [SHA degli input e artefatti](/tmp/forgecad-loft-shape-fix/gui-qa/candidate-linked-artifacts.json). Compilazione riuscita, con soli warning di formattazione/una funzione diagnostica non usata nella sonda. Nessuna modifica al repository, alla build principale, alla memoria o agli originali. L'originale riletto per SHA rimane identico alla fixture congelata.
