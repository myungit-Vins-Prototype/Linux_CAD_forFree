from pathlib import Path
import subprocess,shlex
p=Path('/tmp/forgecad-loft-shape-fix/kernel-agent');r=Path('/home/myungit/Linux_CAD_forFree');a=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-I'+str(r/'kernel'),str(r/'kernel/tests/test_loft_projected_guides.cpp'),str(p/'fk_loft.o'),str(p/'fk_loft_profiles.o'),str(p/'libforgekernel-baseline.a'),'-pthread','-o',str(p/'projected-tests')];print(shlex.join(a),flush=True);subprocess.run(a,check=True);x=subprocess.run([str(p/'projected-tests')]);print('EXITCODE',x.returncode);raise SystemExit(x.returncode)
