from pathlib import Path
import subprocess,shlex,sys,os
p=Path('/tmp/forgecad-loft-shape-fix/kernel-agent');r=Path('/home/myungit/Linux_CAD_forFree');baseline='--baseline' in sys.argv
name='shape-baseline' if baseline else 'shape-tests';a=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-I'+str(r/'kernel'),str(p/'kernel/tests/test_loft_shape.cpp')]
if not baseline:a += [str(p/'fk_loft.o'),str(p/'fk_loft_profiles.o')]
a += [str(r/'forgecad-release/kernel/libforgekernel.a'),'-pthread','-o',str(p/name)];print(shlex.join(a),flush=True);subprocess.run(a,check=True);x=subprocess.run([str(p/name)]);print('EXITCODE',x.returncode);raise SystemExit(x.returncode)
