from pathlib import Path
import subprocess,os,shlex,hashlib
p=Path('/tmp/forgecad-loft-shape-fix/kernel-agent');r=Path('/home/myungit/Linux_CAD_forFree')
print('INSTRUMENTED_TUS kernel/fk_loft.cpp kernel/fk_loft_profiles.cpp kernel/tests/test_loft_shape.cpp',flush=True)
print('Reuse binaries compiled with flags and commands in sanitizer-lsan-unsupported.log; LSan cannot run under ptrace in this environment',flush=True)
print('OTHER_TUS baseline archive not instrumented; no full-app sanitizer claim',flush=True)
env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1');print('ENV ASAN_OPTIONS='+env['ASAN_OPTIONS']+' UBSAN_OPTIONS='+env['UBSAN_OPTIONS'],flush=True)
print(str(p/'shape-tests-asan'),flush=True);x=subprocess.run([str(p/'shape-tests-asan')],env=env);print('EXITCODE',x.returncode,flush=True)
if x.returncode:raise SystemExit(x.returncode)
source=r/'kernel/tests/test_loft_projected_guides.cpp';print('PROJECTED_TEST_SHA256',hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
print('INSTRUMENTED_TUS kernel/fk_loft.cpp kernel/fk_loft_profiles.cpp kernel/tests/test_loft_projected_guides.cpp',flush=True)
a=['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-sanitize-recover=all','-I'+str(p/'kernel'),'-I'+str(r/'kernel'),'-c',str(source),'-o',str(p/'projected-tests.asan.o')];print(shlex.join(a),flush=True);subprocess.run(a,check=True)
a=['c++','-fsanitize=address,undefined',str(p/'projected-tests.asan.o'),str(p/'fk_loft.asan.o'),str(p/'fk_loft_profiles.asan.o'),str(p/'libforgekernel-baseline.a'),'-pthread','-o',str(p/'projected-tests-asan')];print(shlex.join(a),flush=True);subprocess.run(a,check=True)
print(str(p/'projected-tests-asan'),flush=True);x=subprocess.run([str(p/'projected-tests-asan')],env=env);print('EXITCODE',x.returncode,flush=True);raise SystemExit(x.returncode)
