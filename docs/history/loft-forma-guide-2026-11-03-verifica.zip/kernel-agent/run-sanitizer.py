from pathlib import Path
import subprocess,shlex,os,hashlib,shutil,json
p=Path('/tmp/forgecad-loft-shape-fix/kernel-agent');r=Path('/home/myungit/Linux_CAD_forFree');archive=p/'libforgekernel-baseline.a';expected=json.loads((p/'baseline-hashes.json').read_text())['forgecad-release/kernel/libforgekernel.a']
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
if not archive.exists():shutil.copyfile(r/'forgecad-release/kernel/libforgekernel.a',archive)
if sha(archive)!=expected:raise RuntimeError('Archivio supporto diverso dal baseline dichiarato')
print('SUPPORT_LIBRARY_SHA256',expected,flush=True)
print('INSTRUMENTED_TUS kernel/fk_loft.cpp kernel/fk_loft_profiles.cpp kernel/tests/test_loft_shape.cpp',flush=True)
print('OTHER_TUS baseline support archive not instrumented; this does not certify the full application',flush=True)
objects=[]
for name in ['kernel/fk_loft.cpp','kernel/fk_loft_profiles.cpp','kernel/tests/test_loft_shape.cpp']:
 obj=p/(Path(name).stem+'.asan.o');objects.append(str(obj));a=['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-sanitize-recover=all','-I'+str(p/'kernel'),'-I'+str(r/'kernel'),'-c',str(p/name),'-o',str(obj)];print(shlex.join(a),flush=True);subprocess.run(a,check=True)
a=['c++','-fsanitize=address,undefined']+objects+[str(archive),'-pthread','-o',str(p/'shape-tests-asan')];print(shlex.join(a),flush=True);subprocess.run(a,check=True)
env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1');print('ASAN_OPTIONS='+env['ASAN_OPTIONS']+' UBSAN_OPTIONS='+env['UBSAN_OPTIONS'],flush=True);x=subprocess.run([str(p/'shape-tests-asan')],env=env);print('EXITCODE',x.returncode,flush=True);raise SystemExit(x.returncode)
