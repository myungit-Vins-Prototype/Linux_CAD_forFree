from pathlib import Path
import json,subprocess,shlex,os
r=Path('/home/myungit/Linux_CAD_forFree');b=r/'forgecad-release';p=Path('/tmp/forgecad-loft-shape-fix/kernel-agent')
for name in ["fk_loft_profiles","fk_loft"]:
 c=next(x for x in json.loads((b/'compile_commands.json').read_text()) if x['file']==str(r/'kernel/fk_loft.cpp'));a=shlex.split(c['command']);a[a.index('-o')+1]=str(p/(name+'.o'));a[-1]=str(p/'kernel'/(name+'.cpp'));a[1:1]=['-I'+str(p/'kernel'),'-I'+str(r/'kernel')];print(shlex.join(a),flush=True);subprocess.run(a,cwd=b,check=True)
a=shlex.split((b/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());a[a.index('-o')+1]=str(p/'measure-staged')
for i,x in enumerate(a):
 if x=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':a[i]=str(p/'measure.o')
 elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(p/'measure-staged.d')
i=a.index('kernel/libforgekernel.a');a[i:i]=[str(p/'fk_loft.o'),str(p/'fk_loft_profiles.o')];print(shlex.join(a),flush=True);subprocess.run(a,cwd=b,check=True)
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QT_QPA_PLATFORMTHEME='',QT_STYLE_OVERRIDE='Fusion');x=subprocess.run([str(p/'measure-staged'),str(p.parent/'fixture/SurfaceModellingExample219.prt')],env=env);print('EXITCODE',x.returncode);raise SystemExit(x.returncode)
