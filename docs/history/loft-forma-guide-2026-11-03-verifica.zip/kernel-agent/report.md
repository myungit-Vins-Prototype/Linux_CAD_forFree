# Forma loft con guide proiettate — pacchetto congelato

Base `6e9a5f5827ff031b070e68796ee4f008019d59c0`. File di integrazione e hash prima/dopo in `manifest.json`; patch in `loft-shape.patch`. Nessuna scrittura nel checkout, sugli originali CAD, sui lock o sui processi utente. La build di produzione, la migrazione delle cache, la mappa e la memoria sono gestite da root.

## Documento e riproduzione

Copia congelata: `/tmp/forgecad-loft-shape-fix/fixture/SurfaceModellingExample219.prt`, 82240 byte, SHA256 `5e42109d8e7a7c2f40b0d027b59ab2001a7b62503678d5cc6701051db95dbf48`. Screenshot del problema e della forma attesa esaminati.

Questa copia contiene **Loft9**, owner/body index8, featureId12. Non usa la definizione della precedente indagine `planarImage`:

- prima sezione: Schizzo8, index7, entità curva index1 (`kind7`, element1/1);
- seconda sezione: Curva estratta3D3, body6, featureId10 (`kind9`);
- guida salvata: Curva estratta3D4, body7, featureId11;
- guida aggiunta nella variante: Curva estratta3D5, body5, featureId9;
- superficie liscia, G1 iniziale/finale, guide G1 e influenza1.

`inspect.log` contiene i riferimenti completi. `measure.log` è la riproduzione baseline; `final-build.log` la ripetizione sul kernel corretto. Vengono ricostruite sei varianti dalla definizione, senza usare la vecchia cache di Loft9. Le misure usano superficie e jet B-rep analitici, mai mesh/display.

## Cause matematiche distinte

1. `hermiteRow` orientava separatamente ogni polo conservando il modulo del suo spostamento. Questa trasformazione nonlineare non conserva le relazioni fra poli ai nodi: inserire nodi ridondanti, a geometria e parametro identici, cambiava la forma di circa 0.007 unità nel caso sintetico polinomiale. La stessa prova razionale cambiava di 0.118 unità.
2. Le due guide reali sono geometricamente G1 ai raccordi ma hanno velocità parametriche discontinue: fino a rapporto2.4 nella guida salvata e4.435 nella guida aggiunta. `followingGuide` raccordava il parametro grezzo; la somma delle correzioni al campo base trasformava i salti di modulo in creste interne V. La sorgente guida è esatta, il difetto era nel suo uso nel loft.
3. Le sezioni hanno denominatori razionali diversi. Blendare direttamente le loro coordinate omogenee, con derivate di peso differenti ai raccordi, amplificava le discontinuità apparenti. `standardBezierPieces` introduce inoltre riparametrizzazioni di Möbius indipendenti dei Bezier: conservano la curva, ma cambiano le velocità ai giunti.
4. Il passaggio da una a due guide cambiava anche la costruzione del campo base delle righe interne (`originalSpread`), facendo variare la forma oltre alla nuova condizione imposta.

Esiste anche un **corner reale nella seconda sezione**, di circa3.182022558°, fra curva e segmento dello Schizzo4 (confermato dall'audit indipendente di root). Non è un fit della proiezione né un difetto di estrazione. Va conservato: non si può promettere G1 ovunque fino a quel bordo senza cambiare il profilo scelto.

## Implementazione

`kernel/fk_loft_profiles.{h,cpp}` isola le nuove operazioni algebriche esatte sui profili:

- mantiene il parametro dei Bezier razionali, elevandone il grado senza Möbius indipendenti;
- pareggia i moduli ai giunti con velocità differenti mediante composizioni cubiche monotone, rappresentate tramite prodotti Bernstein esatti. La geometria delle sezioni e gli angoli reali rimangono identici; nessun fit dei profili;
- rende comune il denominatore: per `C_i=H_i/W_i`, usa `D=prodotto(W_j)` e `H_i'=H_i*prodotto(W_j,j!=i)`. In questo modo il blend è euclideo. Se i denominatori sono già identici vengono riusati;
- calcola esattamente anche i coefficienti dei prodotti `D*(1-H(u))` e `D*H(u)`, con `H(u)=3u²-2u³`. Le correzioni hanno derivata U nulla sulle guide interne, evitando una regressione concreta con tre guide di incurvamenti differenti;
- verifica numeri finiti e pesi positivi; limita il grado algebrico a128 con errore esplicito, senza fallback geometrico. I nuovi cicli numerici sono cancellabili.

Il riconoscimento dei salti di velocità distingue il bound di arrotondamento dei jet (`epsilon*grado*scalaCoordinate/span`) da una tolleranza geometrica. I tratti di pochi ulp restano presenti; non si pretende di imporre nuovi jet non rappresentabili in tali intervalli.

`kernel/fk_loft.cpp`:

- usa per G1/G2 un modulo comune per sezione, ricavato dalla distanza fra i centroidi e dall'intervallo V. Il campo non dipende dal numero dei poli e non si annulla quando la corda è perpendicolare alla normale G1;
- mantiene il campo base delle sezioni aperte indipendente dal numero delle guide;
- valuta ogni guida originale nella coordinata curvilinea, invertendo l'integrale di lunghezza con le routine esistenti. I jet rispetto alla lunghezza sono tangente unitaria e curvatura, quindi non saltano nei giunti geometricamente G1 a velocità diversa;
- distribuisce le correzioni con i prodotti Bernstein pesati descritti sopra;
- evita di aggiungere un nodo **ausiliario** uniforme di collocazione se un nodo esistente dista pochi ulp. Non accorpa né rimuove nodi sorgenti. Questa precauzione evita di creare campate numeriche spurie dopo l'elevazione del grado; la regressione delle campate di un ulp con geometria distinta resta attiva.

I loft rigati mantengono la pipeline precedente. Nessun nuovo tipo persistito o variazione di ABI pubblica; superfici finali sempre NURBS ordinarie. Formato nativo60 e BodyIO invariati. La migrazione delle vecchie cache Loft è una patch separata di root.

## Risultati misurati sul CAD congelato

| Misura analitica | Baseline1guida | Finale1guida | Baseline2guide | Finale2guide |
| --- | ---: | ---: | ---: | ---: |
| salto massimo normali al giunto U |14.023663°|3.181755°|18.802667°|3.168350°|
| salto massimo ai nodi V, offset1e-10 |6.128100°|6.62e-8°|21.680151°|7.98e-8°|
| minimo seno fra Su/Sv, griglia interna |0.533155|0.881234|0.185157|0.855384|

Il residuo U è collegato al corner reale della sezione e si concentra presso quel bordo. Le guide geometricamente G1 non introducono più un salto finito V. La griglia dei jet conferma regolarità sui punti verificati; non costituisce una certificazione globale di assenza di auto-intersezioni.

Risultato1guida: gradi21×5,43×341poli, BodyIO502736byte;2guide: gradi21×5,43×711poli, BodyIO1038496byte. Il grado maggiore è il costo della rappresentazione razionale algebrica esatta, senza approssimare i profili. Roundtrip BodyIO dei due corpi reali: coordinate identiche sui441punti di verifica (`body-summary.log`).

Root e gui_3d hanno eseguito verifiche indipendenti su candidati precedenti: confermano che le creste sono B-rep e non triangolazione, e che la forma con due guide migliora senza la precedente fascia/pinzatura. La QA nativa finale con la build di produzione è gestita da loro; questi esiti non vengono attribuiti alle sole sonde kernel qui compilate.

## Prove riproducibili

- `python3 run-shape-tests.py --baseline`: **3/9 gruppi PASS,6FAIL causali**, exit1. Il vecchio kernel fallisce invarianza ai nodi polinomiali/razionali, raccordi G1 nonuniformi, guide con velocità discontinua e invarianza al parametro della guida.
- `python3 run-shape-tests.py`: **9/9 gruppi PASS**, exit0. Include0/1/2guide, ordine/verso guide, tre guide con incurvamenti diversi, jet e regolarità interna, profili esatti, conservazione del corner vero, G1 con corda perpendicolare e BodyIO.
- `python3 run-full-kernel.py Loft`: **42/42 test preesistenti PASS**, exit0. Comprende `LoftG1SingleUlpSpanKeepsDistinctCollocationPoints`, `LoftPreservesDistinctNearbyKnots`, contatti circolari G1/G2, campate di guida disuguali, offset e genealogia.
- `python3 run-projected-tests.py`: **10/10 gruppi guide implicite PASS**, exit0; sezioni/guide esatte entro i budget dell'operatore, trasformazioni, più sezioni, verso, rank1, assenza/ambiguità di incrocio, nonplanarità e BodyIO.
- `build-staged.py` compila solo oggetti/eseguibili in /tmp e ricostruisce il CAD congelato con i supporti della build ABI coerente iniziale. Non va rilanciato mentre root aggiorna quella build.

Supporto congelato per test isolati: `libforgekernel-baseline.a`, SHA256 `15b70a2921f445ac3e0bff628023b443538edb83fafa0f292272f0a01f15b961`; la copia è indipendente dall'archivio ricostruito da root. Nei log sono presenti comandi ed exitcode. La suite completa459 e la build app vengono eseguite da root dopo integrazione.

## Limiti e integrazione

Guide e sezioni sorgenti rimangono esatte. Il bordo del loft segue la guida tramite il procedimento adattivo Hermite/quintico preesistente, tolleranza1e-9 mm e controlli indipendenti fino a4e-9 mm, invariati. Non si dichiara coincidenza algebrica del bordo NURBS con qualsiasi guida implicita. L'inversione della lunghezza non crea una nuova curva approssimata sorgente.

Non viene arrotondato il corner reale del profilo. Se servisse G1 anche in quel punto occorrerebbe modificare esplicitamente lo schizzo. Restano i limiti precedenti delle sezioni realmente nonplanari/guide complanari, dell'eventuale eccesso di grado o intervallo numerico e dell'assenza di certificazione globale di auto-intersezione.

`kernel/CMakeLists.txt` nel pacchetto aggiunge la nuova TU e `forgekernel_loft_shape_tests`, indipendente da OCCT. Descrizione architetturale suggerita: **fk_loft_profiles — compatibilità esatta dei profili loft, normalizzazione parametrica e denominatori Bernstein comuni, coefficienti pesati delle correzioni guida; nessun fit della geometria sorgente**. Il coordinatore fk_loft delega queste responsabilità e conserva la costruzione topologica/Hermite.

## ASan/UBSan sullo snapshot finale

**PASS9/9 nuovi gruppi e10/10 gruppi guide implicite, exitcode0 senza diagnostici ASan/UBSan** (`sanitizer.log`). Compilati con `-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fno-sanitize-recover=all -ffp-contract=off`.

Per i9gruppi sono strumentate esattamente le TU `kernel/fk_loft.cpp`, `kernel/fk_loft_profiles.cpp`, `kernel/tests/test_loft_shape.cpp`; per i10gruppi sono strumentate le due TU di produzione precedenti e `kernel/tests/test_loft_projected_guides.cpp`. Archivio supporto baseline e librerie di sistema non strumentati: non è una verifica sanitizer dell'app completa.

Ambiente finale: `ASAN_OPTIONS=detect_leaks=0:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`. Il primo tentativo aveva già superato9/9 casi ma LeakSanitizer terminava con errore ambientale `does not work under ptrace` (`sanitizer-lsan-unsupported.log`); non viene quindi attestata l'assenza di leak. `run-sanitizer.py` ricompila le tre TU e ripete9gruppi; `run-sanitizer-reuse.py` registra il riuso degli stessi oggetti e compila la TU dei10gruppi. Nessuna sorgente è cambiata fra le prove. Hash del pacchetto congelato e della fixture ricontrollati dopo la prova: tutti identici al manifest.
