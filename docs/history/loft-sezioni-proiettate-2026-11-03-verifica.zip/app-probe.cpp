#include <QtWidgets>
#include "forgeCad2026_viewport_internal.h"
#include "fk_sketch_projection.h"
#include "fk_body_check.h"
#include <iostream>
static void require(bool ok,const char *text){if(!ok)throw std::runtime_error(text);}
class ViewportInteractionTest {public:
#include "tests/test_loft_projected_sections.h"
};
int main(int argc,char**argv){QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADSectionsQA");QCoreApplication::setApplicationName("Sections");QTemporaryDir prefs;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,prefs.path());try{ViewportInteractionTest::loftProjectedSections();return 0;}catch(const std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}}
