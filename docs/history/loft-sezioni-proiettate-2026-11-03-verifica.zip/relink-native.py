from pathlib import Path
import subprocess,shlex
r=Path('/home/myungit/Linux_CAD_forFree');q=Path('/tmp/forgecad-loft-sections');b=r/'forgecad-release'
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(q/'native.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(q/'native');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(q/'native.d') for x in a];subprocess.run(a,cwd=b,check=True)
