# Verifica mappa CI

Rigenerazione e controllo di aggiornamento PASS: 548 file, 7572 relazioni, 258 unità AST, zero errori. Verificati sette confini di chiamata risolta e i conteggi entranti/uscenti di call/include/reference separati (architecture-checked.json).

HTML visualizzato con Firefox headless e profilo isolato a 1600×1100, dettaglio cad_revision_store.cpp: descrizione della lettura ottimistica corretta, predecessori e destinatari, collegamenti e liste distinte entrata/uscita visibili. Verificato anche il blocco kernel/fk_offset.cpp: descrizione delle sezioni analitiche, collegamenti entranti (incluso fk_draft.cpp) e uscenti distinti. Screenshot architecture-revisions.png e architecture-offset.png. La prima invocazione non aveva la cartella del profilo; creata e rieseguita con esito0. Nessun processo browser utente modificato.
