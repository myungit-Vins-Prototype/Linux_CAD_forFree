#include "cad_revision_store.h"

#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLockFile>
#include <QElapsedTimer>
#include <QThread>
#include <QSaveFile>
#include <QSet>
#include <algorithm>
#include <functional>
#include <stdexcept>

namespace ForgeCad {
namespace {
constexpr qint64 kMaxCatalogBytes = 16 * 1024 * 1024;
constexpr qint64 kMaxPayloadBytes = 256 * 1024 * 1024;
constexpr qsizetype kMaxDocuments = 10000, kMaxRevisions = 100000, kMaxDependencies = 10000;
struct StoredDocument { RevisionDocumentInfo info; RevisionCheckout checkout; };
struct StoredRevision { RevisionRecord record; QByteArray requestHash; };
struct Catalog {
    QUuid archiveId;
    QVector<StoredDocument> documents;
    QVector<StoredRevision> revisions;
};

class CatalogBusy final : public std::runtime_error {
public:
    CatalogBusy() : std::runtime_error("Archivio temporaneamente occupato; riprovare la lettura.") {}
};

void require(bool ok, const QString &message) {
    if (!ok) throw std::runtime_error(message.toStdString());
}
QString text(const QUuid &id) { return id.isNull() ? QString() : id.toString(QUuid::WithoutBraces); }
QUuid uuid(const QJsonValue &value, bool optional = false) {
    require(value.isString(), QStringLiteral("Identita' dell'archivio non valida."));
    const QString s = value.toString();
    if (optional && s.isEmpty()) return {};
    const QUuid id(s);
    require(!id.isNull(), QStringLiteral("Identita' nulla o malformata nell'archivio."));
    return id;
}
QString string(const QJsonValue &value, qsizetype limit, bool nonempty = false) {
    require(value.isString(), QStringLiteral("Metadato testuale dell'archivio non valido."));
    const auto s = value.toString();
    require(s.size() <= limit && (!nonempty || !s.trimmed().isEmpty()), QStringLiteral("Metadato testuale vuoto o troppo lungo."));
    return s;
}
QByteArray digest(const QByteArray &bytes) { return QCryptographicHash::hash(bytes, QCryptographicHash::Sha256); }
QByteArray hashValue(const QJsonValue &value) {
    const QByteArray hex = string(value, 64, true).toLatin1();
    require(hex.size() == 64 && std::all_of(hex.begin(), hex.end(), [](char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
    }), QStringLiteral("Impronta SHA256 dell'archivio non valida."));
    return QByteArray::fromHex(hex);
}
QDateTime date(const QJsonValue &value) {
    const auto result = QDateTime::fromString(string(value, 40, true), Qt::ISODateWithMs);
    require(result.isValid() && result.offsetFromUtc() == 0, QStringLiteral("Data UTC dell'archivio non valida."));
    return result.toUTC();
}
QJsonObject versionJson(const DocumentVersion &version) {
    return {{"documentId", text(version.documentId)}, {"checkinId", text(version.checkinId)}};
}
QJsonArray dependenciesJson(const QVector<DocumentVersion> &dependencies) {
    QJsonArray result;
    for (const auto &d : dependencies) result.append(versionJson(d));
    return result;
}
QJsonObject checkoutJson(const RevisionCheckout &checkout) {
    return {{"token", text(checkout.token)}, {"base", text(checkout.baseCheckinId)}, {"owner", checkout.owner},
            {"createdUtc", checkout.createdUtc.toUTC().toString(Qt::ISODateWithMs)}};
}
QJsonObject catalogJson(const Catalog &catalog) {
    QJsonArray documents, revisions;
    for (const auto &d : catalog.documents) {
        QJsonObject entry{{"id", text(d.info.documentId)}, {"name", d.info.name}, {"kind", d.info.kind}, {"head", text(d.info.headCheckinId)}};
        entry["checkout"] = d.checkout.token.isNull() ? QJsonValue(QJsonValue::Null) : QJsonValue(checkoutJson(d.checkout));
        documents.append(entry);
    }
    for (const auto &stored : catalog.revisions) {
        const auto &r = stored.record;
        revisions.append(QJsonObject{{"version", versionJson(r.version)}, {"previous", text(r.previousCheckinId)},
            {"sequence", QString::number(r.sequence)}, {"technicalRevision", r.technicalRevision}, {"author", r.author},
            {"comment", r.comment}, {"createdUtc", r.createdUtc.toUTC().toString(Qt::ISODateWithMs)},
            {"sha256", QString::fromLatin1(r.sha256.toHex())}, {"size", QString::number(r.payloadSize)},
            {"dependencies", dependenciesJson(r.dependencies)}, {"requestHash", QString::fromLatin1(stored.requestHash.toHex())}});
    }
    return {{"format", "ForgeCAD.RevisionArchive"}, {"schema", 1}, {"archiveId", text(catalog.archiveId)},
            {"documents", documents}, {"revisions", revisions}};
}

Catalog parseCatalog(const QByteArray &bytes) {
    require(!bytes.isEmpty()&&bytes.size()<=kMaxCatalogBytes,QStringLiteral("Catalogo assente o oltre i limiti."));
    QJsonParseError error;
    const auto json = QJsonDocument::fromJson(bytes, &error);
    require(error.error == QJsonParseError::NoError && json.isObject(), QStringLiteral("Catalogo revisioni danneggiato."));
    const auto root = json.object();
    require(root["format"].toString() == QLatin1String("ForgeCAD.RevisionArchive") && root["schema"].toDouble(-1) == 1,
            QStringLiteral("Formato del catalogo revisioni non supportato."));
    require(root["documents"].isArray() && root["revisions"].isArray(), QStringLiteral("Elenchi del catalogo assenti."));
    const auto documents = root["documents"].toArray(), revisions = root["revisions"].toArray();
    require(documents.size() <= kMaxDocuments && revisions.size() <= kMaxRevisions, QStringLiteral("Archivio oltre i limiti del prototipo."));
    Catalog catalog; catalog.archiveId = uuid(root["archiveId"]);
    QSet<QUuid> documentIds, tokens;
    QHash<QUuid, QUuid> heads, knownRevisions;
    QHash<QUuid, quint64> sequences;
    for (const auto &value : documents) {
        require(value.isObject(), QStringLiteral("Documento del catalogo non valido."));
        const auto o = value.toObject(); StoredDocument d;
        d.info.documentId = uuid(o["id"]);
        require(!documentIds.contains(d.info.documentId), QStringLiteral("Documento duplicato nell'archivio."));
        documentIds.insert(d.info.documentId);
        d.info.name = string(o["name"], 4096, true); d.info.kind = string(o["kind"], 128, true);
        d.info.headCheckinId = uuid(o["head"], true);
        require(o["checkout"].isNull() || o["checkout"].isObject(), QStringLiteral("Prenotazione dell'archivio non valida."));
        if (o["checkout"].isObject()) {
            const auto c = o["checkout"].toObject();
            d.checkout = {d.info.documentId, uuid(c["token"]), uuid(c["base"], true), string(c["owner"], 256, true), date(c["createdUtc"])};
            require(!tokens.contains(d.checkout.token) && d.checkout.baseCheckinId == d.info.headCheckinId,
                    QStringLiteral("Prenotazione duplicata o base incoerente."));
            tokens.insert(d.checkout.token); d.info.checkedOut = true; d.info.checkoutOwner = d.checkout.owner;
        }
        catalog.documents.append(std::move(d));
    }
    for (const auto &value : revisions) {
        require(value.isObject(), QStringLiteral("Record di check-in non valido."));
        const auto o = value.toObject(); StoredRevision stored; auto &r = stored.record;
        require(o["version"].isObject(), QStringLiteral("Versione del check-in assente."));
        const auto version = o["version"].toObject(); r.version = {uuid(version["documentId"]), uuid(version["checkinId"])};
        require(documentIds.contains(r.version.documentId) && !knownRevisions.contains(r.version.checkinId),
                QStringLiteral("Documento assente o check-in duplicato nel catalogo."));
        r.previousCheckinId = uuid(o["previous"], true);
        bool ok = false; r.sequence = string(o["sequence"], 20, true).toULongLong(&ok);
        require(ok && r.sequence == sequences.value(r.version.documentId) + 1
                && r.previousCheckinId == heads.value(r.version.documentId), QStringLiteral("Catena dei check-in incoerente."));
        r.technicalRevision = string(o["technicalRevision"], 128, true);
        r.author = string(o["author"], 256, true); r.comment = string(o["comment"], 16384);
        r.createdUtc = date(o["createdUtc"]); r.sha256 = hashValue(o["sha256"]); stored.requestHash = hashValue(o["requestHash"]);
        r.payloadSize = string(o["size"], 20, true).toLongLong(&ok);
        require(ok && r.payloadSize >= 0 && r.payloadSize <= kMaxPayloadBytes, QStringLiteral("Dimensione del contenuto non valida."));
        require(o["dependencies"].isArray() && o["dependencies"].toArray().size() <= kMaxDependencies,
                QStringLiteral("Dipendenze del check-in non valide."));
        QSet<QUuid> dependencies;
        for (const auto &dep : o["dependencies"].toArray()) {
            require(dep.isObject(), QStringLiteral("Dipendenza del check-in non valida."));
            const auto d = dep.toObject(); const DocumentVersion v{uuid(d["documentId"]), uuid(d["checkinId"])};
            require(knownRevisions.contains(v.checkinId) && knownRevisions.value(v.checkinId) == v.documentId
                    && !dependencies.contains(v.checkinId), QStringLiteral("Dipendenza assente, futura o duplicata."));
            dependencies.insert(v.checkinId); r.dependencies.append(v);
        }
        heads[r.version.documentId] = r.version.checkinId; sequences[r.version.documentId] = r.sequence;
        knownRevisions[r.version.checkinId] = r.version.documentId;
        catalog.revisions.append(std::move(stored));
    }
    for (const auto &d : catalog.documents)
        require(d.info.headCheckinId == heads.value(d.info.documentId), QStringLiteral("Testa del documento incoerente con i check-in."));
    return catalog;
}

// Il puntatore di recupero e' pubblicato prima della proiezione catalog.json.
// In caso di interruzione i lettori si fermano: soltanto il recupero esplicito
// puo' applicare l'ultimo stato registrato, mai scegliere uno snapshot vecchio.
QString recoveryDirectory(const QString &directory,bool create=false){
    const auto path=QDir(directory).filePath("catalog-recovery");const QFileInfo info(path);
    require(!info.isSymLink()&&(!info.exists()||info.isDir()),QStringLiteral("Cartella di recupero non valida."));
    if(create)require(QDir().mkpath(path),QStringLiteral("Impossibile creare la cartella di recupero."));
    return path;
}
QByteArray recoveryRead(const QString &path,qint64 limit,bool allowEmpty=false){
    const QFileInfo info(path);require(!info.isSymLink(),QStringLiteral("Il file di recupero non puo' essere un collegamento."));QFile file(path);
    require(file.open(QIODevice::ReadOnly)&&(allowEmpty||file.size()>0)&&file.size()<=limit,QStringLiteral("File assente, illeggibile o oltre i limiti: %1").arg(path));
    const auto bytes=file.read(limit+1);require(bytes.size()==file.size()&&bytes.size()<=limit,QStringLiteral("Lettura incompleta del file di recupero."));return bytes;
}
void recoveryWrite(const QString &path,const QByteArray &bytes){
    require(!QFileInfo(path).isSymLink(),QStringLiteral("La destinazione del recupero non puo' essere un collegamento."));QSaveFile file(path);
    require(file.open(QIODevice::WriteOnly)&&file.write(bytes)==bytes.size()&&file.commit(),QStringLiteral("Impossibile pubblicare %1. Conservare i dati e riprovare il recupero.").arg(path));
}
struct RecoveryHead {QUuid archiveId;QByteArray hash,previous,bytes;QDateTime created;};
RecoveryHead readRecoveryHead(const QString &directory){
    RecoveryHead head;const auto path=QDir(recoveryDirectory(directory)).filePath("head.json");if(!QFileInfo::exists(path)&&!QFileInfo(path).isSymLink()){require(QDir(recoveryDirectory(directory)).entryList(QDir::AllEntries|QDir::NoDotAndDotDot|QDir::Hidden|QDir::System).isEmpty(),QStringLiteral("Puntatore di recupero mancante: conservare i checkpoint, senza scegliere una generazione automaticamente."));return head;}
    head.bytes=recoveryRead(path,4096);QJsonParseError error;auto o=QJsonDocument::fromJson(head.bytes,&error).object();
    require(error.error==QJsonParseError::NoError&&o.size()==7&&o["format"].toString()==QLatin1String("ForgeCAD.CatalogRecovery")&&o["schema"].toDouble(-1)==1,QStringLiteral("Puntatore di recupero danneggiato o non supportato."));
    const auto checksum=hashValue(o.take("checksum"));require(checksum==digest(QJsonDocument(o).toJson(QJsonDocument::Compact)),QStringLiteral("Impronta del puntatore di recupero non valida."));
    head.archiveId=uuid(o["archiveId"]);head.hash=hashValue(o["sha256"]);require(o["previous"].isString(),QStringLiteral("Base del puntatore di recupero assente."));head.previous=o["previous"].toString().isEmpty()?QByteArray():hashValue(o["previous"]);head.created=date(o["createdUtc"]);return head;
}
QString checkpointPath(const QString &directory,const QByteArray &hash){return QDir(recoveryDirectory(directory)).filePath(QString::fromLatin1(hash.toHex())+".json");}
Catalog loadCatalog(const QString &directory,bool transactionLocked=false){
    require(!directory.isEmpty(),QStringLiteral("Cartella dell'archivio non specificata."));
    const auto lockPath=QDir(directory).filePath("catalog.lock");
    // Stesso limite della precedente attesa del lock; la lettura non deve
    // prenotare catalog.lock e far fallire un writer non bloccante.
    constexpr qint64 waitMilliseconds=1000;
    QElapsedTimer elapsed;elapsed.start();
    for(;;){
        const auto before=readRecoveryHead(directory);
        const bool publishing=QFileInfo::exists(lockPath);
        const auto bytes=recoveryRead(QDir(directory).filePath("catalog.json"),kMaxCatalogBytes);
        auto catalog=parseCatalog(bytes);
        const auto after=readRecoveryHead(directory);
        if(after.hash.isEmpty()||(after.archiveId==catalog.archiveId&&after.hash==digest(bytes)))return catalog;
        // Il writer, che possiede gia' il lock, non deve proseguire da uno
        // stato incoerente. Per i lettori una generazione in movimento o
        // ancora in pubblicazione richiede invece una nuova fotografia.
        if(transactionLocked || (before.bytes==after.bytes && !publishing && !QFileInfo::exists(lockPath)))
            throw std::runtime_error("Il catalogo non corrisponde all'ultimo stato pubblicato. Usare Verifica e recupero catalogo.");
        if(elapsed.elapsed()>=waitMilliseconds)throw CatalogBusy();
        QThread::msleep(1);
    }
}

void publishCatalogCheckpoint(const QString &directory,const QByteArray &bytes,const QUuid &archive,const QByteArray &previous){
    recoveryDirectory(directory,true);const auto hash=digest(bytes);const auto path=checkpointPath(directory,hash);
    if(QFileInfo::exists(path))require(recoveryRead(path,kMaxCatalogBytes)==bytes,QStringLiteral("Checkpoint esistente danneggiato: recupero necessario."));else recoveryWrite(path,bytes);
    QJsonObject o{{"format","ForgeCAD.CatalogRecovery"},{"schema",1},{"archiveId",text(archive)},{"sha256",QString::fromLatin1(hash.toHex())},{"previous",QString::fromLatin1(previous.toHex())},{"createdUtc",QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs)}};
    o["checksum"]=QString::fromLatin1(digest(QJsonDocument(o).toJson(QJsonDocument::Compact)).toHex());recoveryWrite(QDir(recoveryDirectory(directory)).filePath("head.json"),QJsonDocument(o).toJson(QJsonDocument::Compact));
}
void pruneCatalogCheckpoints(const QString &directory,const QByteArray &current,const QByteArray &previous){
    const auto files=QDir(recoveryDirectory(directory)).entryInfoList({"*.json"},QDir::Files);
    for(const auto &file:files){const auto name=file.baseName().toLatin1();if(name.size()!=64||name==current.toHex()||name==previous.toHex()||file.isSymLink())continue;
        const auto decoded=QByteArray::fromHex(name);if(decoded.size()==32&&decoded.toHex()==name)QFile::remove(file.absoluteFilePath());}
}
void saveCatalog(const QString &directory, const Catalog &catalog) {
    require(catalog.documents.size() <= kMaxDocuments && catalog.revisions.size() <= kMaxRevisions,
            QStringLiteral("Archivio oltre i limiti del prototipo."));
    const auto bytes = QJsonDocument(catalogJson(catalog)).toJson(QJsonDocument::Compact);
    require(bytes.size() <= kMaxCatalogBytes, QStringLiteral("Catalogo oltre il limite del prototipo."));
    const auto path=QDir(directory).filePath("catalog.json");const auto previous=QFileInfo::exists(path)?digest(recoveryRead(path,kMaxCatalogBytes)):QByteArray();
    publishCatalogCheckpoint(directory,bytes,catalog.archiveId,previous);
    recoveryWrite(path,bytes);
    pruneCatalogCheckpoints(directory,digest(bytes),previous);
}

QString transaction(const QString &directory, const std::function<bool(Catalog &)> &operation) {
    try {
        require(!directory.isEmpty(), QStringLiteral("Cartella dell'archivio non specificata."));
        QLockFile lock(QDir(directory).filePath("catalog.lock")); lock.setStaleLockTime(0);
        require(lock.tryLock(0), QStringLiteral("Archivio occupato o non scrivibile; riprovare."));
        auto catalog = loadCatalog(directory,true);
        if (operation(catalog)) saveCatalog(directory, catalog);
        return {};
    } catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}
StoredDocument &findDocument(Catalog &catalog, const QUuid &id) {
    const auto it = std::find_if(catalog.documents.begin(), catalog.documents.end(), [&](const auto &d) { return d.info.documentId == id; });
    require(it != catalog.documents.end(), QStringLiteral("Documento non presente nell'archivio."));
    return *it;
}
bool owns(const StoredDocument &document, const RevisionCheckout &checkout) {
    return !checkout.token.isNull() && document.info.documentId == checkout.documentId
        && document.checkout.token == checkout.token && document.checkout.owner == checkout.owner
        && document.checkout.baseCheckinId == checkout.baseCheckinId && document.info.headCheckinId == checkout.baseCheckinId;
}
QString revisionKey(QString label) {
    label=label.normalized(QString::NormalizationForm_KC).trimmed().toCaseFolded();
    if(!label.isEmpty()&&std::all_of(label.cbegin(),label.cend(),[](QChar c){return c>='0'&&c<='9';})){
        qsizetype start=0;while(start+1<label.size()&&label[start]=='0')++start;label=label.mid(start);
    }
    return label;
}
QString nextRevisionLabel(const Catalog &catalog,const QUuid &document) {
    quint64 sequence=1;QSet<QString> used;
    for(const auto &r:catalog.revisions)if(r.record.version.documentId==document){sequence=std::max(sequence,r.record.sequence+1);used.insert(revisionKey(r.record.technicalRevision));}
    while(used.contains(QString::number(sequence)))++sequence;
    return QString::number(sequence);
}
void availableRevision(const Catalog &catalog,const QUuid &document,const QString &label) {
    string(QJsonValue(label),128,true);const auto key=revisionKey(label);
    for(const auto &r:catalog.revisions)if(r.record.version.documentId==document)
        require(revisionKey(r.record.technicalRevision)!=key,QStringLiteral("La revisione %1 esiste gia' per questo documento. Aggiornare il numero proposto.").arg(label));
}
QString objectPath(const QString &directory, const QByteArray &sha256) {
    return QDir(directory).filePath("objects/" + QString::fromLatin1(sha256.toHex()) + ".bin");
}
QByteArray readObject(const QString &directory, const RevisionRecord &record) {
    QFile file(objectPath(directory, record.sha256));
    require(file.open(QIODevice::ReadOnly) && file.size() == record.payloadSize, QStringLiteral("Contenuto del check-in assente o troncato."));
    const auto bytes = file.readAll();
    require(bytes.size() == record.payloadSize && digest(bytes) == record.sha256, QStringLiteral("Contenuto del check-in danneggiato."));
    return bytes;
}
QByteArray fingerprint(const RevisionCheckinRequest &r, const QByteArray &sha256) {
    return digest(QJsonDocument(QJsonObject{{"documentId", text(r.checkout.documentId)}, {"token", text(r.checkout.token)},
        {"base", text(r.checkout.baseCheckinId)}, {"owner", r.checkout.owner}, {"checkinId", text(r.checkinId)},
        {"sha256", QString::fromLatin1(sha256.toHex())}, {"technicalRevision", r.technicalRevision}, {"comment", r.comment},
        {"dependencies", dependenciesJson(r.dependencies)}}).toJson(QJsonDocument::Compact));
}
}

RevisionStore::RevisionStore(QString directory)
    : directory_(directory.trimmed().isEmpty() ? QString() : QDir(directory).absolutePath()) {}

QString RevisionStore::initialize() const {
    try {
        require(!directory_.isEmpty(), QStringLiteral("Cartella dell'archivio non specificata."));
        require(QDir().mkpath(directory_), QStringLiteral("Impossibile creare la cartella dell'archivio."));
        QLockFile lock(QDir(directory_).filePath("catalog.lock")); lock.setStaleLockTime(0);
        require(lock.tryLock(0), QStringLiteral("Archivio occupato o non scrivibile; riprovare."));
        if (QFileInfo::exists(QDir(directory_).filePath("catalog.json"))) {
            loadCatalog(directory_,true);
            require(QDir(QDir(directory_).filePath("objects")).exists(), QStringLiteral("Cartella dei contenuti dell'archivio mancante."));
            return {};
        }
        const auto entries = QDir(directory_).entryList(QDir::AllEntries | QDir::NoDotAndDotDot | QDir::Hidden | QDir::System);
        for (const auto &entry : entries)
            require(entry == QLatin1String("catalog.lock") || entry == QLatin1String("objects"),
                    QStringLiteral("Cartella non vuota priva di catalogo: inizializzazione annullata."));
        const QDir objects(QDir(directory_).filePath("objects"));
        require(!objects.exists() || objects.entryList(QDir::AllEntries | QDir::NoDotAndDotDot | QDir::Hidden | QDir::System).isEmpty(),
                QStringLiteral("Contenuti presenti ma catalogo mancante: ripristinare il catalogo, senza inizializzare di nuovo."));
        require(QDir(directory_).mkpath("objects"), QStringLiteral("Impossibile creare la cartella dei contenuti."));
        Catalog catalog; catalog.archiveId = QUuid::createUuid(); saveCatalog(directory_, catalog);
        return {};
    } catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

QString RevisionStore::createDocument(const QString &name, const QString &kind, QUuid &documentId) const {
    QUuid prepared;
    const auto error = transaction(directory_, [&](Catalog &catalog) {
        string(QJsonValue(name), 4096, true); string(QJsonValue(kind), 128, true);
        StoredDocument d; d.info.documentId = QUuid::createUuid(); d.info.name = name; d.info.kind = kind;
        prepared = d.info.documentId; catalog.documents.append(std::move(d)); return true;
    });
    if (error.isEmpty()) documentId = prepared;
    return error;
}

QString RevisionStore::registerDocument(const QUuid &documentId, const QString &name, const QString &kind) const {
    return transaction(directory_, [&](Catalog &catalog) {
        require(!documentId.isNull(), QStringLiteral("Identita' del documento assente."));
        string(QJsonValue(name), 4096, true); string(QJsonValue(kind), 128, true);
        for (const auto &d : catalog.documents) if (d.info.documentId == documentId) {
            require(d.info.kind == kind, QStringLiteral("Il documento e' gia' registrato con un altro tipo."));
            return false;
        }
        StoredDocument d; d.info.documentId = documentId; d.info.name = name; d.info.kind = kind;
        catalog.documents.append(std::move(d)); return true;
    });
}

QString RevisionStore::archiveIdentity(QUuid &archiveId,bool *temporarilyBusy) const {
    if(temporarilyBusy)*temporarilyBusy=false;
    try { const auto catalog = loadCatalog(directory_); archiveId = catalog.archiveId; return {}; }
    catch (const CatalogBusy &error) { if(temporarilyBusy)*temporarilyBusy=true;return QString::fromUtf8(error.what()); }
    catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

QString RevisionStore::documents(QVector<RevisionDocumentInfo> &result,bool *temporarilyBusy) const {
    if(temporarilyBusy)*temporarilyBusy=false;
    try {
        const auto catalog = loadCatalog(directory_); QVector<RevisionDocumentInfo> prepared;
        for (const auto &d : catalog.documents) prepared.append(d.info);
        result = std::move(prepared); return {};
    } catch (const CatalogBusy &error) { if(temporarilyBusy)*temporarilyBusy=true;return QString::fromUtf8(error.what()); }
    catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

QString RevisionStore::history(const QUuid &documentId, QVector<RevisionRecord> &result) const {
    try {
        auto catalog = loadCatalog(directory_); findDocument(catalog, documentId); QVector<RevisionRecord> prepared;
        for (const auto &r : catalog.revisions) if (r.record.version.documentId == documentId) prepared.append(r.record);
        result = std::move(prepared); return {};
    } catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

namespace {
QString reserveDocument(const QString &directory, const QUuid &documentId, const QString &owner,
                        const QUuid *expectedBase, RevisionCheckout &result) {
    RevisionCheckout prepared;
    const auto error = transaction(directory, [&](Catalog &catalog) {
        string(QJsonValue(owner), 256, true);
        auto &d = findDocument(catalog, documentId);
        require(!expectedBase || d.info.headCheckinId == *expectedBase, QStringLiteral("Il documento e' cambiato prima del check-out."));
        require(d.checkout.token.isNull(), QStringLiteral("Documento gia' in check-out da %1.").arg(d.checkout.owner));
        prepared = {documentId, QUuid::createUuid(), d.info.headCheckinId, owner, QDateTime::currentDateTimeUtc()};
        d.checkout = prepared; return true;
    });
    if (error.isEmpty()) result = prepared;
    return error;
}
}

QString RevisionStore::checkout(const QUuid &documentId, const QString &owner, RevisionCheckout &result) const {
    return reserveDocument(directory_, documentId, owner, nullptr, result);
}

QString RevisionStore::checkoutAtVersion(const DocumentVersion &base, const QString &owner, RevisionCheckout &result) const {
    return reserveDocument(directory_, base.documentId, owner, &base.checkinId, result);
}

QString RevisionStore::checkoutWithToken(const RevisionCheckout &request, RevisionCheckout &result) const {
    RevisionCheckout prepared;
    const auto error = transaction(directory_, [&](Catalog &catalog) {
        require(!request.documentId.isNull() && !request.token.isNull() && request.createdUtc.isValid()
                && request.createdUtc.offsetFromUtc() == 0, QStringLiteral("Richiesta di check-out incompleta."));
        string(QJsonValue(request.owner), 256, true);
        auto &d = findDocument(catalog, request.documentId);
        require(d.info.headCheckinId == request.baseCheckinId, QStringLiteral("La base del check-out non e' piu' corrente."));
        if (owns(d, request)) {
            require(d.checkout.createdUtc == request.createdUtc, QStringLiteral("Token di check-out riutilizzato con metadati diversi."));
            prepared = d.checkout; return false;
        }
        require(d.checkout.token.isNull(), QStringLiteral("Documento gia' in check-out da %1.").arg(d.checkout.owner));
        for (const auto &document : catalog.documents)
            require(document.checkout.token != request.token, QStringLiteral("Token di check-out gia' utilizzato."));
        d.checkout = request; prepared = request; return true;
    });
    if (error.isEmpty()) result = prepared;
    return error;
}

QString RevisionStore::resumeCheckout(const QUuid &documentId, const QUuid &token, RevisionCheckout &result,bool *temporarilyBusy) const {
    if(temporarilyBusy)*temporarilyBusy=false;
    try {
        auto catalog = loadCatalog(directory_); const auto &d = findDocument(catalog, documentId);
        require(!token.isNull() && d.checkout.token == token, QStringLiteral("Prenotazione non piu' valida."));
        result = d.checkout; return {};
    } catch (const CatalogBusy &error) { if(temporarilyBusy)*temporarilyBusy=true;return QString::fromUtf8(error.what()); }
    catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

QString RevisionStore::cancelCheckout(const RevisionCheckout &checkout) const {
    return transaction(directory_, [&](Catalog &catalog) {
        auto &d = findDocument(catalog, checkout.documentId);
        require(owns(d, checkout), QStringLiteral("Prenotazione persa o copia di lavoro obsoleta."));
        d.checkout = {}; return true;
    });
}

QString RevisionStore::checkin(const RevisionCheckinRequest &request, RevisionRecord &result) const {
    RevisionRecord prepared;
    const auto error = transaction(directory_, [&](Catalog &catalog) {
        require(!request.checkinId.isNull() && !request.checkout.documentId.isNull() && !request.checkout.token.isNull(),
                QStringLiteral("Identita' del check-in o della prenotazione assente."));
        require(request.payload.size() <= kMaxPayloadBytes && request.dependencies.size() <= kMaxDependencies,
                QStringLiteral("Contenuti o dipendenze oltre il limite del prototipo."));
        string(QJsonValue(request.technicalRevision), 128); string(QJsonValue(request.comment), 16384);
        const auto sha256 = digest(request.payload), requestHash = fingerprint(request, sha256);
        for (const auto &stored : catalog.revisions) if (stored.record.version.checkinId == request.checkinId) {
            require(stored.requestHash == requestHash, QStringLiteral("Identita' del check-in gia' usata per un'altra operazione."));
            readObject(directory_, stored.record); prepared = stored.record; return false;
        }
        auto &d = findDocument(catalog, request.checkout.documentId);
        require(owns(d, request.checkout), QStringLiteral("Prenotazione persa o copia di lavoro obsoleta."));
        auto label=request.technicalRevision.trimmed().isEmpty()?nextRevisionLabel(catalog,d.info.documentId):request.technicalRevision.trimmed();
        // Un vecchio pendente puo' contenere un'etichetta oggi gia' assegnata.
        // Si cambia solo la ricevuta tecnica, mantenendo UUID, payload e hash
        // della richiesta originale: ogni ritentativo ottiene la stessa ricevuta.
        for(const auto &r:catalog.revisions)if(r.record.version.documentId==d.info.documentId&&revisionKey(r.record.technicalRevision)==revisionKey(label)){label=nextRevisionLabel(catalog,d.info.documentId);break;}
        availableRevision(catalog,d.info.documentId,label);
        QSet<QUuid> dependencies;
        for (const auto &dep : request.dependencies) {
            require(!dep.documentId.isNull() && !dep.checkinId.isNull() && !dependencies.contains(dep.checkinId),
                    QStringLiteral("Dipendenza senza versione precisa o duplicata."));
            const auto found = std::find_if(catalog.revisions.begin(), catalog.revisions.end(), [&](const auto &r) {
                return r.record.version.documentId == dep.documentId && r.record.version.checkinId == dep.checkinId;
            });
            require(found != catalog.revisions.end(), QStringLiteral("Dipendenza non presente nell'archivio."));
            readObject(directory_, found->record); dependencies.insert(dep.checkinId);
        }
        prepared.version = {d.info.documentId, request.checkinId}; prepared.previousCheckinId = d.info.headCheckinId;
        prepared.sequence = 1;
        for (const auto &r : catalog.revisions) if (r.record.version.documentId == d.info.documentId) ++prepared.sequence;
        prepared.technicalRevision = label; prepared.author = d.checkout.owner; prepared.comment = request.comment;
        prepared.createdUtc = QDateTime::currentDateTimeUtc(); prepared.sha256 = sha256; prepared.payloadSize = request.payload.size();
        prepared.dependencies = request.dependencies;
        const auto path = objectPath(directory_, sha256);
        if (QFileInfo::exists(path)) readObject(directory_, prepared);
        else {
            QSaveFile object(path);
            require(object.open(QIODevice::WriteOnly) && object.write(request.payload) == request.payload.size() && object.commit(),
                    QStringLiteral("Scrittura del contenuto del check-in fallita."));
        }
        catalog.revisions.append({prepared, requestHash}); d.info.headCheckinId = request.checkinId; d.checkout = {};
        return true;
    });
    if (error.isEmpty()) result = prepared;
    return error;
}

QString RevisionStore::nextTechnicalRevision(const QUuid &documentId,QString &label) const {
    try {auto catalog=loadCatalog(directory_);findDocument(catalog,documentId);label=nextRevisionLabel(catalog,documentId);return {};}
    catch(const std::exception &e){return QString::fromUtf8(e.what());}
}
QString RevisionStore::validateTechnicalRevision(const QUuid &documentId,const QString &label) const {
    try {auto catalog=loadCatalog(directory_);findDocument(catalog,documentId);availableRevision(catalog,documentId,label.trimmed());return {};}
    catch(const std::exception &e){return QString::fromUtf8(e.what());}
}
QString RevisionStore::read(const DocumentVersion &version, QByteArray &payload) const {
    try {
        const auto catalog = loadCatalog(directory_);
        const auto found = std::find_if(catalog.revisions.begin(), catalog.revisions.end(), [&](const auto &r) {
            return r.record.version.documentId == version.documentId && r.record.version.checkinId == version.checkinId;
        });
        require(found != catalog.revisions.end(), QStringLiteral("Check-in non presente nell'archivio."));
        const auto prepared = readObject(directory_, found->record); payload = prepared; return {};
    } catch (const std::exception &error) { return QString::fromUtf8(error.what()); }
}

namespace {
constexpr qint64 maxReleaseBytes=512*1024,maxReleaseListBytes=32*1024*1024;
constexpr qsizetype maxReleases=1000,maxReleaseDrawings=100;
bool sameReleaseVersion(const DocumentVersion &a,const DocumentVersion &b){return a.documentId==b.documentId&&a.checkinId==b.checkinId;}
QJsonObject releaseMemberJson(const RevisionReleaseMember &m){return {{"version",versionJson(m.version)},{"name",m.name},{"kind",m.kind},{"technicalRevision",m.technicalRevision},{"sequence",QString::number(m.sequence)},{"sha256",QString::fromLatin1(m.sha256.toHex())},{"size",QString::number(m.payloadSize)}};}
QJsonObject releaseJson(const RevisionReleaseManifest &m){
    QJsonArray drawings;for(const auto &d:m.drawings)drawings.append(releaseMemberJson(d));
    return {{"format","ForgeCAD.CoordinatedRelease"},{"schema",1},{"releaseId",text(m.releaseId)},{"archiveId",text(m.archiveId)},{"name",m.name},{"author",m.author},{"comment",m.comment},{"createdUtc",m.createdUtc.toUTC().toString(Qt::ISODateWithMs)},{"model",releaseMemberJson(m.model)},{"drawings",drawings}};
}
QByteArray compactRelease(const QJsonObject &object){return QJsonDocument(object).toJson(QJsonDocument::Compact);}
QByteArray encodeRelease(const RevisionReleaseManifest &m){const auto object=releaseJson(m);return compactRelease({{"manifest",object},{"sha256",QString::fromLatin1(digest(compactRelease(object)).toHex())}});}
QByteArray releaseFingerprint(RevisionReleaseRequest r){
    return digest(compactRelease({{"releaseId",text(r.releaseId)},{"name",r.name.trimmed()},{"author",r.author.trimmed()},{"comment",r.comment},{"model",versionJson(r.model)},{"drawings",dependenciesJson(r.drawings)}}));
}
RevisionReleaseMember readReleaseMember(const QJsonValue &value){
    require(value.isObject(),QStringLiteral("Membro del rilascio assente."));const auto o=value.toObject();require(o.size()==7&&o["version"].isObject()&&o["version"].toObject().size()==2,QStringLiteral("Membro del rilascio incompleto."));const auto v=o["version"].toObject();RevisionReleaseMember m;
    m.version={uuid(v["documentId"]),uuid(v["checkinId"])};m.name=string(o["name"],4096,true);m.kind=string(o["kind"],128,true);m.technicalRevision=string(o["technicalRevision"],128,true);m.sha256=hashValue(o["sha256"]);
    bool valid=false;m.sequence=string(o["sequence"],20,true).toULongLong(&valid);require(valid&&m.sequence>0,QStringLiteral("Sequenza del rilascio non valida."));m.payloadSize=string(o["size"],20,true).toLongLong(&valid);require(valid&&m.payloadSize>=0&&m.payloadSize<=kMaxPayloadBytes,QStringLiteral("Dimensione del membro non valida."));return m;
}
QString releaseDirectory(const QString &directory){
    const auto path=QDir(directory).filePath("releases");const QFileInfo info(path);
    require(!info.isSymLink()&&(!info.exists()||info.isDir()),QStringLiteral("Cartella dei rilasci non valida."));return path;
}
RevisionReleaseManifest readReleaseFile(const QString &path){
    const QFileInfo info(path);require(!info.isSymLink(),QStringLiteral("Il manifesto non puo' essere un collegamento."));QFile file(path);require(file.open(QIODevice::ReadOnly)&&file.size()>0&&file.size()<=maxReleaseBytes,QStringLiteral("Manifesto assente, illeggibile o oltre i limiti."));
    const auto bytes=file.read(maxReleaseBytes+1);require(bytes.size()<=maxReleaseBytes,QStringLiteral("Manifesto oltre i limiti."));QJsonParseError error;const auto json=QJsonDocument::fromJson(bytes,&error);const auto root=json.object();
    require(error.error==QJsonParseError::NoError&&json.isObject()&&root.size()==2&&root["manifest"].isObject(),QStringLiteral("Contenitore del manifesto non valido."));const auto o=root["manifest"].toObject();
    require(hashValue(root["sha256"])==digest(compactRelease(o)),QStringLiteral("Manifesto del rilascio danneggiato."));require(o.size()==10&&o["format"].toString()==QLatin1String("ForgeCAD.CoordinatedRelease")&&o["schema"].toDouble(-1)==1,QStringLiteral("Formato del rilascio non supportato."));
    RevisionReleaseManifest m;m.releaseId=uuid(o["releaseId"]);m.archiveId=uuid(o["archiveId"]);m.name=string(o["name"],128,true);m.author=string(o["author"],256,true);m.comment=string(o["comment"],16384);m.createdUtc=date(o["createdUtc"]);m.model=readReleaseMember(o["model"]);
    require(info.fileName()==text(m.releaseId)+".json"&&m.model.kind==QLatin1String("model")&&o["drawings"].isArray(),QStringLiteral("Identita' o modello del manifesto non validi."));const auto drawings=o["drawings"].toArray();require(!drawings.isEmpty()&&drawings.size()<=maxReleaseDrawings,QStringLiteral("Il rilascio richiede da 1 a 100 tavole."));QSet<QUuid> ids{m.model.version.documentId};
    for(const auto &value:drawings){auto d=readReleaseMember(value);require(d.kind==QLatin1String("drawing")&&!ids.contains(d.version.documentId),QStringLiteral("Tavola duplicata o tipo errato nel rilascio."));ids.insert(d.version.documentId);m.drawings.append(std::move(d));}return m;
}
QVector<RevisionReleaseManifest> releaseList(const QString &directory,const QUuid &archive){
    const auto path=releaseDirectory(directory);QDir dir(path);QVector<RevisionReleaseManifest> list;if(!dir.exists())return list;
    const auto files=dir.entryInfoList({"*.json"},QDir::Files|QDir::Hidden|QDir::System,QDir::Name);require(files.size()<=maxReleases,QStringLiteral("Troppi rilasci nell'archivio."));qint64 total=0;
    for(const auto &file:files){total+=file.size();require(total<=maxReleaseListBytes,QStringLiteral("Elenco rilasci oltre 32 MiB."));auto m=readReleaseFile(file.absoluteFilePath());require(m.archiveId==archive,QStringLiteral("Manifesto di un altro archivio."));list.append(std::move(m));}
    std::sort(list.begin(),list.end(),[](const auto &a,const auto &b){return a.createdUtc!=b.createdUtc?a.createdUtc<b.createdUtc:a.releaseId<b.releaseId;});return list;
}
RevisionReleaseManifest prepareReleaseManifest(const QString &directory,const Catalog &catalog,const RevisionReleaseRequest &r,const QDateTime &created){
    require(!r.releaseId.isNull()&&!r.model.documentId.isNull()&&!r.model.checkinId.isNull(),QStringLiteral("Identita' del rilascio o versione precisa del modello assenti."));
    RevisionReleaseManifest m;m.releaseId=r.releaseId;m.archiveId=catalog.archiveId;m.name=string(r.name.trimmed(),128,true);m.author=string(r.author.trimmed(),256,true);m.comment=string(r.comment,16384);m.createdUtc=created;
    require(!r.drawings.isEmpty()&&r.drawings.size()<=maxReleaseDrawings,QStringLiteral("Selezionare da 1 a 100 tavole archiviate."));
    QHash<QUuid,const StoredDocument *> documents;for(const auto &d:catalog.documents)documents.insert(d.info.documentId,&d);
    QHash<QUuid,const RevisionRecord *> records;for(const auto &stored:catalog.revisions)records.insert(stored.record.version.checkinId,&stored.record);
    const auto member=[&](const DocumentVersion &version,const QString &kind){
        const auto *record=records.value(version.checkinId,nullptr);const auto *document=documents.value(version.documentId,nullptr);
        require(record&&document&&sameReleaseVersion(record->version,version)&&document->info.kind==kind,QStringLiteral("Versione o tipo di documento non presente nell'archivio."));
        require(kind==QLatin1String("model")?record->dependencies.isEmpty():record->dependencies.size()==1&&sameReleaseVersion(record->dependencies[0],r.model),QStringLiteral("La tavola non usa il modello preciso scelto per il rilascio."));
        readObject(directory,*record);return RevisionReleaseMember{version,document->info.name,kind,record->technicalRevision,record->sequence,record->sha256,record->payloadSize};
    };
    m.model=member(r.model,QStringLiteral("model"));QSet<QUuid> ids{r.model.documentId};
    for(const auto &version:r.drawings){require(!ids.contains(version.documentId),QStringLiteral("Selezionare una sola revisione per tavola."));ids.insert(version.documentId);m.drawings.append(member(version,QStringLiteral("drawing")));}
    require(encodeRelease(m).size()<=maxReleaseBytes,QStringLiteral("Manifesto oltre 512 KiB."));return m;
}
RevisionReleaseManifest verifiedRelease(const QString &directory,const Catalog &catalog,const QUuid &id){
    require(!id.isNull(),QStringLiteral("Identita' del rilascio assente."));auto m=readReleaseFile(QDir(releaseDirectory(directory)).filePath(text(id)+".json"));require(m.archiveId==catalog.archiveId,QStringLiteral("Il rilascio appartiene a un altro archivio."));
    const auto expected=prepareReleaseManifest(directory,catalog,revisionReleaseRequest(m),m.createdUtc);require(compactRelease(releaseJson(m))==compactRelease(releaseJson(expected)),QStringLiteral("Manifesto incoerente con i record archiviati."));return m;
}
}
RevisionReleaseRequest revisionReleaseRequest(const RevisionReleaseManifest &m){RevisionReleaseRequest r{m.releaseId,m.name,m.author,m.comment,m.model.version,{}};for(const auto &d:m.drawings)r.drawings.append(d.version);return r;}
QString RevisionStore::inspectRelease(const RevisionReleaseRequest &request,RevisionReleaseManifest &manifest)const{
    try{const auto catalog=loadCatalog(directory_);auto prepared=prepareReleaseManifest(directory_,catalog,request,QDateTime::currentDateTimeUtc());manifest=std::move(prepared);return {};}catch(const std::exception &error){return QString::fromUtf8(error.what());}
}
QString RevisionStore::publishRelease(const RevisionReleaseRequest &request,RevisionReleaseManifest &manifest)const{
    RevisionReleaseManifest prepared;const auto error=transaction(directory_,[&](Catalog &catalog){
        auto candidate=prepareReleaseManifest(directory_,catalog,request,QDateTime::currentDateTimeUtc());const auto path=QDir(releaseDirectory(directory_)).filePath(text(request.releaseId)+".json");
        if(QFileInfo::exists(path)){auto existing=verifiedRelease(directory_,catalog,request.releaseId);require(releaseFingerprint(request)==releaseFingerprint(revisionReleaseRequest(existing)),QStringLiteral("Identita' del rilascio gia' usata per un'altra operazione."));prepared=std::move(existing);return false;}
        const auto previous=releaseList(directory_,catalog.archiveId);require(previous.size()<maxReleases,QStringLiteral("Limite di 1000 rilasci raggiunto."));qint64 total=0;
        for(const auto &m:previous){require(m.model.version.documentId!=request.model.documentId||revisionKey(m.name)!=revisionKey(candidate.name),QStringLiteral("Nome del rilascio gia' usato per questo modello."));total+=QFileInfo(QDir(releaseDirectory(directory_)).filePath(text(m.releaseId)+".json")).size();}
        const auto bytes=encodeRelease(candidate);require(total+bytes.size()<=maxReleaseListBytes,QStringLiteral("Elenco rilasci oltre 32 MiB."));require(QDir().mkpath(releaseDirectory(directory_)),QStringLiteral("Impossibile creare la cartella rilasci."));QSaveFile file(path);
        require(file.open(QIODevice::WriteOnly)&&file.write(bytes)==bytes.size()&&file.commit(),QStringLiteral("Pubblicazione del rilascio fallita: ritentare con la stessa identita'."));prepared=std::move(candidate);return false;
    });if(error.isEmpty())manifest=std::move(prepared);return error;
}
QString RevisionStore::readRelease(const QUuid &id,RevisionReleaseManifest &manifest)const{
    try{const auto catalog=loadCatalog(directory_);auto prepared=verifiedRelease(directory_,catalog,id);manifest=std::move(prepared);return {};}catch(const std::exception &error){return QString::fromUtf8(error.what());}
}
QString RevisionStore::releases(QVector<RevisionReleaseManifest> &manifests)const{
    try{const auto catalog=loadCatalog(directory_);auto prepared=releaseList(directory_,catalog.archiveId);manifests=std::move(prepared);return {};}catch(const std::exception &error){return QString::fromUtf8(error.what());}
}
namespace {
void verifyRecoveryContents(const QString &directory,const Catalog &catalog,RevisionCatalogRecovery &info){
    QHash<QByteArray,qint64> verified;for(const auto &stored:catalog.revisions){const auto &record=stored.record;if(verified.contains(record.sha256))require(verified.value(record.sha256)==record.payloadSize,QStringLiteral("Dimensioni incoerenti per lo stesso contenuto."));else{readObject(directory,record);verified.insert(record.sha256,record.payloadSize);}}
    const auto releases=releaseList(directory,catalog.archiveId);for(const auto &release:releases)verifiedRelease(directory,catalog,release.releaseId);info.releases=releases.size();
}
RevisionCatalogRecovery inspectRecovery(const QString &directory){
    const auto head=readRecoveryHead(directory);RevisionCatalogRecovery info;Catalog catalog;QByteArray current;const auto path=QDir(directory).filePath("catalog.json");
    const bool exists=QFileInfo::exists(path)||QFileInfo(path).isSymLink();if(exists)current=recoveryRead(path,kMaxCatalogBytes,true);
    if(head.hash.isEmpty()){require(exists,QStringLiteral("Nessun checkpoint disponibile: gli oggetti da soli non ricostruiscono il catalogo."));catalog=parseCatalog(current);info.catalogMatches=true;}
    else{
        const auto bytes=recoveryRead(checkpointPath(directory,head.hash),kMaxCatalogBytes);require(digest(bytes)==head.hash,QStringLiteral("Checkpoint del catalogo danneggiato."));catalog=parseCatalog(bytes);
        require(catalog.archiveId==head.archiveId,QStringLiteral("Checkpoint di un altro archivio."));info.protectedCatalog=true;info.checkpointHash=head.hash;info.createdUtc=head.created;info.catalogMatches=exists&&digest(current)==head.hash;
        if(exists&&!info.catalogMatches){bool valid=false;try{parseCatalog(current);valid=true;}catch(const std::exception &){}if(valid&&digest(current)!=head.previous)info.conflict=QStringLiteral("Il catalogo attuale e' valido ma divergente: recupero bloccato per non perdere modifiche di un altro writer.");}
        info.canRecover=!info.catalogMatches&&info.conflict.isEmpty();
    }
    info.archiveId=catalog.archiveId;info.documents=catalog.documents.size();info.revisions=catalog.revisions.size();for(const auto &d:catalog.documents)if(!d.checkout.token.isNull())++info.checkouts;
    verifyRecoveryContents(directory,catalog,info);info.stateHash=digest(head.bytes+(exists?QByteArray("present"):QByteArray("missing"))+current);return info;
}
}
QString RevisionStore::inspectCatalogRecovery(RevisionCatalogRecovery &result)const{
    try{auto prepared=inspectRecovery(directory_);result=std::move(prepared);return {};}catch(const std::exception &e){return QString::fromUtf8(e.what());}
}
QString RevisionStore::protectCatalog(RevisionCatalogRecovery &result)const{
    try{QLockFile lock(QDir(directory_).filePath("catalog.lock"));lock.setStaleLockTime(0);require(lock.tryLock(0),QStringLiteral("Archivio occupato o non scrivibile; riprovare."));
        auto prepared=inspectRecovery(directory_);require(prepared.catalogMatches,QStringLiteral("Recuperare prima la proiezione del catalogo."));if(!prepared.protectedCatalog){const auto catalog=loadCatalog(directory_,true);saveCatalog(directory_,catalog);prepared=inspectRecovery(directory_);}result=std::move(prepared);return {};
    }catch(const std::exception &e){return QString::fromUtf8(e.what());}
}
QString RevisionStore::recoverCatalog(const RevisionCatalogRecovery &expected,RevisionCatalogRecovery &result)const{
    try{QLockFile lock(QDir(directory_).filePath("catalog.lock"));lock.setStaleLockTime(0);require(lock.tryLock(0),QStringLiteral("Archivio occupato o non scrivibile; riprovare."));auto prepared=inspectRecovery(directory_);
        require(prepared.protectedCatalog&&expected.archiveId==prepared.archiveId&&expected.checkpointHash==prepared.checkpointHash,QStringLiteral("Il checkpoint e' cambiato: ripetere la verifica."));
        if(prepared.catalogMatches){result=std::move(prepared);return {};}
        require(prepared.canRecover&&prepared.stateHash==expected.stateHash,QStringLiteral("Il catalogo e' cambiato o e' divergente: ripetere la verifica."));
        const auto path=QDir(directory_).filePath("catalog.json");QString evidence;
        if(QFileInfo::exists(path)){const auto bytes=recoveryRead(path,kMaxCatalogBytes,true);evidence=QDir(recoveryDirectory(directory_)).filePath("damaged-"+text(QUuid::createUuid())+".bin");recoveryWrite(evidence,bytes);}
        recoveryWrite(path,recoveryRead(checkpointPath(directory_,prepared.checkpointHash),kMaxCatalogBytes));prepared=inspectRecovery(directory_);prepared.evidencePath=evidence;result=std::move(prepared);return {};
    }catch(const std::exception &e){return QString::fromUtf8(e.what());}
}

}
