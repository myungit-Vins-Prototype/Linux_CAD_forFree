# Evidenze CI del 2 novembre 2026

La prima diagnosi riguarda cc26a27/run41503734941: build Linux e macOS riuscite, test draft e catalogo falliti. github-linux e github-macos contengono gli artifact ufficiali di quel run; run-414* conserva log precedenti.

production/manifest.json identifica i quattro sorgenti/test corretti in f75015b. Numeri locali di quel checkpoint:162PASS/1SKIP/0FAIL su163, kernel459/459, revisioni32/32, confronto deterministico FAIL/PASS, Clang e sanitizer mirati. Gli eseguibili e gli oggetti non sono inclusi. I prototipi preliminari falliti sono distinti nei log draft-fixed e draft-analytic; solo i sorgenti production/ sono il fix integrato.

Il run41509525775 di f75015b ha compilato Linux, poi è stato annullato dal push del nuovo lavoro richiesto sul loft. Il suo job macOS era già annullato senza runner per capacità ARM64 insufficiente: job/check/annotations JSON ne conservano la causa. Non si considera quel run una verifica completa riuscita.

La verifica remota conclusiva è run41513461524 su ec08b12, discendente diretto di f75015b, comprensivo del fix loft. run-fixed-complete.json e github-fixed-linux/macos contengono esiti e artifact ufficiali. L'archivio viene creato solo dopo il PASS di entrambi i job. I log del checkpoint locale finale163PASS/1SKIP/0FAIL su164 e la QA del loft sono nell'archivio separato loft-guide-proiettate-2026-11-02-verifica.zip del repository.

Gli hash di ogni file incluso sono in evidence-manifest.json. Nessun CAD originale, binario o oggetto compilato viene incluso. Le immagini riguardano la mappa architetturale della correzione iniziale; la mappa finale549file/7598relazioni/259AST e le immagini del loft sono nel secondo archivio.
