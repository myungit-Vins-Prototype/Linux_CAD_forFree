Evidenze delle correzioni del 2 novembre 2026, base ab6fc71, main.
Build 4 finale completa di applicazione e runner: PASS.
CTest full 153 prima dell'ultima correzione storyboard; final 152 dopo, escluso solo
forgekernel_tests il cui binario non cambia (SHA256 verificato). Il JUnit consolidato
usa l'ultimo esito per nome: 151 PASS, 1 SKIP, 1 FAIL preesistente DraftCurvedAndConcaveSolids.
Tempi wall-clock delle invocazioni: 406,30 s e 67,81 s; il tempo del JUnit consolidato
sommato per testcase non rappresenta un'ulteriore invocazione unica.
Le fixture sono copie congelate; manifest CTest copiati cambiano solo EXAMPLE_DIR.
Originali e copie invariati al controllo finale. Nessun file CAD o binario incluso.
GUI finale: 6 prove reali Wayland/XCB sulla build4; dodici catture, senza errori GL.
ASan/UBSan: 5/5 test di robustezza, fk_step.cpp/fk_body_io.cpp/test instrumentati,
altri oggetti Release, detect_leaks=0. Risultato registrato nella sessione; non e'
una certificazione dell'intera app instrumentata. Le regressioni permanenti sono
nei sorgenti, inclusa guardia test delle allocazioni per non richiedere GB reali.
Mappa: 531 file, 7305 relazioni, 249 TU, zero diagnostica; check PASS e HTML ispezionato.
