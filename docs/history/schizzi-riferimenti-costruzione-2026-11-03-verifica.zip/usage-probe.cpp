#include "cad_sketch_reference_usage.h"
#include "cad_sketch_refs.h"
#include "cad_constraints.h"
#include "cad_document_io.h"
#include <iostream>
#include <stdexcept>
using namespace ForgeCad;
void require(bool ok,const char *msg){if(!ok)throw std::runtime_error(msg);}
int main(){try{
    DocumentState doc;SketchObject source;source.storyId=1;source.segments={{{1,0},{1,5}},{{2,0},{2,5}},{{3,0},{3,5}},{{4,0},{4,5}}};SketchObject sketch;sketch.storyId=2;doc.sketches={source,sketch};
    const auto add=[&](int entity,bool visible){GeometryRef r;r.kind=7;r.index=0;r.featureId=1;r.element={0,entity,-1};require(appendLinkedSketchReference(doc.sketches[1],r,doc.sketches,{},false,true,100,nullptr,visible).isEmpty(),"append fixture");};
    add(0,false);doc.sketches[1].segments.append({{20,0},{20,5}});add(1,false);add(2,true);add(3,false);
    auto &s=doc.sketches[1];SketchConstraint c;c.type=ConstraintType::Coincident;c.first={0,1,0};c.second={0,2,0};s.geometricConstraints={c};
    ExtrusionObject loft;loft.loftSections.resize(1);loft.loftSections[0].kind=7;loft.loftSections[0].index=1;loft.loftSections[0].featureId=2;loft.loftSections[0].element={0,4,-1};doc.extrusions={loft};const auto before=doc;
    const auto map=pruneUnusedSketchReferences(1,doc.sketches,doc.extrusions);require(map.changed()&&doc.sketches[1].linkedReferences.size()==3,"solo orfano eliminato");
    require(doc.sketches[1].geometricConstraints.size()==1&&doc.sketches[1].geometricConstraints[0].first.element==0&&doc.sketches[1].geometricConstraints[0].second.element==1,"vincolo intatto e rinumerato");require(doc.extrusions[0].loftSections[0].element.element==3,"riferimento loft rinumerato");require(before.sketches[1].segments.size()==5&&before.sketches[1].linkedReferences.size()==4,"snapshot immutabile");
    auto faulty=before;auto broken=std::make_shared<SketchLinkedReference>(*faulty.sketches[1].linkedReferences[0]);broken->error="Sorgente rimossa";faulty.sketches[1].linkedReferences[0]=broken;faulty.sketches[1].referenceError=broken->error;
    pruneUnusedSketchReferences(faulty);require(faulty.sketches[1].referenceError.isEmpty(),"errore della sola cache orfana eliminato");
    auto malformed=before;malformed.sketches[1].geometricConstraints[0].first.element=999;auto invalidBefore=malformed;
    pruneUnusedSketchReferences(malformed);require(malformed.sketches[1].linkedReferences.size()==invalidBefore.sketches[1].linkedReferences.size()&&malformed.sketches[1].geometricConstraints[0].first.element==999,"vincolo malformato conservato senza potatura");
    auto copy=doc;copy.sketches[1].geometricConstraints.clear();pruneUnusedSketchReferences(copy);require(copy.sketches[1].linkedReferences.size()==2,"rimozione ultimo vincolo elimina cache senza rimuovere conversione o riferimento a valle");
    QByteArray bytes;require(encodeDocument(doc,bytes,false).isEmpty(),"codec");DocumentState restored;require(decodeDocument(bytes,restored).isEmpty()&&restored.sketches[1].linkedReferences.size()==3,"codec preserva usati");
    std::cout<<"PASS prototipo: orfani, vincoli, conversioni, riferimento loft, snapshot immutabili e codec\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}}
