from pathlib import Path
import shlex,json,subprocess,sys
r=Path('/home/myungit/Linux_CAD_forFree');q=Path('/tmp/forgecad-reference-cleanup');b=r/'forgecad-release';commands=json.loads((b/'compile_commands.json').read_text())
prefix=(r/'tests/test_viewport.cpp').read_text().split('#include "test_declared_history_cache.h"')[0]
(q/'app-probe.cpp').write_text(prefix+'#include "test_document_read.h"\n'+'''class ViewportInteractionTest {public:
#include "test_sketch_construction.h"
#include "test_sketch_linked_refs.h"
    static void constructionDimensionRegressions() {
        using namespace ForgeCad;
        const auto mouse=[](CadViewport &v,const QPointF &point,bool move=false) {
            const auto pixel=v.projectWorldPoint(v.mapSketchPoint(point,v.sketches_[0]));
            QMouseEvent event(move?QEvent::MouseMove:QEvent::MouseButtonPress,pixel,pixel,
                move?Qt::NoButton:Qt::LeftButton,move?Qt::NoButton:Qt::LeftButton,Qt::NoModifier);
            if(move)v.mouseMoveEvent(&event);else v.mousePressEvent(&event);
            if(!move){QMouseEvent release(QEvent::MouseButtonRelease,pixel,pixel,Qt::LeftButton,Qt::NoButton,Qt::NoModifier);v.mouseReleaseEvent(&release);}
        };
        int cases=0;
        for(int sourceKind:{1,2})for(bool referencesFirst:{true,false})for(double halfLength:{100.0,5.0}) {
            SketchObject sketch;sketch.name=QStringLiteral("Costruzione quotata");
            int line=-1;
            const auto appendLine=[&] {
                line=sketch.segments.size();sketch.segments.append({{0,0},{10,0}});
                sketch.constraints.append(-1);sketch.segmentLengths.append(0);sketch.segmentAngles.append(-1);
                sketch.constructionSegments.append(line);
            };
            const auto appendAxis=[&] {
                GeometryRef axis;axis.kind=sourceKind;axis.index=sourceKind==1?1:0;
                require(appendLinkedSketchReference(sketch,axis,{},{},false,true,halfLength).isEmpty(),"riferimento automatico piano standard o asse X");
            };
            if(referencesFirst){appendAxis();appendLine();}else{appendLine();appendAxis();}
            const auto anchor=sketch.linkedReferences.front()->entities.front();
            // La cache ha un vero utilizzo: il punto iniziale e' vincolato al
            // centro dell'asse, anziche' essere una cache orfana della fixture.
            sketch.geometricConstraints={makeConstraint(sketch,ConstraintType::Midpoint,{{0,line,0},{anchor.kind,anchor.element,-1}}),
                makeConstraint(sketch,ConstraintType::Horizontal,{{0,line,-1}})};
            CadViewport view;view.resize(1000,700);view.sketches_={sketch};view.selectSketch(0);
            view.camera_.zoom_=20;view.geometrySnap_=view.gridSnap_=view.originSnap_=false;view.history_.clear();
            const auto hidden=sketch.linkedReferences.front()->entities.front();
            const auto cachedAxis=sketch.segments[hidden.element];
            ConstraintRef ref;
            require(view.dimensionRefAt({5,0},ref)&&ref==ConstraintRef{0,line,-1},"clic sul tratto sceglie la costruzione visibile invece del riferimento nascosto");
            require(view.dimensionRefAt({0,0},ref)&&ref==ConstraintRef{0,line,0},"primo estremo della costruzione ancora quotabile");
            require(view.dimensionRefAt({10,0},ref)&&ref==ConstraintRef{0,line,1},"secondo estremo della costruzione ancora quotabile");
            view.selectSketchElement({5,0},false);
            require(view.sketchSelections_==QVector<SketchElementSelection>{{0,line}},"preselezione della costruzione visibile");
            require(view.beginDimensionTool().isEmpty()&&view.dimensionPreviewValid_,"quota disponibile sulla costruzione preselezionata");
            view.setDimensionOrientation(1);
            view.sketchSelections_.clear();view.refreshDimensionPreview({5,0});
            mouse(view,{5,0},true);
            require(view.dimensionHover_==ConstraintRef{0,line,-1},"hover quota sulla costruzione visibile");
            mouse(view,{5,0});
            require(view.dimensionPreviewValid_&&view.constraintSelection()==QVector<ConstraintRef>{{0,line,-1}},"clic reale seleziona la linea intera e prepara la quota");
            bool entered=false;
            QTimer::singleShot(0,&view,[&] {
                auto *dialog=view.findChild<QDialog*>();if(!dialog)return;
                auto *value=dialog->findChild<QDoubleSpinBox*>();auto *buttons=dialog->findChild<QDialogButtonBox*>();
                if(value&&buttons){value->setValue(18);entered=true;buttons->button(QDialogButtonBox::Ok)->click();}
                else dialog->reject();
            });
            mouse(view,{5,3});
            require(entered&&view.sketches_[0].geometricConstraints.size()==3,"pannello Quota conferma la lunghezza della costruzione");
            const auto &dimension=view.sketches_[0].geometricConstraints.last();
            require(dimension.type==ConstraintType::Distance&&dimension.first==ConstraintRef{0,line,-1}
                &&std::abs(currentMeasure(view.sketches_[0],dimension)-18)<1e-7,"quota guidante sul segmento intero");
            require(view.sketches_[0].isConstructionSegment(line)&&view.sketches_[0].segments[hidden.element]==cachedAxis
                &&isHiddenSketchReference(view.sketches_[0],hidden.kind,hidden.element),"costruzione conservata e riferimento automatico immutato/nascosto");
            view.undo();require(view.sketches_[0].geometricConstraints.size()==2
                &&pointDistance(view.sketches_[0].segments[line].first,view.sketches_[0].segments[line].second)==10,"Undo quota di costruzione");
            view.redo();require(view.sketches_[0].geometricConstraints.size()==3
                &&std::abs(currentMeasure(view.sketches_[0],view.sketches_[0].geometricConstraints.last())-18)<1e-7,"Redo quota di costruzione");
            QTemporaryDir directory;const auto path=directory.filePath(QStringLiteral("costruzione.prt"));
            require(saveDocumentFile(path,view.currentDocument(),false).isEmpty(),"salvataggio quota di costruzione");
            DocumentState loaded;require(loadDocumentFile(path,loaded).isEmpty()&&loaded.sketches[0].isConstructionSegment(line)
                &&std::abs(currentMeasure(loaded.sketches[0],loaded.sketches[0].geometricConstraints.last())-18)<1e-7,"riapertura conserva quota e ruolo di costruzione");
            require(view.dimensionRefAt({-halfLength,0},ref)&&ref.kind==hidden.kind&&ref.element==hidden.element,
                "riferimenti automatici ancora disponibili per le quote verso geometria esterna");
            ++cases;
        }
        std::cout<<"PASS construction dimensions: "<<cases<<" casi, hover/clic/preselezione, pannello, solver, Undo/Redo e persistenza"<<std::endl;
    }
static void referenceSelectionFlow(){using namespace ForgeCad;CadViewport v;
        const int sketch = v.createSketch(0, QStringLiteral("Test riferimenti"));
        require(sketch >= 0, "creazione schizzo");
        v.selectSketch(sketch);
        v.history_.clear();
        v.selectSketchReference(2, 0);
        require(v.sketches_.at(sketch).segments.size() == 1, "riferimento asse X");
        require(v.constraintSelection().size() == 1, "asse scelto per i vincoli");
        v.selectPlane(1);
        require(v.sketches_.at(sketch).segments.isEmpty(), "scelta coincidente deseleziona senza duplicare e libera la cache");
        require(!v.canUndo(), "selezione/deselezione riferimenti senza Undo");
        v.selectSketchReference(2, 0);
        v.selectSketchReference(2, 1);
        require(v.sketches_.at(sketch).segments.size() == 2, "riferimento asse Y");
        require(analyzeSketch(v.sketches_.at(sketch)).fullyDefined(), "riferimenti fissi senza liberta' residue");
        v.selectSketchReference(2, 2);
        v.selectPlane(0);
        require(v.sketches_.at(sketch).segments.size() == 2, "riferimenti degeneri non modificano lo schizzo");
        require(!v.canUndo() && v.currentDocument().sketches[sketch].linkedReferences.isEmpty(), "selezioni di assi senza geometria persistente");
        v.recordUndo();
        auto &profile=v.sketches_[sketch];const int drawn=profile.segments.size();
        profile.segments.append({{1,2},{4,3}});profile.constraints.append(-1);profile.segmentLengths.append(0);profile.segmentAngles.append(-1);
        profile.geometricConstraints.append(makeConstraint(profile,ConstraintType::Parallel,{{0,drawn,-1},{0,0,-1}}));
        v.sketchEdited();
        require(v.sketches_[sketch].linkedReferences.size()==1 && v.sketches_[sketch].segments.size()==2,"solo l'asse usato dalla geometria resta persistente");
        v.undo();
        require(v.sketches_.at(sketch).segments.isEmpty(), "Undo geometria rimuove anche il riferimento usato");
        v.redo();
        require(v.sketches_.at(sketch).segments.size() == 2 && v.sketches_[sketch].linkedReferences.size()==1, "Redo geometria ripristina il riferimento usato");

        SketchObject work = v.sketches_.at(sketch);
        const int line = int(work.segments.size());
        work.segments.append({QPointF(1, 2), QPointF(4, 3)});
        work.constraints.append(-1); work.segmentLengths.append(0); work.segmentAngles.append(-1);
        const auto fixed = work.segments.at(0);
        work.geometricConstraints.append(makeConstraint(work, ConstraintType::Parallel, {{0, line, -1}, {0, 0, -1}}));
        require(solveSketch(work).ok, "vincolo parallelo all'asse");
        require(work.segments.at(0) == fixed, "il riferimento resta fisso");
        require(std::fabs(work.segments.at(line).second.y() - work.segments.at(line).first.y()) < 1e-8, "segmento parallelo al riferimento");

}
static void realFileCleanup() {
    using namespace ForgeCad;using namespace Kernel;
    const QString path="/tmp/forgecad-reference-cleanup/SurfaceModellingExample219.prt";DocumentState original;require(loadDocumentFile(path,original).isEmpty(),"lettura copia reale");auto cleaned=original;
    int linksBefore=0,linksAfter=0;for(const auto &s:original.sketches)linksBefore+=s.linkedReferences.size();
    pruneUnusedSketchReferences(cleaned);for(const auto &s:cleaned.sketches)linksAfter+=s.linkedReferences.size();
    require(cleaned.extrusions.size()==original.extrusions.size()&&cleaned.sketches.size()==original.sketches.size(),"parti CAD invariate");
    for(int i=0;i<original.sketches.size();++i){const auto &a=original.sketches[i],&b=cleaned.sketches[i];require(a.geometricConstraints.size()==b.geometricConstraints.size(),"nessun vincolo reale eliminato");const auto first=forgeSketchSegments(a),second=forgeSketchSegments(b);require(first.size()==second.size(),"profilo reale invariato");for(std::size_t k=0;k<first.size();++k)for(int j=0;j<=19;++j){const auto p=first[k].curve->point(first[k].range.lo+first[k].range.length()*j/19.),q=second[k].curve->point(second[k].range.lo+second[k].range.length()*j/19.);require(distance(p,q)==0,"geometria del profilo reale bit-identica");}}
    CadViewport view;view.loadDocument(cleaned);require(view.rebuildAllFeatures()==0,"tutte le funzioni reali ricostruite dopo pulizia");
    for(bool cache:{false,true}){const QString output=QStringLiteral("/tmp/forgecad-reference-cleanup/cleaned-%1.prt").arg(cache);require(saveDocumentFile(output,view.currentDocument(),cache).isEmpty(),"salvataggio copia ripulita");DocumentState read;require(loadDocumentFile(output,read).isEmpty(),"riapertura copia ripulita");CadViewport restored;restored.loadDocument(read);require(restored.rebuildAllFeatures()==0,"ricostruzione dopo lettura reale");}
    std::cout<<"PASS CAD reale: cache "<<linksBefore<<" -> "<<linksAfter<<", tutti i vincoli e i profili invariati, rebuild e codec/cache"<<std::endl;
}

};
int main(int argc,char**argv){QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADReferenceCleanupQA");QCoreApplication::setApplicationName("ReferenceCleanup");QTemporaryDir prefs;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,prefs.path());try{const auto mode=app.arguments().value(1);const bool gl=app.arguments().contains("--gl");if(mode=="dimensions")ViewportInteractionTest::constructionDimensionRegressions();else if(mode=="selection")ViewportInteractionTest::referenceSelectionFlow();else if(mode=="file")ViewportInteractionTest::realFileCleanup();else if(mode=="usage")ViewportInteractionTest::sketchReferenceUsage();else if(mode=="construction")ViewportInteractionTest::sketchConstructionVisibility(gl);else if(mode=="linked")ViewportInteractionTest::linkedSketchReferences();else if(mode=="visibility")ViewportInteractionTest::linkedReferenceVisibility(gl);return 0;}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}}
''')
sources=['cad_forge.cpp','forgeCad2026_viewport_document.cpp','forgeCad2026_viewport_interaction.cpp','forgeCad2026_viewport_render.cpp','forgeCad2026_viewport_scene.cpp','forgeCad2026_viewport_selection.cpp','forgeCad2026_viewport_sketch.cpp','forgeCad2026_viewport_storyboard.cpp','cad_sketch_reference_usage.cpp']
overrides={}
for source in sources+['forgeCad2026.cpp']:
    row=next(a for a in commands if 'CMakeFiles/forgecad.dir/'+source+'.o' in a['command']);a=shlex.split(row['command']);name='app-probe' if source=='forgeCad2026.cpp' else source[:-4];out=q/(name+'.o');overrides['CMakeFiles/forgecad.dir/'+source+'.o']=str(out)
    if source!='forgeCad2026.cpp' and out.exists() and out.stat().st_mtime>=(r/source).stat().st_mtime:continue
    a[a.index('-o')+1]=str(out)
    if source=='forgeCad2026.cpp':a[-1]=str(q/'app-probe.cpp')
    a=[x if x!='-O3' else '-O0' for x in a];a+=['-I'+str(r/'tests'),'-DFORGECAD_SOURCE_DIR="'+str(r)+'"'];subprocess.run(a,cwd=b,check=True);overrides['CMakeFiles/forgecad.dir/'+source+'.o']=str(out)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[overrides.get(x,x) for x in a];a[a.index('-o')+1]=str(q/'app-probe');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(q/'app-probe.d') for x in a];subprocess.run(a,cwd=b,check=True)
