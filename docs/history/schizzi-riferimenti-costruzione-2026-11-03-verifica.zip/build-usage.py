from pathlib import Path
import shlex,json,subprocess
r=Path('/home/myungit/Linux_CAD_forFree');q=Path('/tmp/forgecad-reference-cleanup');b=r/'forgecad-release';commands=json.loads((b/'compile_commands.json').read_text());row=next(a for a in commands if 'CMakeFiles/forgecad.dir/cad_sketch_refs.cpp.o' in a['command'])
for name in ['cad_sketch_reference_usage','usage-probe']:
    a=shlex.split(row['command']);a[a.index('-o')+1]=str(q/(name+'.o'));a[-1]=str(q/(name+'.cpp'));a += ['-I'+str(q)];subprocess.run(a,cwd=b,check=True)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(q/'usage-probe.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a=[x for x in a if not x.endswith('/cad_sketch_reference_usage.cpp.o')];a.insert(a.index(str(q/'usage-probe.o'))+1,str(q/'cad_sketch_reference_usage.o'));a[a.index('-o')+1]=str(q/'usage-probe');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(q/'usage-probe.d') for x in a];subprocess.run(a,cwd=b,check=True)
