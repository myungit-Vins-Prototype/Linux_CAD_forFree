from pathlib import Path
import subprocess,shlex,sys
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-storyboard-pick');b=r/'forgecad-release';a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/'probe.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/'probe');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/'probe.d') for x in a];subprocess.run(a,cwd=b,check=True)
