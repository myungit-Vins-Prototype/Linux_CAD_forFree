from pathlib import Path
import shlex,json,subprocess
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-storyboard-pick');b=r/'forgecad-release'
s=(r/'tests/test_viewport.cpp').read_text().split('class ViewportInteractionTest {')[0]
s+='''class ViewportInteractionTest { public:
#include "test_storyboard_panel_selection.h"
};
int main(int argc,char **argv) {
 QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);
 QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADStoryboardQA");QCoreApplication::setApplicationName("Storyboard");
 QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());
 try {if(app.arguments().contains("--mirror-only")){ViewportInteractionTest::mirrorDeleteOnce();return 0;}ViewportInteractionTest::storyboardPanelSelection();ViewportInteractionTest::loftFailureDiagnostics();ViewportInteractionTest::mirrorDeleteOnce();return 0;}
 catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
}
'''
s=s.replace('};\nint main', (o/'real-panels.inc').read_text()+(o/'real-delete.inc').read_text()+'};\nint main')
s=s.replace('try {if(app.arguments()', 'try {if(app.arguments().contains(\"--real-panels\")){ViewportInteractionTest::realLoftPanel();return 0;}if(app.arguments()')
s=s.replace('#include \"test_storyboard_panel_selection.h\"',(r/'tests/test_storyboard_panel_selection.h').read_text().replace('window.addDockWidget(Qt::RightDockWidgetArea,other);','window.addDockWidget(Qt::RightDockWidgetArea,other);other->hide();').replace('window.resize(1100,760);window.show();','window.resize(1100,760);').replace('view->extrusions_.append(body);','forgeTessellate(*body.forgeBody,view->tessellationQuality_,body.display);view->extrusions_.append(body);window.show();'))
s=s.replace('try {if(app.arguments()', 'try {if(app.arguments().contains(\"--real-delete\")){ViewportInteractionTest::realMirrorDelete();return 0;}if(app.arguments()')
s=s.replace('QPointF(rect.center())','QPointF(qMin(rect.left()+80,tree->viewport()->width()-8),rect.center().y())')
(o/'probe.cpp').write_text(s)
commands=json.loads((b/'compile_commands.json').read_text());row=next(a for a in commands if 'CMakeFiles/forgecad.dir/forgeCad2026.cpp.o' in a['command']);a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/'probe.o');a[-1]=str(o/'probe.cpp');a=[x if x!='-O3' else '-O0' for x in a];a+=['-g','-I'+str(r/'tests'),'-DFORGECAD_SOURCE_DIR="'+str(r)+'"'];subprocess.run(a,cwd=row['directory'],check=True)
if '--link' in __import__('sys').argv:
 a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/'probe.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/'probe');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/'probe.d') for x in a];subprocess.run(a,cwd=b,check=True)
