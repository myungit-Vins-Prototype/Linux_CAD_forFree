#include <set>
#include <QThread>
#include <QEventLoop>
#include <QCryptographicHash>
#include <condition_variable>
#if defined(__GLIBC__)
#include <malloc.h>
#endif
#include "../cad_gpu_broad_phase.h"
#include "../cad_cuda_tessellation.h"
#include "../cad_document_read.h"
#include "../cuda_support.h"
#include <QSaveFile>
// I componenti GUI sono dichiarati negli header e compilati separatamente.
#include "../forgeCad2026_gui.h"
#include "../forgeCad2026_viewport.h"
#include "../forgeCad2026_storyboard.h"
#include "../forgeCad2026_dialogs.h"
#include "../cad_expression.h"
#include "../cad_features.h"
#include "../cad_feature_build.h"
#include "../cad_feature_dependencies.h"
#include "../cad_datum.h"
#include "../cad_storyboard_selection.h"
#include "../cad_loft_diagnostics.h"
#include "../forgeCad2026_dialogs_common.h"
#include "fk_curve_ops.h"
#include "fk_bspline.h"
#include "../cad_forge.h"
#include "../cad_pattern.h"
#include "../cad_extrude.h"
#include "../cad_sketch_refs.h"
#include "../cad_history_graph.h"
#include "../cad_model_history.h"
#include "../cad_topology_ref.h"
#include "../cad_icons.h"
#include "../cad_menu.h"
#include "../cad_kernel.h"
#include "../cad_curve_extract.h"
#include "../cad_projected_curve.h"
#include "../cad_surface_tools.h"
#include "../cad_spatial_sketch.h"
#include "../kernel/tests/surface_tools_fixture.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLocale>
#include "../cad_measure.h"
#include "../toolbar_editor.h"
#include <QOpenGLContext>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>

using ForgeCad::Gui::uiFont;
using ForgeCad::Gui::pointLength;
using ForgeCad::Gui::pointDistance;
using ForgeCad::Gui::featureIconName;
using ForgeCad::Gui::kSelectionColor;
using ForgeCad::Gui::kHoverColor;
using ForgeCad::Gui::runUntilApplied;
using ForgeCad::Gui::wrappedNote;
#include "fk_blend.h"
#include "fk_blend_surface.h"
#include "fk_body_check.h"
#include "fk_boolean.h"
#include "fk_body_io.h"
#include "../cad_snapshot_chunks.h"
#include "fk_step.h"
#include "fk_iges.h"
#include "fk_classify.h"
#include "fk_extrude.h"
#include "fk_sew.h"
#include "fk_helix.h"
#include "fk_mass.h"
#include "fk_sketch_projection.h"
#include "fk_pcurve.h"
#include "fk_primitives.h"
#include "fk_revolve.h"
#include "fk_sheet.h"
#include "fk_surface_algo.h"
#include "fk_tessellate.h"
#include "fk_loft.h"
#include "fk_project.h"
#include "fk_parallel.h"
#include <QGraphicsItem>
#include <QGraphicsView>
#include <QSurfaceFormat>
#include <QTemporaryDir>
#include "../cad_element_names.h"
#include <QProcess>
#include <QDateTime>
#include <QPointingDevice>
#include <QSemaphore>
#include <QCryptographicHash>
#include <QtEndian>
#include <fstream>
#include <cstring>
#include <iostream>
#include <stdexcept>

static void require(bool ok, const char *message) {
    if (!ok) throw std::runtime_error(message);
}

static QByteArray testDocumentUncompress(const QByteArray &document, qsizetype offset, qsizetype size = -1) {
    QByteArray result;
    require(document.size() >= 11 && ForgeCad::DocumentReadDetail::uncompress(document.mid(offset, size),
        qsizetype(1024)*1024*1024, result, quint8(document.at(6))), "decompressione blocco fixture nativa");
    return result;
}
static QByteArray testDocumentCompress(const QByteArray &data, const QByteArray &document) {
    return ForgeCad::DocumentReadDetail::compress(data, quint8(document.at(6)), 9);
}

// Configurabile anche nei lanci diretti del runner; CTest passa la cartella da CMake.
static QString exampleDocumentPath(const char *name) {
    const QString directory = qEnvironmentVariable("FORGECAD_EXAMPLE_DIR", QStringLiteral(FORGECAD_SOURCE_DIR "/File_Esempio"));
    return QDir(directory).filePath(QString::fromUtf8(name));
}

#include "test_declared_history_cache.h"
#include "test_boolean_history.h"
#include "test_extrusion_history.h"
#include "test_revolution_history.h"
#include "test_all_history.h"
#include "test_native_revisions.h"
#include "test_workspace_revisions.h"
#include "test_linked_drawing.h"
#include "test_drawing_revisions.h"
#include "test_projected_drawing_file.h"
#include "test_drawing_multisheet.h"
#include "test_drawing_revision_restore.h"
#include "test_drawing_release.h"
#include "test_drawing_mouse.h"
#include "test_drawing_section_model.h"
#include "test_drawing_performance.h"
#include "document_regression.h"
#include "test_document_read.h"
#include "test_history_suppression.h"
#include "test_pattern_placements.h"
#include "test_zoom_input.h"
#include "test_solver_partition.h"
class ViewportInteractionTest { public:
static void storyboardPanelSelection() {
    using namespace ForgeCad;
    using namespace ForgeCad::Kernel;
    QMainWindow window;
    auto *view=new CadViewport(&window);window.setCentralWidget(view);
    auto *dock=new QDockWidget(&window);auto *tree=new StoryboardTree(dock);dock->setWidget(tree);
    window.addDockWidget(Qt::LeftDockWidgetArea,dock);
    auto *other=new QDockWidget(&window);other->setWidget(new QLabel("Altro"));window.addDockWidget(Qt::RightDockWidgetArea,other);other->hide();
    installStoryboardSelection(&window,view,tree);
    window.resize(1100,760);
    SketchObject sketch;sketch.name="Profilo nascosto";sketch.visible=false;sketch.storyId=101;
    sketch.segments={{{0,0},{10,0}},{{10,0},{10,5}}};view->sketches_.append(sketch);
    ExtrusionObject body;body.feature=BodyFeature::Imported;body.featureId=102;body.modelBodyId=1;body.name="Cubo";
    body.forgeBody=std::make_shared<Body>(makeBox(Frame3(),10,10,10));body.visible=true;body.solid=true;
    forgeTessellate(*body.forgeBody,view->tessellationQuality_,body.display);view->extrusions_.append(body);window.show();
    const auto row=[&](const QString &name,int type,int index) {
        auto *item=new QTreeWidgetItem(tree,{name});item->setData(0,Qt::UserRole,type);item->setData(0,Qt::UserRole+1,index);
        item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsSelectable|Qt::ItemIsUserCheckable);item->setCheckState(0,Qt::Unchecked);return item;
    };
    auto *sketchRow=row(sketch.name,kTreeSketch,0);auto *bodyRow=row(body.name,kTreeExtrusion,0);
    int changed=0,clicked=0,edited=0;
    QObject::connect(tree,&QTreeWidget::itemChanged,&window,[&]{++changed;});
    QObject::connect(tree,&QTreeWidget::itemClicked,&window,[&]{++clicked;});
    QObject::connect(tree,&QTreeWidget::itemDoubleClicked,&window,[&]{++edited;});
    const auto pump=[] {for(int i=0;i<4;++i)QApplication::processEvents();};pump();
    const auto click=[&](QTreeWidgetItem *item,bool check=false) {
        tree->scrollToItem(item);pump();const auto rect=tree->visualItemRect(item);
        const QPointF point=check?QPointF(rect.left()+8,rect.center().y()):QPointF(qMin(rect.left()+80,tree->viewport()->width()-8),rect.center().y());
        QMouseEvent press(QEvent::MouseButtonPress,point,tree->viewport()->mapToGlobal(point.toPoint()),Qt::LeftButton,Qt::LeftButton,Qt::NoModifier);
        QApplication::sendEvent(tree->viewport(),&press);
        QMouseEvent release(QEvent::MouseButtonRelease,point,tree->viewport()->mapToGlobal(point.toPoint()),Qt::LeftButton,Qt::NoButton,Qt::NoModifier);
        QApplication::sendEvent(tree->viewport(),&release);pump();
    };
    FunctionDialogPanel panel(view,false);panel.createScrollableForm()->addRow(new QLabel("Selezione",&panel));
    GeometryRef chosen;int picked=0;
    view->setReferencePickCallback([&](bool ok,GeometryRef ref){if(ok){chosen=ref;++picked;}});
    {
        WindowLock lock(&window,view,&panel);
        require(dock->isEnabled()&&!other->isEnabled(),"solo storyboard resta disponibile durante il pannello");
        require(view->beginReferencePick(DatumRoleCurve,-1).isEmpty(),"picker curve avviato");
        click(sketchRow);
        require(picked==1&&chosen.kind==7&&chosen.index==0&&chosen.element.kind==-1,"clic singolo sceglie schizzo intero nascosto");
        require(!view->sketches_[0].visible&&changed==0&&clicked==0&&edited==0,"scelta non cambia visibilita o apre modifica");
        std::vector<PathSegment> path;QString reason;
        require(geometryRefPath(chosen,-1,view->sketches_,view->extrusions_,path,&reason)&&path.size()==2,"schizzo intero consumabile dai picker di curve");
        view->beginReferencePick(DatumRolePoint,-1);click(sketchRow);
        require(picked==1,"campo punto non riceve schizzo intero");
        QTreeWidgetItem *pointRow=nullptr;
        for(QTreeWidgetItemIterator it(tree);*it;++it)if((*it)->text(0).startsWith("Punto di")){pointRow=*it;break;}
        require(pointRow,"entita compatibili dello schizzo espanse");click(pointRow);
        require(picked==2&&chosen.kind==6,"punto di schizzo dalla storyboard");
        view->beginReferencePick(DatumRoleCurve,-1);click(sketchRow,true);
        require(picked==3&&sketchRow->checkState(0)==Qt::Unchecked&&changed==0,"clic sulla spunta seleziona senza cambiare visibilita");
        view->beginReferencePick(DatumRoleCurve,-1);click(bodyRow);
        QTreeWidgetItem *edgeRow=nullptr;
        for(QTreeWidgetItemIterator it(tree);*it;++it)if((*it)->text(0).startsWith("Spigolo E")){edgeRow=*it;break;}
        require(edgeRow,"bordi B-rep disponibili sotto il corpo");click(edgeRow);
        require(picked==4&&chosen.kind==4&&geometryRefPath(chosen,-1,view->sketches_,view->extrusions_,path,&reason),"bordo esatto passato al picker");
        view->beginReferencePick(DatumRoleCurve,0);require(view->storyboardReferences(SceneObjectKind::Extrusion,0).isEmpty(),"corpo futuro escluso");
        view->cancelReferencePick();
        QKeyEvent rename(QEvent::KeyPress,Qt::Key_F2,Qt::NoModifier);QApplication::sendEvent(tree,&rename);
        require(edited==0&&changed==0,"modifica impedita durante pannello anche senza picker attivo");
    }
    pump();require(dock->isEnabled()&&other->isEnabled()&&!view->interactionLocked(),"stato normale ripristinato alla chiusura");
    view->setReferencePickCallback({});
    require(view->startEdgePick(false,false,false,true).isEmpty(),"picker raccordo avviato");
    const auto edges=view->storyboardReferences(SceneObjectKind::Extrusion,0);
    GeometryRef edge;for(const auto &ref:edges)if(ref.kind==4){edge=ref;break;}
    require(edge.kind==4&&view->pickStoryboardReference(edge).isEmpty()&&!view->edgePickPoints().isEmpty(),"bordo storyboard nel picker raccordo");
    require(view->pickStoryboardReference(edge).isEmpty()&&view->edgePickPoints().isEmpty(),"secondo clic toglie bordo raccordo");
    GeometryRef face;for(const auto &ref:edges)if(ref.kind==5){face=ref;break;}
    require(face.kind==5&&view->pickStoryboardReference(face).isEmpty()&&!view->edgePickPoints().isEmpty()
        &&view->edgePickPoints().first().role==kEdgePointFaceBoundary,"faccia conserva il ruolo genealogico di selezione del suo bordo");
    require(view->pickStoryboardReference(face).isEmpty()&&view->edgePickPoints().isEmpty(),"secondo clic rimuove bordo della faccia");
    view->endEdgePick();
    int pattern=-1;tree->setSourcePickCallback([&](int index,bool){pattern=index;});click(bodyRow);
    require(pattern==0,"selezione sorgente ripetizione resta funzionante");tree->setSourcePickCallback({});
    pump();click(sketchRow);
    require(clicked>0,"clic normale ripristinato dopo picker");
    std::cout<<"PASS storyboard panel selection\n";
}

static void loftFailureDiagnostics() {
    using namespace ForgeCad;using namespace ForgeCad::Kernel;
    QVector<SketchObject> sketches;
    const auto profile=[](QString name,double z) {
        SketchObject s;s.name=name;s.customFrame=true;s.frame.origin[2]=z;s.segments={{{0,0},{10,0}}};return s;
    };
    sketches.append(profile("Sezione base",0));sketches.append(profile("Sezione finale",10));
    QVector<ExtrusionObject> bodies;
    for(int i=0;i<2;++i){ExtrusionObject b;b.feature=BodyFeature::ExtractedCurve;b.name=i?"Guida lontana":"Guida corretta";b.featureId=i+10;
        // Percorso 3D limitato, come nelle estrazioni reali.
        b.curve=std::make_shared<BSplineCurve<3>>(1,std::vector<double>{0,0,1,1},std::vector<Vec3>{Vec3(i?20:0,0,0),Vec3(i?20:0,0,10)});b.curves={b.curve};bodies.append(b);}
    ExtrusionObject d;d.feature=BodyFeature::Loft;d.loftSurface=true;
    for(int i=0;i<2;++i){GeometryRef ref;ref.kind=7;ref.index=i;ref.element={-1,-1,-1};d.loftSections.append(ref);}
    for(int i=0;i<2;++i){GeometryRef ref;ref.kind=9;ref.index=i;ref.featureId=bodies[i].featureId;d.loftEdgeGuides.append(ref);}
    d.loftGuideOrder={1,0};
    QString error;require(!forgeReferencedLoft(d,-1,sketches,bodies,&error),"guida distante fallisce realmente nel kernel");
    const auto failure=loftFailure(error);
    require(failure.guide==0&&failure.section==0&&error.contains("Guida lontana")&&error.contains("Sezione base"),"identita guida e sezione rispettano ordine kernel");
    require(!visibleLoftError(error).contains("[[loft-"),"marker interni assenti dal messaggio visibile");
    const auto paths=loftDiagnosticPaths(failure,d,-1,sketches,bodies);
    require(paths.size()==2&&paths[0].guide&&!paths[1].guide&&paths[0].path[0].curve->point(0).x()==20,"diagnostica esatta sulla guida riordinata e sulla sola sezione coinvolta");
    CadViewport view;view.sketches_=sketches;view.extrusions_=bodies;view.preview_.definition=d;
    require(!view.preparePreviewError(error).contains("[[loft-")&&view.previewLoftErrors_.size()==2,"anteprima prepara due overlay");
    require(view.previewLoftErrors_[0].color.red()>view.previewLoftErrors_[0].color.green()
        &&view.previewLoftErrors_[0].color!=view.previewLoftErrors_[1].color,"guida rossa e sezione di colore distinto");
    view.resize(1000,750);view.ensureVisibleBodyDisplays();view.fitAll();view.show();
    for(int i=0;i<4;++i)QApplication::processEvents();
    QImage image(view.size(),QImage::Format_ARGB32_Premultiplied);image.fill(Qt::transparent);
    {QPainter painter(&image);view.drawLoftDiagnostics(painter);}require(!image.isNull(),"etichette e frecce renderizzabili senza cambiare modello");
    int red=0,orange=0;
    for(int y=0;y<image.height();++y)for(int x=0;x<image.width();++x) {
        const auto pixel=image.pixelColor(x,y);
        if(pixel.alpha()>100 && pixel.red()>220 && pixel.green()<100)++red;
        if(pixel.alpha()>100 && pixel.red()>220 && pixel.green()>130 && pixel.green()<210 && pixel.blue()<90)++orange;
    }
    require(red>10&&orange>10,"entrambi gli overlay ed etichette hanno pixel dei colori previsti");
    const auto platform=QGuiApplication::platformName();
    image.save(QStringLiteral("/tmp/forgecad-storyboard-pick/loft-diagnostics-overlay-%1.png").arg(platform));
    if(view.isValid())view.grabFramebuffer().save(QStringLiteral("/tmp/forgecad-storyboard-pick/loft-diagnostics-view-%1.png").arg(platform));
    view.preparePreviewError({});require(view.previewLoftErrors_.isEmpty(),"diagnostica eliminata quando errore risolto");
    view.preparePreviewError(error);view.clearPreview();require(view.previewLoftErrors_.isEmpty(),"diagnostica eliminata alla chiusura");
    std::cout<<"PASS loft failure diagnostics\n";
}

static void mirrorDeleteOnce() {
    using namespace ForgeCad;using namespace ForgeCad::Kernel;
    for(bool linked:{false,true})for(bool child:{false,true}) {
        DocumentState initial;ExtrusionObject source;source.name="Base";source.feature=BodyFeature::Primitive;
        source.primitive.kind=PrimitiveKind::Box;source.primitive.origin[0]=3;
        source.primitive.size[0]=source.primitive.size[1]=source.primitive.size[2]=2;initial.extrusions={source};
        CadViewport view;view.loadDocument(initial);
        ExtrusionObject mirror;mirror.feature=BodyFeature::Pattern;mirror.name="Specchio da eliminare";mirror.firstBody=0;mirror.pattern.kind=2;
        GeometryRef plane;plane.kind=1;plane.index=2;mirror.pattern.refs={plane};
        require(view.createBody(mirror,{0}).isEmpty()&&view.extrusions_.size()==3,"fixture specchio con due risultati");
        if(linked) {
            SketchObject sketch;sketch.name="Schizzo collegato";
            GeometryRef vertex;vertex.kind=3;vertex.index=2;vertex.featureId=view.extrusions_[2].featureId;
            vertex.point=vertexReference(*view.extrusions_[2].forgeBody,view.extrusions_[2].forgeBody->vertices().front());
            require(appendLinkedSketchReference(sketch,vertex,{},view.extrusions_).isEmpty(),"riferimento associativo al risultato dello specchio");
            view.sketches_.append(sketch);view.documentChanged();
        }
        const auto before=view.currentDocument();
        view.selectObject(SceneObjectKind::Extrusion,child?2:1);view.deleteSelection();
        require(view.extrusions_.size()==1&&view.extrusions_[0].feature==BodyFeature::Primitive,"un solo Elimina rimuove madre e risultati anche con schizzi collegati");
        require(view.extrusions_[0].error.isEmpty()&&view.isBodyDrawn(0),"base ripristinata senza specchio orfano arancione");
        if(linked)require(!view.sketches_.last().linkedReferences.first()->error.isEmpty(),"schizzo conserva errore esplicito del riferimento rimosso");
        view.undo();require(view.extrusions_.size()==before.extrusions.size()&&view.extrusions_[1].featureId==before.extrusions[1].featureId,"Undo unico ripristina gruppo con identita");
        view.redo();require(view.extrusions_.size()==1,"Redo elimina gruppo in una sola operazione");
    }
    std::cout<<"PASS mirror deletion once with linked sketches\n";
}

static void realLoftPanel() {
 using namespace ForgeCad;using namespace ForgeCad::Kernel;
 QMainWindow window;auto *view=new CadViewport(&window);window.setCentralWidget(view);
 auto *dock=new QDockWidget("Storyboard",&window);auto *tree=new StoryboardTree(dock);dock->setWidget(tree);window.addDockWidget(Qt::LeftDockWidgetArea,dock);dock->setMaximumWidth(270);installStoryboardSelection(&window,view,tree);
 window.resize(1500,1000);window.show();
 for(int i=0;i<2;++i){SketchObject s;s.name=i?"Profilo finale":"Profilo base";s.customFrame=true;s.frame.origin[2]=10*i;s.segments={{{0,0},{10,0}}};s.visible=false;view->sketches_.append(s);}
 for(int i=0;i<2;++i){SketchObject s;s.name=i?"Guida errata":"Guida sinistra";s.customFrame=true;s.frame.normal[0]=0;s.frame.normal[1]=1;s.frame.normal[2]=0;s.frame.xAxis[0]=1;s.frame.xAxis[1]=s.frame.xAxis[2]=0;s.segments={{{i?20.:0,0},{i?20.:0,-10}}};s.visible=false;view->sketches_.append(s);}
 QVector<QTreeWidgetItem*> rows;for(int i=0;i<4;++i){auto *row=new QTreeWidgetItem(tree,{view->sketches_[i].name});row->setData(0,Qt::UserRole,kTreeSketch);row->setData(0,Qt::UserRole+1,i);row->setFlags(Qt::ItemIsEnabled|Qt::ItemIsSelectable|Qt::ItemIsUserCheckable);row->setCheckState(0,Qt::Unchecked);rows.append(row);}
 for(int i=0;i<4;++i)QApplication::processEvents();view->fitView({QVector3D(0,0,0),QVector3D(20,0,10)});ExtrusionObject initial;initial.feature=BodyFeature::Loft;initial.loftSurface=true;initial.loftSketches={0,1};initial.loftGuides={2,3};initial.loftGuideOrder={1,0};
 int phase=0;std::exception_ptr failure;ExtrusionObject applied;QElapsedTimer elapsed;elapsed.start();QTimer timer;timer.setInterval(40);
 const auto click=[&](QTreeWidgetItem *item){tree->scrollToItem(item);auto p=QPointF(tree->visualItemRect(item).center());QMouseEvent press(QEvent::MouseButtonPress,p,tree->viewport()->mapToGlobal(p.toPoint()),Qt::LeftButton,Qt::LeftButton,Qt::NoModifier);QApplication::sendEvent(tree->viewport(),&press);QMouseEvent release(QEvent::MouseButtonRelease,p,tree->viewport()->mapToGlobal(p.toPoint()),Qt::LeftButton,Qt::NoButton,Qt::NoModifier);QApplication::sendEvent(tree->viewport(),&release);};
 QObject::connect(&timer,&QTimer::timeout,&window,[&]{auto *dialog=window.findChild<QDialog*>("loftDialog");if(!dialog||!dialog->isVisible())return;try{
   require(elapsed.elapsed()<12000,"timeout pannello loft reale");
   if(phase==0){if(view->previewError().isEmpty())return;require(view->previewError().contains("Guida errata")&&view->previewError().contains("Profilo base")&&view->previewLoftErrors_.size()==2,"pannello reale indica coppia corretta");
    require(view->isValid(),"contesto GL nativo valido");window.grab().save("/tmp/forgecad-storyboard-pick/real-loft-window-"+QGuiApplication::platformName()+".png");view->grabFramebuffer().save("/tmp/forgecad-storyboard-pick/real-loft-error-"+QGuiApplication::platformName()+".png");
    dialog->findChild<QPushButton*>("loftPickSections")->click();click(rows[0]);
    require(dialog->findChild<QListWidget*>("loftSections")->item(0)->checkState()==Qt::Unchecked,"sezione intera tolta dall'albero nel pannello");phase=1;
   }else if(phase==1){click(rows[0]);require(dialog->findChild<QListWidget*>("loftSections")->item(0)->checkState()==Qt::Checked,"sezione ripristinata dall'albero");
    dialog->findChild<QPushButton*>("loftPickGuides")->click();click(rows[3]);phase=2;
   }else if(phase==2){if(view->previewPending())return;require(view->previewError().isEmpty()&&view->preview_.valid,"guida sbagliata tolta dallo schizzo nella storyboard");require(view->previewLoftErrors_.isEmpty(),"overlay rimossi dopo correzione reale");
    view->grabFramebuffer().save("/tmp/forgecad-storyboard-pick/real-loft-valid-"+QGuiApplication::platformName()+".png");timer.stop();dialog->findChild<QDialogButtonBox*>()->button(QDialogButtonBox::Ok)->click();phase=3;
   }
 }catch(...){failure=std::current_exception();timer.stop();dialog->reject();}});timer.start();
 const auto accepted=loftDialog(&window,view,"Loft: storyboard e diagnostica",-1,initial,[&](const ExtrusionObject &d){applied=d;return QString();});timer.stop();if(failure)std::rethrow_exception(failure);
 require(accepted&&phase==3&&applied.loftGuides==QVector<int>{2}&&view->previewLoftErrors_.isEmpty()&&dock->isEnabled()&&!view->interactionLocked(),"conferma e cleanup pannello");
 for(const auto &s:view->sketches_)require(!s.visible,"selezione non modifica visibilita degli schizzi");
 std::cout<<"PASS real loft panel selection and error repair "<<qPrintable(QGuiApplication::platformName())<<std::endl;
}
static void realMirrorDelete() {
 using namespace ForgeCad;using namespace ForgeCad::Kernel;
 DocumentState initial;ExtrusionObject source;source.feature=BodyFeature::Primitive;source.name="Base";source.primitive.kind=PrimitiveKind::Box;source.primitive.origin[0]=3;source.primitive.size[0]=source.primitive.size[1]=source.primitive.size[2]=2;initial.extrusions={source};
 CadViewport fixture;fixture.loadDocument(initial);ExtrusionObject mirror;mirror.feature=BodyFeature::Pattern;mirror.name="Specchio da eliminare";mirror.firstBody=0;mirror.pattern.kind=2;GeometryRef plane;plane.kind=1;plane.index=2;mirror.pattern.refs={plane};require(fixture.createBody(mirror,{0}).isEmpty(),"specchio reale");
 SketchObject sketch;sketch.name="Schizzo collegato";GeometryRef vertex;vertex.kind=3;vertex.index=2;vertex.featureId=fixture.extrusions_[2].featureId;vertex.point=vertexReference(*fixture.extrusions_[2].forgeBody,fixture.extrusions_[2].forgeBody->vertices().front());require(appendLinkedSketchReference(sketch,vertex,{},fixture.extrusions_).isEmpty(),"schizzo collegato reale");fixture.sketches_.append(sketch);fixture.documentChanged();
 PdfWindow window;window.loadingDocument_=true;window.viewport_->loadDocument(fixture.currentDocument());window.loadingDocument_=false;window.rebuildModelTree();window.resize(1200,850);window.show();for(int i=0;i<4;++i)QApplication::processEvents();
 QTreeWidgetItem *row=nullptr;for(QTreeWidgetItemIterator it(window.modelTree_);*it;++it)if((*it)->data(0,Qt::UserRole).toInt()==kTreeExtrusion&&(*it)->data(0,Qt::UserRole+1).toInt()==1){row=*it;break;}require(row,"voce specchio nell'albero reale");for(auto *p=row->parent();p;p=p->parent())p->setExpanded(true);window.modelTree_->scrollToItem(row);QApplication::processEvents();auto p=QPointF(window.modelTree_->visualItemRect(row).center());
 QMouseEvent press(QEvent::MouseButtonPress,p,window.modelTree_->viewport()->mapToGlobal(p.toPoint()),Qt::LeftButton,Qt::LeftButton,Qt::NoModifier);QApplication::sendEvent(window.modelTree_->viewport(),&press);QMouseEvent release(QEvent::MouseButtonRelease,p,window.modelTree_->viewport()->mapToGlobal(p.toPoint()),Qt::LeftButton,Qt::NoButton,Qt::NoModifier);QApplication::sendEvent(window.modelTree_->viewport(),&release);
 require(window.viewport_->selection().kind==SceneObjectKind::Extrusion&&window.viewport_->selection().index==1,"clic storyboard sceglie funzione specchio");
 QAction *remove=nullptr;for(auto *action:window.findChildren<QAction*>())if(action->text()=="Elimina"&&action->shortcut()==QKeySequence::Delete){remove=action;break;}require(remove,"azione Elimina reale");remove->trigger();QApplication::processEvents();require(window.viewport_->extrusions_.size()==1&&window.viewport_->extrusions_[0].error.isEmpty(),"un solo Elimina reale rimuove specchio senza orfani");window.viewport_->undo();require(window.viewport_->extrusions_.size()==3,"Undo reale ripristina gruppo");window.viewport_->redo();require(window.viewport_->extrusions_.size()==1,"Redo reale elimina gruppo");window.documentModified_=false;
 std::cout<<"PASS real storyboard mirror deletion "<<qPrintable(QGuiApplication::platformName())<<std::endl;
}
};
int main(int argc,char **argv) {
 QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);
 QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADStoryboardQA");QCoreApplication::setApplicationName("Storyboard");
 QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());
 try {if(app.arguments().contains("--real-delete")){ViewportInteractionTest::realMirrorDelete();return 0;}if(app.arguments().contains("--real-panels")){ViewportInteractionTest::realLoftPanel();return 0;}if(app.arguments().contains("--mirror-only")){ViewportInteractionTest::mirrorDeleteOnce();return 0;}ViewportInteractionTest::storyboardPanelSelection();ViewportInteractionTest::loftFailureDiagnostics();ViewportInteractionTest::mirrorDeleteOnce();return 0;}
 catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
}
