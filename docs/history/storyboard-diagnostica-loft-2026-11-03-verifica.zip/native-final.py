from pathlib import Path
import os,subprocess,json,time
q=Path('/tmp/forgecad-storyboard-pick');rows=[]
for backend in ['wayland','xcb']:
 for label,args in [('selection',[]),('loft-panel',['--real-panels']),('mirror-delete',['--real-delete'])]:
  env=os.environ.copy();env.update(QT_QPA_PLATFORM=backend,QT_QPA_PLATFORMTHEME='',QT_STYLE_OVERRIDE='Fusion');env.pop('QT_QPA_OFFSCREEN_NO_GLX',None)
  t=time.monotonic();p=subprocess.run([str(q/'probe')]+args,env=env,capture_output=True,text=True,timeout=30);(q/f'native-{backend}-{label}.log').write_text(p.stdout+p.stderr);row={'backend':backend,'case':label,'exit':p.returncode,'seconds':round(time.monotonic()-t,2)};rows.append(row);print(row,flush=True)
  if p.returncode:print((p.stdout+p.stderr)[-2000:],flush=True)
(q/'native-results.json').write_text(json.dumps(rows,indent=2));raise SystemExit(any(r['exit'] for r in rows))
