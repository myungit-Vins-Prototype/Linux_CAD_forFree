from pathlib import Path
import subprocess,json,shlex
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-storyboard-pick');b=r/'forgecad-release'
row=next(x for x in json.loads((b/'compile_commands.json').read_text()) if 'CMakeFiles/forgecad.dir/forgeCad2026_viewport_document.cpp.o' in x['command']);a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/'document-before.o');a[-1]=str(o/'document-before.cpp');a=[x if x!='-O3' else '-O0' for x in a];subprocess.run(a,cwd=b,check=True)
