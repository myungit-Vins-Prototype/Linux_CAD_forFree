from pathlib import Path
import re, struct, subprocess, json, resource
root=Path('/tmp/forgecad-review-resume')
base=(root/'cube.step').read_text()
def inject(text, lines): return text.replace('\nENDSEC;\nEND-ISO-10303-21;', '\n'+lines+'\nENDSEC;\nEND-ISO-10303-21;')
cases=[]
def add(name,content,mode='read'):
    p=root/name
    p.write_bytes(content.encode() if isinstance(content,str) else content)
    cases.append((p,mode))
add('baseline.step',base)
for typed in [False,True]:
    for n in [100,100000]:
        add(f'{"typed" if typed else "lists"}-{n}.step', 'ISO-10303-21;\nDATA;\n#1=IGNORED('+('T(' if typed else '(')*n+'0'+')'*n+');\nENDSEC;\nEND-ISO-10303-21;\n')
add('truncated.body',b'FKBD'+struct.pack('=II',1,0x01020304)+bytes([3,7])+struct.pack('=iiIIii',1,1,0,0,10000,10000),'body')
m=re.search(r"(#\d+=EDGE_CURVE\('',#\d+,#\d+,)#\d+(,\.T\.\);)",base)
assert m
for mult in [2,100000000]:
    s=base[:m.start()]+m[1]+'#190'+m[2]+base[m.end():]
    add(f'knots-{mult}.step',inject(s,f"#190=B_SPLINE_CURVE_WITH_KNOTS('',1,(#10,#12),.UNSPECIFIED.,.F.,.F.,({mult},2),(0.,1.),.UNSPECIFIED.);"))
root_product="""#200=PRODUCT('assembly','assembly','',(#3));
#201=PRODUCT_DEFINITION_FORMATION('','',#200);
#202=PRODUCT_DEFINITION('design','',#201,#4);
#203=PRODUCT_DEFINITION_SHAPE('','',#202);
#204=SHAPE_REPRESENTATION('',(#146),#9);
#205=SHAPE_DEFINITION_REPRESENTATION(#203,#204);"""
for translation in ['0.','0.0000004','0.000002']:
    lines=root_product+'\n'
    for i,x in enumerate(['0.',translation]):
        j=210+i*10
        lines+=f"""#{j}=NEXT_ASSEMBLY_USAGE_OCCURRENCE('occ{i}','occ{i}','',#202,#153,$);
#{j+1}=PRODUCT_DEFINITION_SHAPE('','',#{j});
#{j+2}=CARTESIAN_POINT('',({x},0.,0.));
#{j+3}=AXIS2_PLACEMENT_3D('',#{j+2},#144,#145);
#{j+4}=ITEM_DEFINED_TRANSFORMATION('','',#146,#{j+3});
#{j+5}=(REPRESENTATION_RELATIONSHIP('','',#149,#204) REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION(#{j+4}) SHAPE_REPRESENTATION_RELATIONSHIP());
#{j+6}=CONTEXT_DEPENDENT_SHAPE_REPRESENTATION(#{j+5},#{j+1});
"""
    add(f'assembly-{translation}.step',inject(base,lines))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
results=[]
for p,mode in cases:
    r=subprocess.run([str(root/'kernel_probe'),mode,str(p)],capture_output=True,text=True,timeout=30)
    item={'file':p.name,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    results.append(item);print(json.dumps(item),flush=True)
(root/'kernel-results.json').write_text(json.dumps(results,indent=2)+'\n')
