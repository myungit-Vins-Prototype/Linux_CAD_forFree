#include "fk_step.h"
#include "fk_body_io.h"
#include "fk_primitives.h"
#include "fk_mass.h"
#include <cstdio>
#include <cstdlib>
#include <new>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <string>
static bool intercept = false;
void* operator new(std::size_t n) {
    if (intercept && n > 64000000) { std::fprintf(stderr,"blocked_allocation=%zu\n",n); throw std::bad_alloc(); }
    void* p=std::malloc(n ? n : 1); if(!p)throw std::bad_alloc(); return p;
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
int main(int argc, char** argv) {
    if(argc!=3)return 2;
    try {
        std::string mode=argv[1];
        if(mode=="write") {
            ForgeCad::Kernel::ExchangeBody b;
            b.name="cube"; b.body=ForgeCad::Kernel::makeBox(ForgeCad::Kernel::Frame3(),1,2,3);
            std::ofstream(argv[2])<<ForgeCad::Kernel::writeStep({b}); return 0;
        }
        std::ifstream file(argv[2],std::ios::binary);
        std::string content((std::istreambuf_iterator<char>(file)),std::istreambuf_iterator<char>());
        intercept=true;
        std::cout<<"input_bytes="<<content.size()<<std::endl;
        if(mode=="body") {auto b=ForgeCad::Kernel::readBodyBinary(content); std::cout<<"body_read\n";}
        else {
            auto r=ForgeCad::Kernel::readStep(content,{1});
            std::cout<<"bodies="<<r.bodies.size()<<" notes="<<r.notes.size()<<'\n';
            for(auto& b:r.bodies) {auto m=ForgeCad::Kernel::massProperties(b.body); std::cout<<std::setprecision(17)<<"volume="<<m.volume<<" centroid="<<m.centroid.x()<<','<<m.centroid.y()<<','<<m.centroid.z()<<'\n';}
            for(auto& note:r.notes)std::cout<<note<<'\n';
        }
        return 0;
    }catch(const std::exception& e) {std::cout<<"exception="<<e.what()<<'\n';return 3;}
}
