#include <QApplication>
#include <QStyleFactory>
#include <QStyle>
#include <iostream>
int main(int argc,char** argv){QApplication app(argc,argv);std::cerr<<"before-create"<<std::endl;auto* style=QStyleFactory::create("Breeze");std::cerr<<"after-create"<<std::endl;delete style;return 0;}
