#include "cad_revision_store.h"
#include <QCoreApplication>
#include <QTemporaryDir>
#include <atomic>
#include <thread>
#include <iostream>
int main(int argc,char** argv){
    QCoreApplication app(argc,argv);QTemporaryDir dir;
    ForgeCad::RevisionStore store(dir.path());auto e=store.initialize();if(!e.isEmpty())return 2;
    QUuid id;e=store.createDocument("probe","model",id);if(!e.isEmpty())return 3;
    std::atomic<bool> done{false};int writerErrors=0;
    std::thread writer([&]{for(int i=0;i<300;++i){ForgeCad::RevisionCheckout c;auto e=store.checkout(id,"writer",c);if(!e.isEmpty()){++writerErrors;continue;}if(!store.cancelCheckout(c).isEmpty())++writerErrors;}done=true;});
    int reads=0,errors=0;QString first;
    while(!done){QVector<ForgeCad::RevisionDocumentInfo> result;auto e=store.documents(result);++reads;if(!e.isEmpty()){++errors;if(first.isEmpty())first=e;}}
    writer.join();QVector<ForgeCad::RevisionDocumentInfo> result;auto final=store.documents(result);
    std::cout<<"reads="<<reads<<" read_errors="<<errors<<" writer_errors="<<writerErrors<<" final_error="<<final.toStdString()<<"\nfirst="<<first.toStdString()<<'\n';
    return writerErrors||!final.isEmpty()?1:0;
}
