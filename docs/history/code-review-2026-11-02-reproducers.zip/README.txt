Riproduttori della review ForgeCAD del 2 novembre 2026
Base: ab6fc71c8e639da620521a815b4b4101d2b7167b, Linux, GCC 16.2.1, Qt 6.12.0.
Nessun CAD originale incluso. fixtures.json conserva dimensioni e hash SHA256.
Le richieste di memoria superiori a 64 MB vengono bloccate dal kernel_probe
PRIMA di malloc. I crash del parser sono eseguiti in subprocessi, senza core dump.

Dalla radice di un checkout della base, compilare la build Release abituale.
Estrarre questo archivio in /tmp/forgecad-review-resume (reproduce.py usa quel percorso).

c++ -std=c++17 -O2 -g -I kernel /tmp/forgecad-review-resume/kernel_probe.cpp forgecad-release/kernel/libforgekernel.a -pthread -o /tmp/forgecad-review-resume/kernel_probe
/tmp/forgecad-review-resume/kernel_probe write /tmp/forgecad-review-resume/cube.step
python3 /tmp/forgecad-review-resume/reproduce.py

Per la race, con Qt6 e il runner revision_store gia' compilato:
c++ -std=c++17 -fPIC -O2 -g -I . $(pkg-config --cflags Qt6Core) /tmp/forgecad-review-resume/revision_probe.cpp forgecad-release/CMakeFiles/forgecad_revision_store_tests.dir/cad_revision_store.cpp.o $(pkg-config --libs Qt6Core) -pthread -o /tmp/forgecad-review-resume/revision_probe
/tmp/forgecad-review-resume/revision_probe
Il conteggio degli errori dipende dalla schedulazione.

Per ASan/UBSan sostituire il collegamento del primo comando con:
c++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I kernel /tmp/forgecad-review-resume/kernel_probe.cpp kernel/fk_step.cpp forgecad-release/kernel/libforgekernel.a -pthread -o /tmp/forgecad-review-resume/kernel_probe_asan
ASAN_OPTIONS=detect_leaks=0 /tmp/forgecad-review-resume/kernel_probe_asan read /tmp/forgecad-review-resume/lists-100000.step
ASAN_OPTIONS=detect_leaks=0 /tmp/forgecad-review-resume/kernel_probe_asan read /tmp/forgecad-review-resume/typed-100000.step
Solo fk_step.cpp e la sonda sono strumentati, il resto del kernel e' Release.

Per il fallimento numerico:
./forgecad-release/kernel/forgekernel_tests DraftCurvedAndConcaveSolids

summary.json e i log descrivono gli esiti di questa ripresa.
Non modificare tolleranze o test per ottenere artificiosamente un PASS.
