from pathlib import Path
import subprocess,shlex,json,sys
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-loft-guide-tolerance');b=r/'forgecad-release';name=sys.argv[1] if len(sys.argv)>1 else 'inspect'
row=next(a for a in json.loads((b/'compile_commands.json').read_text()) if 'CMakeFiles/forgecad.dir/forgeCad2026.cpp.o' in a['command']);a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/(name+'.o'));a[-1]=str(o/(name+'.cpp'));a=[x if x!='-O3' else '-O0' for x in a];a += ['-I'+str(r/'tests'),'-DFORGECAD_SOURCE_DIR="'+str(r)+'"'];subprocess.run(a,cwd=b,check=True)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/(name+'.o')) if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/name);a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/(name+'.d')) for x in a];subprocess.run(a,cwd=b,check=True)
