from pathlib import Path
r=Path('/home/myungit/Linux_CAD_forFree');q=Path('/tmp/forgecad-loft-guide-tolerance')
s=(r/'tests/test_viewport.cpp').read_text().split('#include "test_declared_history_cache.h"')[0]
s+='class ViewportInteractionTest { public:\n'+(q/'native.inc').read_text()+'\n};\n'
s+='''int main(int argc,char **argv){QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADSectionsNativeQA");QCoreApplication::setApplicationName("SectionsNative");QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());try{ViewportInteractionTest::nativeTolerance();return 0;}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}}'''
(q/'native.cpp').write_text(s)
