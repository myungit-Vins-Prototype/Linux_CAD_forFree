#include <set>
#include <QThread>
#include <QEventLoop>
#include <QCryptographicHash>
#include <condition_variable>
#if defined(__GLIBC__)
#include <malloc.h>
#endif
#include "../cad_gpu_broad_phase.h"
#include "../cad_cuda_tessellation.h"
#include "../cad_document_read.h"
#include "../cuda_support.h"
#include <QSaveFile>
// I componenti GUI sono dichiarati negli header e compilati separatamente.
#include "../forgeCad2026_gui.h"
#include "../forgeCad2026_viewport.h"
#include "../forgeCad2026_storyboard.h"
#include "../forgeCad2026_dialogs.h"
#include "../cad_expression.h"
#include "../cad_features.h"
#include "../cad_feature_build.h"
#include "../cad_feature_dependencies.h"
#include "../cad_datum.h"
#include "../cad_storyboard_selection.h"
#include "../cad_loft_diagnostics.h"
#include "../forgeCad2026_dialogs_common.h"
#include "fk_curve_ops.h"
#include "fk_bspline.h"
#include "../cad_forge.h"
#include "../cad_pattern.h"
#include "../cad_extrude.h"
#include "../cad_sketch_refs.h"
#include "../cad_sketch_reference_usage.h"
#include "../cad_history_graph.h"
#include "../cad_model_history.h"
#include "../cad_topology_ref.h"
#include "../cad_icons.h"
#include "../cad_menu.h"
#include "../cad_kernel.h"
#include "../cad_curve_extract.h"
#include "../cad_projected_curve.h"
#include "../cad_surface_tools.h"
#include "../cad_spatial_sketch.h"
#include "../kernel/tests/surface_tools_fixture.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLocale>
#include "../cad_measure.h"
#include "../toolbar_editor.h"
#include <QOpenGLContext>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>

using ForgeCad::Gui::uiFont;
using ForgeCad::Gui::pointLength;
using ForgeCad::Gui::pointDistance;
using ForgeCad::Gui::featureIconName;
using ForgeCad::Gui::kSelectionColor;
using ForgeCad::Gui::kHoverColor;
using ForgeCad::Gui::runUntilApplied;
using ForgeCad::Gui::wrappedNote;
#include "fk_blend.h"
#include "fk_blend_surface.h"
#include "fk_body_check.h"
#include "fk_boolean.h"
#include "fk_body_io.h"
#include "../cad_snapshot_chunks.h"
#include "fk_step.h"
#include "fk_iges.h"
#include "fk_classify.h"
#include "fk_extrude.h"
#include "fk_sew.h"
#include "fk_helix.h"
#include "fk_mass.h"
#include "fk_sketch_projection.h"
#include "fk_pcurve.h"
#include "fk_primitives.h"
#include "fk_revolve.h"
#include "fk_sheet.h"
#include "fk_surface_algo.h"
#include "fk_tessellate.h"
#include "fk_loft.h"
#include "fk_project.h"
#include "fk_parallel.h"
#include <QGraphicsItem>
#include <QGraphicsView>
#include <QSurfaceFormat>
#include <QTemporaryDir>
#include "../cad_element_names.h"
#include <QProcess>
#include <QDateTime>
#include <QPointingDevice>
#include <QSemaphore>
#include <QCryptographicHash>
#include <QtEndian>
#include <fstream>
#include <cstring>
#include <iostream>
#include <stdexcept>

static void require(bool ok, const char *message) {
    if (!ok) throw std::runtime_error(message);
}

static QByteArray testDocumentUncompress(const QByteArray &document, qsizetype offset, qsizetype size = -1) {
    QByteArray result;
    require(document.size() >= 11 && ForgeCad::DocumentReadDetail::uncompress(document.mid(offset, size),
        qsizetype(1024)*1024*1024, result, quint8(document.at(6))), "decompressione blocco fixture nativa");
    return result;
}
static QByteArray testDocumentCompress(const QByteArray &data, const QByteArray &document) {
    return ForgeCad::DocumentReadDetail::compress(data, quint8(document.at(6)), 9);
}

// Configurabile anche nei lanci diretti del runner; CTest passa la cartella da CMake.
static QString exampleDocumentPath(const char *name) {
    const QString directory = qEnvironmentVariable("FORGECAD_EXAMPLE_DIR", QStringLiteral(FORGECAD_SOURCE_DIR "/File_Esempio"));
    return QDir(directory).filePath(QString::fromUtf8(name));
}

class ViewportInteractionTest { public:
static void nativeTolerance() {
    using namespace ForgeCad;using namespace Kernel;
    DocumentState original;require(loadDocumentFile("/tmp/forgecad-loft-guide-tolerance/SurfaceModellingExample219.prt",original).isEmpty(),"lettura copia CAD");
    for(int continuity:{0,1}) {
        PdfWindow window;window.loadingDocument_=true;window.viewport_->loadDocument(original);window.loadingDocument_=false;window.rebuildModelTree();
        auto *view=window.viewport_;for(auto *dock:window.findChildren<QDockWidget*>())if(!dock->isAncestorOf(window.modelTree_))dock->hide();window.resize(1500,1000);window.show();for(int i=0;i<5;++i)QApplication::processEvents();view->fitAll();
        const auto baseline=view->currentDocument();
        ExtrusionObject definition;definition.feature=BodyFeature::Loft;definition.loftSurface=true;definition.name="Loft tolleranza guide";
        definition.loftSketches={6,8,7};definition.loftGuides={9,10};definition.loftStartContinuity=definition.loftEndContinuity=continuity;
        const auto verify=[&](CadViewport &target){const auto state=target.currentDocument();const auto &loft=state.extrusions.last();require(loft.feature==BodyFeature::Loft&&loft.error.isEmpty()&&loft.forgeBody&&checkBody(*loft.forgeBody).empty(),"loft reale valida");double maximum=0,guideError=0;
            for(int i:{6,8,7})for(const auto &piece:forgeSketchSegments(state.sketches[i]))for(int j=0;j<=31;++j){const auto local=piece.curve->point(piece.range.lo+piece.range.length()*j/31.);const auto p=sketchToWorld(QPointF(local.x(),local.y()),state.sketches[i]);double best=1e100;for(auto face:loft.forgeBody->faces())best=std::min(best,projectPoint(*loft.forgeBody->face(face).surface,p).distance);maximum=std::max(maximum,best);}
            for(int i:{9,10}){GeometryRef ref;ref.kind=7;ref.index=i;std::vector<PathSegment> path;QString error;require(geometryRefPath(ref,state.extrusions.size()-1,state.sketches,state.extrusions,path,&error),"guida risolta");for(const auto &piece:path)for(int j=0;j<=71;++j){const auto p=piece.curve->point(piece.range.lo+piece.range.length()*j/71.);double best=1e100;for(auto face:loft.forgeBody->faces()){const auto &surface=*loft.forgeBody->face(face).surface;for(double u:{surface.uDomain().lo,surface.uDomain().hi}){const auto edge=surface.uIso(u);best=std::min(best,projectPoint(*edge,p,edge->domain()).distance);}}guideError=std::max(guideError,best);}}
            require(maximum<4e-9,"fedelta sezioni CAD reale");require(guideError<2.28e-7,"guide entro residuo di connessione piu fit");std::cout<<"continuity="<<continuity<<" sectionError="<<maximum<<" guideError="<<guideError<<" faces="<<loft.forgeBody->faces().size()<<std::endl;
        };
        QTimer timer;timer.setInterval(50);QElapsedTimer elapsed;elapsed.start();std::exception_ptr failure;bool confirmed=false;
        QObject::connect(&timer,&QTimer::timeout,&window,[&]{auto *dialog=window.findChild<QDialog*>("loftDialog");if(!dialog||!dialog->isVisible())return;try{
            require(elapsed.elapsed()<60000,"timeout preview nativa");if(view->previewPending())return;
            require(view->previewError().isEmpty(),qPrintable(view->previewError()));if(!view->preview_.valid)return;
            require(view->isValid(),"contesto OpenGL valido");
            window.grab().save(QStringLiteral("/tmp/forgecad-loft-guide-tolerance/panel-G%1-%2.png").arg(continuity).arg(QGuiApplication::platformName()));
            view->grabFramebuffer().save(QStringLiteral("/tmp/forgecad-loft-guide-tolerance/preview-G%1-%2.png").arg(continuity).arg(QGuiApplication::platformName()));
            timer.stop();dialog->findChild<QDialogButtonBox*>()->button(QDialogButtonBox::Ok)->click();confirmed=true;
        }catch(...){failure=std::current_exception();timer.stop();dialog->reject();}});timer.start();
        const bool accepted=loftDialog(&window,view,"Loft tolleranza guide",-1,definition,[&](const ExtrusionObject &d){return view->createBody(d);});timer.stop();if(failure)std::rethrow_exception(failure);
        require(accepted&&confirmed&&view->extrusions_.size()==baseline.extrusions.size()+1,"conferma pannello crea corpo");verify(*view);for(int i=0;i<4;++i)QApplication::processEvents();view->grabFramebuffer().save(QStringLiteral("/tmp/forgecad-loft-guide-tolerance/result-G%1-%2.png").arg(continuity).arg(QGuiApplication::platformName()));
        for(int i:{6,8,7,9,10}){const auto &before=baseline.sketches[i],&after=view->sketches_[i];const auto a=forgeSketchSegments(before),b=forgeSketchSegments(after);require(a.size()==b.size(),"profili sorgenti invariati");for(std::size_t k=0;k<a.size();++k)for(double f:{0.,.3,.7,1.})require(distance(a[k].curve->point(a[k].range.lo+f*a[k].range.length()),b[k].curve->point(b[k].range.lo+f*b[k].range.length()))==0,"geometria sorgente immutata");}
        view->undo();require(view->extrusions_.size()==baseline.extrusions.size(),"Undo reale");view->redo();verify(*view);
        for(bool cache:{false,true}){const QString path=QStringLiteral("/tmp/forgecad-loft-guide-tolerance/replay-G%1-%2-%3.prt").arg(continuity).arg(cache).arg(QGuiApplication::platformName());require(saveDocumentFile(path,view->currentDocument(),cache).isEmpty(),"salvataggio copia reale");DocumentState read;require(loadDocumentFile(path,read).isEmpty(),"riapertura copia reale");CadViewport restored;restored.loadDocument(read);verify(restored);require(restored.rebuildAllFeatures()==0,"ricostruzione completa CAD reale");verify(restored);}
        window.documentModified_=false;std::cout<<"PASS native G"<<continuity<<" "<<qPrintable(QGuiApplication::platformName())<<" preview/conferma/Undo/Redo/cache/rigenerazione/sorgenti\n";
    }
}

};
int main(int argc,char **argv){QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADSectionsNativeQA");QCoreApplication::setApplicationName("SectionsNative");QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());try{ViewportInteractionTest::nativeTolerance();return 0;}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}}