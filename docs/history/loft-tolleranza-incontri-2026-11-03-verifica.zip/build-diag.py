from pathlib import Path
import json,shlex,subprocess
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-loft-guide-tolerance');b=r/'forgecad-release';db=json.loads((b/'compile_commands.json').read_text())
for name in ['fk_loft','fk_hermite']:
 row=next(x for x in db if x['file'].endswith('/kernel/'+name+'.cpp'));a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/(name+'.o'));a[-1]=str(o/(name+'.cpp'));a=[x if x!='-O3' else '-O0' for x in a];a+=['-g','-I'+str(r/'kernel')];subprocess.run(a,cwd=row['directory'],check=True)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/'inspect.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/'diagnostic');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/'diagnostic.d') for x in a];idx=a.index('kernel/libforgekernel.a');a[idx:idx]=[str(o/'fk_loft.o'),str(o/'fk_hermite.o')];subprocess.run(a,cwd=b,check=True)
