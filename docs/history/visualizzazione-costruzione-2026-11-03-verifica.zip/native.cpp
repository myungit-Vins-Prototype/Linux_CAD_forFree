#include "forgeCad2026_application_theme.h"
#include <set>
#include <QThread>
#include <QEventLoop>
#include <QCryptographicHash>
#include <condition_variable>
#if defined(__GLIBC__)
#include <malloc.h>
#endif
#include "../cad_gpu_broad_phase.h"
#include "../cad_cuda_tessellation.h"
#include "../cad_document_read.h"
#include "../cuda_support.h"
#include <QSaveFile>
// I componenti GUI sono dichiarati negli header e compilati separatamente.
#include "../forgeCad2026_gui.h"
#include "../forgeCad2026_viewport.h"
#include "../forgeCad2026_storyboard.h"
#include "../forgeCad2026_dialogs.h"
#include "../cad_expression.h"
#include "../cad_features.h"
#include "../cad_feature_build.h"
#include "../cad_feature_dependencies.h"
#include "../cad_datum.h"
#include "../cad_storyboard_selection.h"
#include "../cad_loft_diagnostics.h"
#include "../forgeCad2026_dialogs_common.h"
#include "fk_curve_ops.h"
#include "fk_bspline.h"
#include "../cad_forge.h"
#include "../cad_pattern.h"
#include "../cad_extrude.h"
#include "../cad_sketch_refs.h"
#include "../cad_sketch_reference_usage.h"
#include "../cad_history_graph.h"
#include "../cad_model_history.h"
#include "../cad_topology_ref.h"
#include "../cad_icons.h"
#include "../cad_menu.h"
#include "../cad_kernel.h"
#include "../cad_curve_extract.h"
#include "../cad_projected_curve.h"
#include "../cad_surface_tools.h"
#include "../cad_spatial_sketch.h"
#include "../kernel/tests/surface_tools_fixture.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLocale>
#include "../cad_measure.h"
#include "../toolbar_editor.h"
#include <QOpenGLContext>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>

using ForgeCad::Gui::uiFont;
using ForgeCad::Gui::pointLength;
using ForgeCad::Gui::pointDistance;
using ForgeCad::Gui::featureIconName;
using ForgeCad::Gui::kSelectionColor;
using ForgeCad::Gui::kHoverColor;
using ForgeCad::Gui::runUntilApplied;
using ForgeCad::Gui::wrappedNote;
#include "fk_blend.h"
#include "fk_blend_surface.h"
#include "fk_body_check.h"
#include "fk_boolean.h"
#include "fk_body_io.h"
#include "../cad_snapshot_chunks.h"
#include "fk_step.h"
#include "fk_iges.h"
#include "fk_classify.h"
#include "fk_extrude.h"
#include "fk_sew.h"
#include "fk_helix.h"
#include "fk_mass.h"
#include "fk_sketch_projection.h"
#include "fk_pcurve.h"
#include "fk_primitives.h"
#include "fk_revolve.h"
#include "fk_sheet.h"
#include "fk_surface_algo.h"
#include "fk_tessellate.h"
#include "fk_loft.h"
#include "fk_project.h"
#include "fk_parallel.h"
#include <QGraphicsItem>
#include <QGraphicsView>
#include <QSurfaceFormat>
#include <QTemporaryDir>
#include "../cad_element_names.h"
#include <QProcess>
#include <QDateTime>
#include <QPointingDevice>
#include <QSemaphore>
#include <QCryptographicHash>
#include <QtEndian>
#include <fstream>
#include <cstring>
#include <iostream>
#include <stdexcept>

static void require(bool ok, const char *message) {
    if (!ok) throw std::runtime_error(message);
}

static QByteArray testDocumentUncompress(const QByteArray &document, qsizetype offset, qsizetype size = -1) {
    QByteArray result;
    require(document.size() >= 11 && ForgeCad::DocumentReadDetail::uncompress(document.mid(offset, size),
        qsizetype(1024)*1024*1024, result, quint8(document.at(6))), "decompressione blocco fixture nativa");
    return result;
}
static QByteArray testDocumentCompress(const QByteArray &data, const QByteArray &document) {
    return ForgeCad::DocumentReadDetail::compress(data, quint8(document.at(6)), 9);
}

// Configurabile anche nei lanci diretti del runner; CTest passa la cartella da CMake.
static QString exampleDocumentPath(const char *name) {
    const QString directory = qEnvironmentVariable("FORGECAD_EXAMPLE_DIR", QStringLiteral(FORGECAD_SOURCE_DIR "/File_Esempio"));
    return QDir(directory).filePath(QString::fromUtf8(name));
}

class ViewportInteractionTest { public:
#include "test_sketch_construction.h"
static void nativeMenu() {
    PdfWindow window;auto *view=window.viewport_;DocumentState doc;SketchObject sketch;sketch.storyId=1;sketch.name="Costruzione su richiesta";
    sketch.segments={{{-8,-4},{8,-4}},{{-8,6},{8,6}}};sketch.constructionSegments={1};CurveObject circle;circle.tool=DrawingTool::Circle;circle.controlPoints={{0,12},{3,12}};circle.construction=true;ForgeCad::recalculateCurve(circle);sketch.curves={circle};doc.sketches={sketch};
    window.loadingDocument_=true;view->loadDocument(doc);window.loadingDocument_=false;window.rebuildModelTree();window.resize(1200,900);window.show();window.raise();window.activateWindow();
    for(int i=0;i<30;++i){QApplication::processEvents();QThread::msleep(10);}view->setGridVisible(false);view->setAxesVisible(false);for(int i=0;i<3;++i)view->setPlaneVisible(i,false);view->setViewFrame({1,0,0},{0,0,1});view->fitAll();
    auto *action=window.findChild<QAction*>("sketchConstructionVisibilityAction");require(action&&!action->isChecked(),"menu nativo inizialmente spento");action->trigger();
    auto *menu=qobject_cast<QMenu*>(action->parent());require(menu,"comando appartenente al menu Visualizza");menu->popup(window.mapToGlobal(QPoint(130,60)));for(int i=0;i<10;++i){QApplication::processEvents();QThread::msleep(10);}if(!menu->isVisible()){window.activateWindow();menu->show();for(int i=0;i<20;++i){QApplication::processEvents();QThread::msleep(10);}}std::cout<<"menu visible="<<menu->isVisible()<<" activeWindow="<<window.isActiveWindow()<<std::endl;if(!menu->isVisible()){require(QGuiApplication::platformName()=="wayland","menu nativo aperto XCB");std::cout<<"SKIP popup Wayland: apertura automatizzata non riuscita; verificati comando e widget del menu"<<std::endl;menu->resize(menu->sizeHint());}
    const auto suffix=QGuiApplication::platformName();menu->grab().save("/tmp/forgecad-construction-option/menu-"+suffix+".png");menu->hide();QApplication::processEvents();view->grabFramebuffer().save("/tmp/forgecad-construction-option/window-shown-"+suffix+".png");
    QSettings().sync();
    for(const QString &mode:QStringList{"--persist-on","--persist-off"}){QProcess next;next.start(QCoreApplication::applicationFilePath(),{mode});require(next.waitForStarted(5000)&&next.waitForFinished(30000),"avvio seconda sessione");const auto output=next.readAllStandardOutput()+next.readAllStandardError();std::cout<<output.constData();require(next.exitStatus()==QProcess::NormalExit&&next.exitCode()==0,"preferenza ripristinata in un processo indipendente");}
    window.documentModified_=false;std::cout<<"PASS menu nativo e persistenza tra processi "<<qPrintable(suffix)<<std::endl;
}

};
int main(int argc,char **argv) {
 QSurfaceFormat f;f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);
 QApplication app(argc,argv);ForgeCad::initializeApplicationTheme(app);QCoreApplication::setOrganizationName("ForgeCADConstructionQA");QCoreApplication::setApplicationName("Construction");
 QTemporaryDir settings;const QString path=qEnvironmentVariable("FORGECAD_OPTION_QA_SETTINGS",settings.path());qputenv("FORGECAD_OPTION_QA_SETTINGS",path.toUtf8());QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,path);qputenv("FORGECAD_RECOVERY_DIR",(path+"/recovery-"+QString::number(QCoreApplication::applicationPid())).toUtf8());
 try {
   if(app.arguments().contains("--persist-on")||app.arguments().contains("--persist-off")){const bool expected=app.arguments().contains("--persist-on");PdfWindow window;auto *action=window.findChild<QAction*>("sketchConstructionVisibilityAction");require(action&&action->isChecked()==expected,"preferenza checkbox in processo nuovo");auto *view=dynamic_cast<CadViewport*>(window.centralWidget());if(!view){for(auto *widget:window.findChildren<QWidget*>())if(auto *v=dynamic_cast<CadViewport*>(widget))view=v;}require(view&&view->sketchConstructionVisible()==expected,"preferenza viewport in processo nuovo");if(expected)action->trigger();QSettings().sync();std::cout<<"PASS processo nuovo stato="<<expected<<std::endl;return 0;}
   ViewportInteractionTest::sketchConstructionVisibility(app.arguments().contains("--gl"));if(app.arguments().contains("--gl"))ViewportInteractionTest::nativeMenu();return 0;
 }catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}
}
