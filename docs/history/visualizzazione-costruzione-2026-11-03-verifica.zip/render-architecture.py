from pathlib import Path
import subprocess,os
r=Path('/home/myungit/Linux_CAD_forFree');q=Path('/tmp/forgecad-construction-option');env=os.environ.copy();env['XDG_CACHE_HOME']=str(q/'firefox-cache')
for label,node in [('construction-scene','forgeCad2026_viewport_scene.cpp'),('construction-menu','forgeCad2026_gui.cpp')]:
 profile=q/('firefox-'+label);profile.mkdir(exist_ok=True);url=(r/'docs/architecture/index.html').as_uri()+'#file='+node.replace('/','%2F');a=['firefox','--headless','--offline','--no-remote','--profile',str(profile),'--window-size','1600,1000','--screenshot',str(q/('architecture-'+label+'.png')),url];p=subprocess.run(a,env=env,capture_output=True,text=True,timeout=45);print(label,'exit',p.returncode,flush=True);print(p.stdout+p.stderr,flush=True);assert p.returncode==0
