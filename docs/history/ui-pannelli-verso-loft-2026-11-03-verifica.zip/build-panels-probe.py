from pathlib import Path
import subprocess,shlex,json
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-ui-panel-fix');b=r/'forgecad-release'
commands=json.loads((b/'compile_commands.json').read_text());row=next(a for a in commands if 'CMakeFiles/forgecad.dir/forgeCad2026.cpp.o' in a['command'])
a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/'panels-probe.o');a[-1]=str(o/'panels-probe.cpp');a=[x if x!='-O3' else '-O0' for x in a];subprocess.run(a,cwd=row['directory'],check=True)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/'panels-probe.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/'panels-probe');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/'panels-probe.d') for x in a];subprocess.run(a,cwd=b,check=True)
