from pathlib import Path
import subprocess,shlex,json
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-ui-panel-fix');b=r/'forgecad-release'
commands=json.loads((b/'compile_commands.json').read_text());row=next(a for a in commands if 'CMakeFiles/forgecad.dir/forgeCad2026.cpp.o' in a['command'])
a=shlex.split(row['command']);a[a.index('-o')+1]=str(o/'ribbon-main.o');a[-1]=str(r/'forgeCad2026_ribbon_preview_main.cpp');subprocess.run(a,cwd=row['directory'],check=True)
row=next(a for a in commands if 'CMakeFiles/forgecad.dir/forgeCad2026_ribbon_preview.cpp.o' in a['command']);args=shlex.split(row['command']);args[args.index('-o')+1]=str(o/'ribbon.o');subprocess.run(args,cwd=row['directory'],check=True)
a=shlex.split((b/'CMakeFiles/forgecad.dir/link.txt').read_text());a=[str(o/'ribbon.o') if x.endswith('/forgeCad2026_ribbon_preview.cpp.o') else x for x in a];a=[str(o/'ribbon-main.o') if x.endswith('/forgeCad2026.cpp.o') else x for x in a];a[a.index('-o')+1]=str(o/'ribbon-ui-tests');a=[x if not x.startswith('-Wl,--dependency-file=') else '-Wl,--dependency-file='+str(o/'ribbon-ui-tests.d') for x in a]
(o/'ribbon-link.json').write_text(json.dumps(a,indent=2));subprocess.run(a,cwd=b,check=True);print('Runner aggiornato: bootstrap isolato e oggetti di produzione della app completa')
