from pathlib import Path
import os,subprocess,time,json
q=Path('/tmp/forgecad-ui-panel-fix');results=[]
for backend in ['wayland','xcb']:
 folder=q/backend;folder.mkdir(exist_ok=True);env=os.environ.copy();env.update(FORGECAD_PANEL_UI_ONLY='1',QT_QPA_PLATFORM=backend,QT_QPA_PLATFORMTHEME='',QT_STYLE_OVERRIDE='Fusion',FORGECAD_UI_PANEL_CAPTURE=str(folder/'ribbon-full-height.png'));env.pop('QT_QPA_OFFSCREEN_NO_GLX',None)
 start=time.monotonic();p=subprocess.run([str(q/'ribbon-ui-tests'),'--self-test'],env=env,capture_output=True,text=True,timeout=150);(folder/'ribbon.log').write_text(p.stdout+p.stderr);row={'backend':backend,'exit':p.returncode,'seconds':round(time.monotonic()-start,2)};results.append(row);print(row,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-3000:],flush=True)
(q/'native-ribbon-results.json').write_text(json.dumps(results,indent=2))
raise SystemExit(any(r['exit'] for r in results))
