from pathlib import Path
import json
r=Path('/home/myungit/Linux_CAD_forFree');o=Path('/tmp/forgecad-ui-panel-fix');g=json.loads((r/'docs/architecture/graph.json').read_text());assert not g['analysis']['errors']
checks=[('forgeCad2026_ribbon_preview.cpp','forgeCad2026_dialogs_common.cpp','setViewportTopInset'),('forgeCad2026_dialogs_sketch.cpp','forgeCad2026_viewport_selection.cpp','cancelReferencePick'),('cad_drawing_file.cpp','cad_document_io.cpp','encodeDocumentDefinition60ForHash'),('cad_feature_build.cpp','cad_forge.cpp','forgeRuledSurface'),('cad_forge.cpp','kernel/fk_loft.cpp','loftSheet'),('tests/test_function_panels.h','forgeCad2026_dialogs_sketch.cpp','datumDialog'),('tests/test_function_panels.h','forgeCad2026_dialogs_surfaces.cpp','loftDialog'),('tests/test_function_panels.h','cad_drawing_file.cpp','drawingModelDefinitionMatches')]
result={'files':len(g['nodes']),'relations':len(g['edges']),'units':len(g['analysis']['units']),'errors':g['analysis']['errors'],'boundaries':[],'directions':{}}
for source,target,symbol in checks:
 sites=[s for e in g['edges'] if e['source']==source and e['target']==target and e['kind']=='call' for s in e['sites'] if symbol in s['symbol']];assert sites,(source,target,symbol)
 result['boundaries'].append({'source':source,'target':target,'kind':'call','symbol':symbol,'sites':sites})
for name in ['forgeCad2026_dialogs_common.cpp','forgeCad2026_dialogs_common.h','forgeCad2026_dialogs_sketch.cpp','forgeCad2026_ribbon_preview.cpp','cad_types.h','cad_forge.cpp','cad_forge.h','cad_feature_build.cpp','cad_document_io.cpp','cad_document_io.h','cad_drawing_file.cpp','forgeCad2026_feature_preview.cpp','kernel/fk_loft.h','kernel/fk_loft.cpp','kernel/tests/test_loft_shape.cpp','tests/test_function_panels.h']:
 assert any(x['id']==name for x in g['nodes']),name
 result['directions'][name]={kind:{'in':sum(e['count'] for e in g['edges'] if e['target']==name and e['kind']==kind),'out':sum(e['count'] for e in g['edges'] if e['source']==name and e['kind']==kind)} for kind in ['call','include','reference']}
(o/'architecture-checked.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',result['files'],'files',result['relations'],'relations',result['units'],'AST units',len(checks),'boundaries; incoming/outgoing call/include/reference checked')
