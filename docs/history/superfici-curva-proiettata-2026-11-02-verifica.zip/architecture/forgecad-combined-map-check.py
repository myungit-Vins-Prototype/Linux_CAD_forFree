from pathlib import Path
import json
repo=Path('/home/myungit/Linux_CAD_forFree')
graph=json.loads((repo/'docs/architecture/graph.json').read_text())
assert not graph['analysis']['errors']
checks=[('cad_extrude.cpp','kernel/fk_face_normal_bounds.cpp','faceHasNonnegativeNormalProjection'),('cad_projected_curve.cpp','kernel/fk_sketch_projection.cpp','projectSketchOnSketch'),('cad_feature_build.cpp','cad_projected_curve.cpp','forgeSketchProjectedCurves'),('forgeCad2026_gui.cpp','forgeCad2026_dialogs_projection.cpp','projectionDialog'),('kernel/fk_step.cpp','kernel/fk_sketch_projection.cpp','isImplicitSketchProjection'),('kernel/fk_iges.cpp','kernel/fk_sketch_projection.cpp','isImplicitSketchProjection')]
result={'files':len(graph['nodes']),'edges':len(graph['edges']),'units':len(graph['analysis']['units']),'errors':graph['analysis']['errors'],'calls_checked':[],'both_directions':{}}
for source,target,symbol in checks:
 sites=[s for e in graph['edges'] if e['source']==source and e['target']==target and e['kind']=='call' for s in e['sites'] if symbol in s['symbol']]
 assert sites,(source,target,symbol)
 result['calls_checked'].append({'source':source,'target':target,'kind':'call','symbol':symbol,'lines':[s['line'] for s in sites]})
for name in ['cad_extrude.cpp','kernel/fk_face_normal_bounds.cpp','cad_projected_curve.cpp','kernel/fk_sketch_projection.cpp','forgeCad2026_dialogs_projection.cpp','cad_feature_dependencies.cpp','cad_history_graph.cpp']:
 assert name in [n['id'] for n in graph['nodes']]
 result['both_directions'][name]={kind:{'incoming':sum(e['count'] for e in graph['edges'] if e['target']==name and e['kind']==kind),'outgoing':sum(e['count'] for e in graph['edges'] if e['source']==name and e['kind']==kind)} for kind in ['call','include','reference']}
Path('/tmp/forgecad-combined-architecture-check.json').write_text(json.dumps(result,indent=2)+'\n')
print('Architecture PASS:',result['files'],'files,',result['edges'],'edges,',result['units'],'units;',len(checks),'call boundaries verified; incoming/outgoing call/include/reference recorded separately')
