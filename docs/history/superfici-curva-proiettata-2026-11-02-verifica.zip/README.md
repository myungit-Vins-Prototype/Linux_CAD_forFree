# Evidenze del 2 novembre 2026

Build comune finale, CTest singolo di 156 test, QA nativa estrusione/proiezione e mappa.
App/runner/hash finali sono in build. I rapporti delle sonde distinguono checkpoint intermedi e QA finale: prevalgono le sezioni «build comune» e i relativi log.
I primi errori della sonda proiezione dipendevano da camera/layout/pannello, non da un difetto prodotto.
Le immagini provengono dalle sessioni effettive Wayland/XCB; i test offscreen non attestano GL.
Le sonde in projection-agent sono prove isolate con TU sostituite; la build completa effettiva è quella di build/ e CTest.
Sanitizer mirati solo a modulo/test proiezione, leak disabilitati per ptrace.
Le copie CAD di prova e gli eseguibili sono esclusi; fixtures.json conserva origine e hash. Gli script richiedono una build configurata e le copie indicate.
Le fonti prodotto sono versionate nel commit; source-manifest registra lo snapshot verificato prima della pubblicazione.
