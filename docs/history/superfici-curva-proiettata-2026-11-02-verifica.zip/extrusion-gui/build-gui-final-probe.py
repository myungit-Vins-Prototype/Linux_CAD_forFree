from pathlib import Path
import json,shlex,subprocess,sys
root=Path('/home/myungit/Linux_CAD_forFree');build=root/'forgecad-release';out=Path('/tmp/forgecad-superfici-fix');fixed='--fixed' in sys.argv;name='gui-final-probe-fixed' if fixed else 'gui-final-probe-common'
command=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/tests/test_viewport.cpp'))
args=shlex.split(command['command']);args[args.index('-o')+1]=str(out/(name+'.o'));args[-1]=str(out/'gui-final-probe.cpp');args=['-O0' if a=='-O3' else a for a in args];subprocess.run(args,cwd=build,check=True)
args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());args[args.index('-o')+1]=str(out/name)
for i,a in enumerate(args):
 if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':args[i]=str(out/(name+'.o'))
 elif a.startswith('-Wl,--dependency-file='):args[i]='-Wl,--dependency-file='+str(out/(name+'.d'))
 elif fixed:
  for source in ['cad_extrude.cpp','cad_document_io.cpp','cad_datum.cpp']:
   if a=='CMakeFiles/forgecad_view_tests.dir/'+source+'.o':args[i]=str(out/(source+'.fixed.o'))
if fixed:args.insert(args.index('kernel/libforgekernel.a'),str(out/'normal-fixed.o'))
subprocess.run(args,cwd=build,check=True)
