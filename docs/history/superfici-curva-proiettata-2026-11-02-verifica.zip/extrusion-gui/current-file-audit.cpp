#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "fk_mass.h"
#include "fk_body_io.h"
#include "fk_curve_ops.h"
#include "fk_nurbs.h"
#include <iostream>
int main(int argc,char **argv) {
 QApplication app(argc,argv);using namespace ForgeCad;using namespace Kernel;
 DocumentState a,b;auto check=[](bool ok,const char *msg){if(!ok)throw std::runtime_error(msg);};
 try {
 check(loadDocumentFile(QString::fromLocal8Bit(argv[1]),a).isEmpty(),"decode frozen");check(loadDocumentFile(QString::fromLocal8Bit(argv[2]),b).isEmpty(),"decode current");
 std::cout<<"feature counts frozen="<<a.extrusions.size()<<" current="<<b.extrusions.size()<<std::endl;
 check(a.extrusions.size()==17&&b.extrusions.size()==18,"unexpected feature counts");
 int same=0;for(int i=0;i<17;++i){check(bool(a.extrusions[i].forgeBody)==bool(b.extrusions[i].forgeBody),"cache availability differs");if(a.extrusions[i].forgeBody){check(writeBodyBinary(*a.extrusions[i].forgeBody)==writeBodyBinary(*b.extrusions[i].forgeBody),"previous B-rep cache changed");++same;}}
 double maximumProfileDifference=0.0;const auto first=forgeSketchSegments(a.sketches[2]),second=forgeSketchSegments(b.sketches[2]);check(first.size()==second.size(),"profile piece count changed");
 for(std::size_t i=0;i<first.size();++i){const auto one=rationalBezierPieces(*embedCurve(first[i].curve,sketchAxes(a.sketches[2])),first[i].range),two=rationalBezierPieces(*embedCurve(second[i].curve,sketchAxes(b.sketches[2])),second[i].range);check(one.size()==two.size(),"profile Bezier count changed");for(std::size_t j=0;j<one.size();++j){check(one[j].degree()==two[j].degree()&&one[j].knots()==two[j].knots()&&one[j].weights()==two[j].weights()&&one[j].poleCount()==two[j].poleCount(),"profile rational definition changed");for(int k=0;k<one[j].poleCount();++k)for(int d=0;d<3;++d)maximumProfileDifference=std::max(maximumProfileDifference,std::fabs(one[j].poles()[k][d]-two[j].poles()[k][d]));}}

 auto f=b.extrusions[17];check(f.feature==BodyFeature::Extrusion&&f.sketchIndex==2&&f.extent==4&&f.distance<0&&f.error.isEmpty()&&f.forgeBody,"unexpected new feature");
 const double cached=massProperties(*f.forgeBody).volume;buildGeometry(f,17,b.sketches,b.extrusions);check(f.error.isEmpty()&&f.forgeBody,"regenerate new feature failed");const double fresh=massProperties(*f.forgeBody).volume;check(std::fabs(fresh-cached)<1e-9,"new feature volume differs after regeneration");
 std::cout.precision(14);std::cout<<"PASS previous B-rep caches byte-identical="<<same<<" Schizzo 3 maximum rational profile pole difference="<<maximumProfileDifference<<"; new feature="<<f.name.toStdString()<<" extent=4 Invertito, cached volume="<<cached<<" regenerated volume="<<fresh<<" faces="<<f.forgeBody->faces().size()<<std::endl;
 }catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;
}
