from pathlib import Path
import json,shlex,subprocess
repo=Path('/home/myungit/Linux_CAD_forFree');build=repo/'forgecad-release';out=Path('/tmp/forgecad-superfici-fix');name='current-file-audit'
command=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/tests/test_viewport.cpp'))
args=shlex.split(command['command']);args[args.index('-o')+1]=str(out/(name+'.o'));args[-1]=str(out/(name+'.cpp'));args=['-O0' if a=='-O3' else a for a in args];subprocess.run(args,cwd=build,check=True)
args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text());args[args.index('-o')+1]=str(out/name)
for i,a in enumerate(args):
 if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o':args[i]=str(out/(name+'.o'))
 elif a.startswith('-Wl,--dependency-file='):args[i]='-Wl,--dependency-file='+str(out/(name+'.d'))
subprocess.run(args,cwd=build,check=True)
