#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_dialogs.h"
#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_application_theme.h"
#include "fk_mass.h"
#include "fk_body_io.h"
#include <QTemporaryDir>
#include <iostream>
#include <stdexcept>
#include <iomanip>
static void require(bool value,const QString &message){if(!value)throw std::runtime_error(message.toStdString());}
class ViewportInteractionTest { public:
static void run(const QString &path,bool gl){
 using namespace ForgeCad;using namespace Kernel;
 DocumentState source;require(loadDocumentFile(path,source).isEmpty(),"lettura della copia congelata");
 require(source.extrusions.size()==17&&source.sketches.size()==3,"fixture recente con17feature e3schizzi");
 require(source.extrusions[16].solid&&!source.extrusions[16].forgeBody->isSheet(),"decoder conserva il solido Svuota1");
 const auto frame=sketchAxes(source.sketches[2]);const auto&points=source.sketches[2].curves[0].controlPoints;
 Vec3 center=frame.toGlobal(Vec3(points[0].x(),points[0].y(),0));const double radius=std::hypot(points[1].x()-points[0].x(),points[1].y()-points[0].y());const Vec3 direction=-frame.zDir();
 require(direction.z()>.999999&&std::abs(center.z()+10)<1e-7,"Invertito sale da Schizzo3 verso Corpo1");
 const auto targetBinary=writeBodyBinary(*source.extrusions[16].forgeBody);
 const auto makeRef=[&](const Vec3&p,int expectedFace){double t=0;FaceId face;require(firstRayHit(*source.extrusions[16].forgeBody,p,direction,1e-8,t,&face),"raggio esatto incontra Corpo1");require(face.index==expectedFace,QString("riferimento atteso faccia%1, trovato%2").arg(expectedFace).arg(face.index));auto q=p+t*direction;GeometryRef ref;ref.kind=5;ref.index=16;ref.featureId=source.extrusions[16].featureId;ref.point={q.x(),q.y(),q.z()};return ref;};
 const GeometryRef extrusionRef=makeRef(center,18),splineRef=makeRef(center+Vec3(0,.9*radius,0),8);
 const auto checkCap=[&](const ForgeBody&result,const QString&label){
  require(result&&!result->isSheet(),label+": B-rep solido");
  const auto mass=massProperties(*result);require(mass.volume>2300&&mass.volume<2400,label+": volume atteso fra2300e2400mm3");
  RayFaceIndex targetIndex(*source.extrusions[16].forgeBody),resultIndex(*result);double maximumError=0;
  for(int sample=0;sample<17;++sample){double angle=(sample-1)*2*3.14159265358979323846/16.;Vec3 p=center+(sample?Vec3(radius*std::cos(angle),radius*std::sin(angle),0):Vec3());double expected=0,actual=0;FaceId targetFace,resultFace;
   require(firstRayHit(*source.extrusions[16].forgeBody,p,direction,1e-7,expected,&targetFace,&targetIndex),label+": copertura del punto campionato");
   // Una finestra esatta attorno al primo incontro esclude la base e le
   // generatrici laterali coincidenti nei punti sul cerchio di bordo.
   Interval window{expected-1e-5,expected+1e-5};
   require(firstRayHit(*result,p,direction,1e-7,actual,&resultFace,&resultIndex,&window),label+QString(": cap sul primo incontro, punto%1").arg(sample));
   maximumError=std::max(maximumError,std::abs(actual-expected));
   require(std::abs(actual-expected)<1e-6,label+": stesso arresto esatto del corpo limite");
   // Poco all'interno del bordo si puo' controllare anche che questo sia
   // il primo cap, senza accettare un eventuale incontro piu' lontano.
   if(sample){Vec3 inside=center+(p-center)*(1.-1e-5)+direction*1e-4;double targetT=0,resultT=0;
    require(firstRayHit(*source.extrusions[16].forgeBody,inside,direction,1e-7,targetT,nullptr,&targetIndex)&&firstRayHit(*result,inside,direction,1e-7,resultT,nullptr,&resultIndex),label+": primo cap vicino al bordo");require(std::abs(resultT-targetT)<1e-5,label+": nessun cap anticipato o oltre il limite");}
  }
  std::cout<<label.toStdString()<<" faces="<<result->faces().size()<<" volume="<<std::setprecision(12)<<mass.volume<<" capMaxError="<<maximumError<<" samples=17+16"<<std::endl;
 };
 QMainWindow window;auto*view=new CadViewport(&window);window.setCentralWidget(view);view->tessellationQuality_=0;
 if(gl){require(QGuiApplication::platformName()!="offscreen","rendering GL richiede piattaforma reale");window.resize(1250,900);window.show();}
 auto output=qEnvironmentVariable("FORGECAD_GUI_REVIEW_QA_DIR");if(!output.isEmpty())QDir().mkpath(output);
 for(int mode=0;mode<3;++mode){
  view->loadDocument(source);view->setReferencePlanesVisible(false);view->setAxesVisible(false);view->setGridVisible(false);view->setViewFrame(QVector3D(1,0,0),QVector3D(.7f,-1.f,-.8f));view->fitAll();QApplication::processEvents();
  ExtrusionObject definition;definition.sketchIndex=2;definition.extent=mode?3:4;definition.distance=-1;definition.mergeOperation=0;if(mode)definition.extentRef=mode==1?extrusionRef:splineRef;
  const QString label=mode==0?"next-body":mode==1?"face-extrusion18":"face-bspline8";bool inspected=false,applied=false;std::exception_ptr failure;
  QTimer::singleShot(0,&window,[&]{QDialog*panel=nullptr;for(auto*p:window.findChildren<QDialog*>())if(p->findChild<QComboBox*>("extrusionExtent"))panel=p;
   try{require(panel,"pannello estrusione reale");panel->resize(520,860);if(gl){QApplication::processEvents();view->camera_.autoFit_=false;view->camera_.panX_+=.5f*(panel->width()+24)*view->camera_.zoom_/view->height();view->update();QApplication::processEvents();}auto*extent=panel->findChild<QComboBox*>("extrusionExtent");auto*directionBox=panel->findChild<QComboBox*>("extrusionNextBodyDirection");auto*reference=panel->findChild<QPushButton*>("extrusionExtentReference");require(extent->currentIndex()==definition.extent,"modalita' del pannello richiesta");
    if(mode==0)require(directionBox->isVisibleTo(panel)&&directionBox->currentIndex()==1&&!reference->isVisibleTo(panel)&&!view->referencePicking(),"prossimo corpo invertito senza picker");else require(reference->isVisibleTo(panel)&&!view->referencePicking(),"riferimento libero esistente riconosciuto dal pannello");
    QElapsedTimer wait;wait.start();while((view->previewPending()||view->previewRunning_||(view->previewTimer_&&view->previewTimer_->isActive()))&&wait.elapsed()<45000)QApplication::processEvents();
    require(view->preview_.valid&&bool(view->preview_.geometry),"anteprima "+label+": "+view->previewError());checkCap(view->preview_.geometry,label+" preview");
    if(!output.isEmpty()){require(panel->grab().save(output+"/"+label+"-panel.png"),"cattura pannello");if(gl)require(view->grabFramebuffer().save(output+"/"+label+"-preview.png"),"cattura anteprima GL");}
    inspected=true;panel->findChild<QDialogButtonBox*>()->button(QDialogButtonBox::Ok)->click();require(applied,"conferma riesce: "+panel->findChild<QPlainTextEdit*>("extrusionStatus")->toPlainText());
   }catch(...){failure=std::current_exception();if(panel)panel->reject();}
  });
  const bool accepted=extrusionDialog(&window,view,"Schizzo3 fino a Corpo1 — "+label,-1,definition,[&](const ExtrusionObject&d){const auto why=view->createExtrusion(d,mode==0?QStringLiteral("Estrusione Schizzo 3 fino a Corpo 1"):label);applied=why.isEmpty();return why;});
  if(failure)std::rethrow_exception(failure);
  require(accepted&&inspected&&applied&&view->extrusions_.size()==18,"conferma una feature");
  require(view->extrusions_[16].visible&&view->isBodyVisibleInScene(16)&&writeBodyBinary(*view->extrusions_[16].forgeBody)==targetBinary,"Corpo1 rimane visibile e invariato");checkCap(view->extrusions_[17].forgeBody,label+" confirmed");const auto created=writeBodyBinary(*view->extrusions_[17].forgeBody);
  view->undo();require(view->extrusions_.size()==17&&view->extrusions_[16].visible&&writeBodyBinary(*view->extrusions_[16].forgeBody)==targetBinary,"Undo conserva Corpo1");view->redo();require(view->extrusions_.size()==18&&writeBodyBinary(*view->extrusions_[17].forgeBody)==created&&view->extrusions_[16].visible,"Redo ripristina geometria esatta");
  const QString copy=mode==0?QStringLiteral("/tmp/forgecad-superfici-fix/Superfici-estrusione-fino-corpo.prt"):"/tmp/forgecad-superfici-fix/"+label+".prt";require(saveDocumentFile(copy,view->documentState()).isEmpty(),"salvataggio copia dimostrativa");DocumentState decoded;require(loadDocumentFile(copy,decoded).isEmpty()&&decoded.extrusions.size()==18&&decoded.extrusions[17].solid&&decoded.extrusions[16].visible,"codec della nuova feature");require(writeBodyBinary(*decoded.extrusions[17].forgeBody)==created&&writeBodyBinary(*decoded.extrusions[16].forgeBody)==targetBinary,"codec conserva entrambe le geometrie esatte");
  CadViewport reopened;reopened.tessellationQuality_=0;reopened.loadDocument(decoded);checkCap(reopened.extrusions_[17].forgeBody,label+" reopened");require(reopened.extrusions_[16].visible&&reopened.extrusions_[17].error.isEmpty(),"riapertura senza errori o consumo del corpo limite");
  if(gl){view->fitAll();QApplication::processEvents();require(view->context()&&view->context()->isValid(),"contesto GL reale valido");if(!output.isEmpty())require(view->grabFramebuffer().save(output+"/"+label+"-confirmed.png"),"cattura conferma");view->makeCurrent();require(view->glGetError()==GL_NO_ERROR,"nessun errore GL");view->doneCurrent();}
  std::cout<<"PASS "<<label.toStdString()<<" panel preview confirm Undo Redo codec reopen target-preserved copy="<<copy.toStdString()<<std::endl;
 }
}
};
int main(int argc,char**argv){QSurfaceFormat f;f.setRenderableType(QSurfaceFormat::OpenGL);f.setVersion(3,3);f.setProfile(QSurfaceFormat::CoreProfile);f.setDepthBufferSize(24);f.setStencilBufferSize(8);QSurfaceFormat::setDefaultFormat(f);QApplication app(argc,argv);ForgeCad::initializeApplicationTheme(app);QCoreApplication::setOrganizationName("ForgeCADSuperficiFinalProbe");QCoreApplication::setApplicationName("GUI");QTemporaryDir settings;QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,settings.path());try{ViewportInteractionTest::run(app.arguments()[1],app.arguments().contains("--gl"));}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}return 0;}
