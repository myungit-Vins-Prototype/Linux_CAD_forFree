from pathlib import Path
import json,shlex,subprocess
root=Path('/home/myungit/Linux_CAD_forFree'); build=root/'forgecad-release'; out=Path('/tmp/forgecad-superfici-fix')
commands=json.loads((build/'compile_commands.json').read_text())
def compile_file(source,original,obj):
    command=next(c for c in commands if c['file'].endswith('/'+original))
    args=shlex.split(command['command']); args[args.index('-o')+1]=str(out/obj); args[-1]=str(source)
    args=['-O0' if a=='-O3' else a for a in args]
    subprocess.run(args,cwd=build,check=True)
compile_file(out/'face-ref-tests.cpp','tests/test_viewport.cpp','face-ref-tests.o')
compile_file(out/'cad_datum.cpp','cad_datum.cpp','face-ref-datum.o')
for variant in ['before','after']:
    args=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text()); args[args.index('-o')+1]=str(out/('face-ref-'+variant))
    for i,a in enumerate(args):
        if a=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o': args[i]=str(out/'face-ref-tests.o')
        elif variant=='after' and a=='CMakeFiles/forgecad_view_tests.dir/cad_datum.cpp.o': args[i]=str(out/'face-ref-datum.o')
        elif a.startswith('-Wl,--dependency-file='): args[i]='-Wl,--dependency-file='+str(out/('face-ref-'+variant+'.d'))
    subprocess.run(args,cwd=build,check=True)
