# QA GUI finale — Schizzo3 fino a Corpo1

## Precisazione sul file originale dopo la QA

La QA descritta qui si riferisce esclusivamente alla copia congelata `/tmp/forgecad-superfici-fix/Superfici.prt`, 15890253 byte, SHA256 `c5666c219d013c190fd5d3da34eb92ebc438d04b33f9e2eeef997dc7128b9dca`.

Un controllo successivo, in sola lettura, ha rilevato che `/home/myungit/Documenti/File_Esempio/Superfici.prt` è diverso: 16074185 byte, SHA256 `56779a6c668258e54d686a9f1e721de03acbea84a2c16d642e1083d364203adf`, mtime2026-11-02 16:39:58.961847526UTC. La causa e l'autore della modifica non sono stabiliti. Non è stato ripristinato o modificato durante questo controllo. Questa versione successiva non è coperta dai risultati geometrici sopra riportati.

La precedente formulazione «originali invariati» era impropria: i miei assert controllavano soltanto le copie congelate, non gli originali aperti nell'app utente. Il codice delle sonde usa solo `QMainWindow`/`CadViewport`, senza `PdfWindow`, `DocumentRecovery` o callback di autosalvataggio. `gui-final-probe.cpp` salva a tre nomi espliciti in `/tmp/forgecad-superfici-fix`; `projection-gui-native.cpp` salva nella QA_DIR, impostata sotto `/tmp` in tutte le esecuzioni. `saveDocumentFile` apre `QSaveFile` sul percorso canonico della copia passata; `loadDocumentFile` apre il file in sola lettura. L'audit statico non identifica l'autore di una scrittura storica fatta da un altro processo.

## Verifica definitiva con tutti gli oggetti production

Build comune completata dal coordinatore in `forgecad-combined-build-final.log`. Entrambe le sonde sono state ricompilate e ricollegate a **tutti gli oggetti effettivi** di `forgecad-release`, sostituendo soltanto il main del runner con il probe dedicato. Nessun override fixed nel collegamento definitivo.

| Verifica | Offscreen | Wayland reale | XCB reale |
| --- | --- | --- | --- |
| Superfici: prossimo corpo, Invertito | PASS | PASS | PASS |
| Superfici: fino alla faccia18 estrusa | PASS | PASS | PASS |
| Superfici: fino alla faccia8 BSpline | PASS | PASS | PASS |
| Curva proiettata: schizzo su schizzo, picking/checklist/3D | non richiesta | PASS | PASS |

Tutte le prove sono terminate con exit 0, senza timeout o errori GL. La dimostrazione del rendering usa i due backend reali; il test offscreen conferma soltanto il percorso funzionale del pannello.

### Estrusione sul file recente

Confermati sulla build definitiva gli stessi risultati del checkpoint: solido di 5 facce, volume 2348.73301675 mm³, errore cap 0 sui17 raggi esatti (centro+16 punti di bordo) e primo incontro corretto sui16 punti appena interni, ripetuti su anteprima, risultato confermato e riapertura. Pulsante Conferma reale, Undo/Redo esatti, codec e corpo limite visibile/invariato.

Log definitivi `gui-final-common-{offscreen,wayland,xcb}.log`; immagini nelle rispettive cartelle senza `.log`. Per backend reale9 catture: pannello, anteprima e conferma per le3 modalità. Dopo il primo PASS la sonda ha soltanto ampliato il pannello e traslato la camera per mostrare il cilindro fuori dal vetro del pannello; tutte e 9 le prove sono state ripetute con questa versione finale. Ispezionati parametri completi, anteprima del cilindro e risultato dalla parte interna della scocca.

### Nuova curva proiettata da due schizzi

Finestra principale e viewport realmente mostrati. Fixture del test permanente: due schizzi XY/XZ, ciascuno con due NURBS quadratiche. Pannello iniziale con tutte le entità deselezionate; veri eventi mouse nel viewport scelgono solo entità 0 di ciascuno schizzo. La checklist reale toglie e ripristina entità 0, mantenendo entità 1 esclusa. L'anteprima usa precisamente quei due riferimenti. La conferma crea una sola curva 3D implicita, senza fit, con21 campioni che soddisfano entrambe le quadratiche: errore massimo **8.88178e-16**. Le curve escluse sono a x 20–25 e 40–45; l'intero risultato controllato rimane a x 0–4. Undo/Redo conserva identità e geometria; la riapertura produce la stessa curva.

Log `projection-final-{wayland,xcb}.log`,10 catture per backend nelle cartelle omonime: iniziale, picking primo/secondo gruppo, anteprima, conferma e riapertura. Ispezionate le due checklist leggibili, entrambe con sola prima riga spuntata, risultato3D e riapertura. Wayland: Intel UHD Graphics P630, Mesa 4.6 Core 26.2.5; XCB: Quadro RTX 3000, NVIDIA OpenGL 3.3.0 615.78.08. Entrambi `GL_NO_ERROR`.

Diagnostica iniziale della sola sonda conservata in `projection-probe-initial-diagnostics.log`: l'adattamento automatico della camera alterava il focus manuale; inoltre alcuni clic cadevano dietro il pannello incorporato e venivano correttamente intercettati dal suo eventFilter. La sonda finale stabilizza la camera e inquadra gli input nell'area libera, controllando il riferimento prima/dopo la cattura e verificando che il clic sia fuori dal pannello. **Nessuna modifica ai sorgenti prodotto e nessun bug prodotto rilevato da queste prove finali.**

### Tracciabilità e copie finali

Elenco esatto dei100 oggetti/librerie production, con percorsi, dimensioni e SHA256: `gui-final-production-objects.json`. Argomenti completi dei due collegamenti: `gui-final-probe-common-link.json` e `projection-gui-native-link.json`. Manifesto completo dei binari e delle copie: `gui-final-artifacts.json`.

| Artefatto | SHA256 |
| --- | --- |
| app `forgecad` | `d51299cb2215aee1d04e8e4ff397bb0712c8974e1a53fb5074758fbcfa4219ed` |
| runner `forgecad_view_tests` | `2d3baa393d1e46965539fe98c0cc76ea5bd45c8bd75ae177ed5be6f37b425dbe` |
| kernel `libforgekernel.a` | `db3a51303454bf2729a483f5b2d44c3636e80df70a02b23ec6f9241f8434b00a` |
| sonda `gui-final-probe-common` | `d7ffccc6253a97c47a6da36fa9b6c20d7fc2885b1ecb0b19a7a713c52f16257f` |
| sonda `projection-gui-native` | `b2921b600e128c22229fb3e8829cbbb89feeb3b4d210d1a5b0d7d40f3a436e7f` |
| `Superfici-estrusione-fino-corpo.prt` | `efd63f7653f5b795818493a707383d9db4aca1be3271fe3081b97a2bfab10f76` |
| `Curva-proiettata-due-schizzi.prt` | `c996dc1c82d35230db645ecc2d6930ad1526aa715ccb534356860c22c4f9544d` |

Copie dimostrative in `/tmp/forgecad-superfici-fix`, rispettivamente 15976665 e 943 byte. Gli assert SHA precedenti verificavano esclusivamente le due copie congelate in `/tmp`, rimaste identiche al manifesto `fixtures.json`; non attestavano lo stato successivo degli originali in `File_Esempio`. Le sonde salvano soltanto nei percorsi temporanei descritti sopra e non interagiscono con processi utente.

## Checkpoint con oggetti fixed

Sonda dedicata `gui-final-probe-fixed`, SHA256 `6d9c7e64328aaf9562a2376e7584a7fb11e44fcfd718859778b4c1304f4ebe97`, collegata al runner completo sostituendo `cad_extrude`, `cad_document_io`, `cad_datum` con i3 oggetti fixed e aggiungendo `normal-fixed.o`. Sorgenti prodotto non modificati dall'agente GUI. Da ripetere con tutti gli oggetti della build comune dopo integrazione.

Tre pannelli reali sul file congelato recente `Superfici.prt`:

1. Fino al prossimo corpo, Invertito, Corpo nuovo, nessun riferimento.
2. Fino a una faccia o a un piano, riferimento alla faccia18 ExtrusionSurface di Svuota1.
3. Stessa modalità, riferimento alla faccia8 BSpline di Svuota1.

**PASS 9/9**: ciascuna modalità provata offscreen, Wayland e XCB. Ogni prova verifica anteprima valida, conferma dal pulsante vero, Undo e Redo, codec, riapertura nel viewport, flag solido del decoder e corpo limite rimasto visibile/invariato byte per byte. Nei due backend reali il contesto GL è valido e `glGetError()==GL_NO_ERROR`.

Tutti i risultati: solido di 5 facce, volume **2348.73301675 mm³**. Cap al primo incontro B-rep con Corpo1: errore massimo0 sui17 raggi esatti (centro+16 punti del cerchio di bordo), più16 controlli appena all'interno del bordo per verificare che non esista un cap anteriore o posteriore al primo incontro. Verifica ripetuta su anteprima, conferma e riapertura. E' un controllo geometrico campionato indipendente, aggiuntivo alle certificazioni analitiche del core.

Log:

- `gui-final-fixed-offscreen.log`
- `gui-final-fixed-wayland.log`
- `gui-final-fixed-xcb.log`

Catture9 per backend reale nelle cartelle omonime senza estensione `.log`: pannello, anteprima e conferma per ogni modalità. Ispezionati il pannello pronto e la vista inferiore del pezzo confermato: estrusione circolare visibile all'interno della scocca, corpo limite presente, nessun artefatto rilevato.

Copia dimostrativa: `/tmp/forgecad-superfici-fix/Superfici-estrusione-fino-corpo.prt`, SHA256 `4cf22019dd7d911c96affa7fe0e2483fafb0290a86192729e49bc94d4d217c5f` al checkpoint. Conserva tutte le 17 feature precedenti e aggiunge l'estrusione da Schizzo3 con extent4/Invertito, senza consumare Corpo1. La sonda risalva solo le copie proprie a ogni nuova esecuzione.
