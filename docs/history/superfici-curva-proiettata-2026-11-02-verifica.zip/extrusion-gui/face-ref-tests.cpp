#include "/home/myungit/Linux_CAD_forFree/forgeCad2026_viewport_internal.h"
#include "cad_pattern.h"
#include "cad_topology_ref.h"
#include "fk_body_io.h"
#include "fk_mass.h"
#include "fk_primitives.h"
#include <QTemporaryDir>
#include <iostream>
#include <stdexcept>

static void require(bool condition, const char *message) {
    if (!condition) throw std::runtime_error(message);
}

class ViewportInteractionTest {
public:
static void run(const QString &path) {
    using namespace ForgeCad;
    using namespace Kernel;
    DocumentState original;
    const QString loadError = loadDocumentFile(path, original);
    require(loadError.isEmpty(), qPrintable(loadError));
    require(original.extrusions.size() == 17 && original.sketches.size() >= 3,
            "fixture Superfici corrente con Schizzo3 e Svuota1");
    const Body &limiter = *original.extrusions.at(16).forgeBody;
    const RayFaceIndex rayIndex(limiter);
    QVector<GeometryRef> references;
    for (const auto &offset : {Vec3(0,0,0), Vec3(0,5,0)}) {
        const Vec3 rayOrigin = Vec3(-27.74674219,61.05967827,-10) + offset;
        double parameter; FaceId face;
        require(firstRayHit(limiter,rayOrigin,Vec3(0,0,1),1e-7,parameter,&face,&rayIndex),
                "raggio esatto incontra una faccia limite");
        GeometryRef reference;
        reference.kind = 5; reference.index = 16;
        reference.featureId = original.extrusions.at(16).featureId;
        reference.point = faceReference(limiter,face,rayOrigin+parameter*Vec3(0,0,1));
        const auto expectedType = references.isEmpty() ? SurfaceType::Extrusion : SurfaceType::BSpline;
        require(limiter.face(face).surface->type() == expectedType, "facce reali Extrusion e BSpline distinte");
        ResolvedRef resolved; QString error;
        const bool ok = resolveGeometryRef(reference,original.extrusions.size(),original.sketches,original.extrusions,resolved,&error);
        std::cout << "RESOLVER face=" << face.index << " type=" << int(expectedType) << " ok=" << ok
                  << " error=" << error.toStdString() << std::endl;
        require(ok && resolved.face == face.index, "la faccia libera e' risolta senza obbligo di piano/asse");
        require(!resolved.hasPlane && !resolved.hasLine && !resolved.hasPoint && !resolved.hasCurve && !resolved.nearest,
                "nessun piano asse punto o curva inventati per la faccia libera");
        references.append(reference);
    }
    // Il successo del riferimento faccia non ne amplia i ruoli geometrici.
    for (const auto &reference : references) {
        SketchFrame frame; QString error;
        for (int mode : {0,2,3}) {
            DatumParameters datum; datum.mode = mode; datum.refs = {reference, GeometryRef{}};
            datum.refs[1].kind = 0;
            require(!computeDatum(datum,17,original.sketches,original.extrusions,frame,&error) && error.contains("serve"),
                    "datum piano curva e asse continuano a rifiutare facce libere");
        }
        for (int kind : {0,1,2}) {
            PatternParameters pattern; pattern.kind = kind; pattern.count = 2; pattern.spacing = 10;
            pattern.refs = {reference}; std::vector<Transform3> placements;
            require(!patternPlacements(pattern,17,original.sketches,original.extrusions,placements,&error)
                        && placements.empty() && !error.isEmpty(),
                    "direzione asse e specchio non ricavano geometrie spurie dalla faccia libera");
        }
        ExtrusionObject draft; draft.feature = BodyFeature::Draft; draft.firstBody = 16; draft.draftNeutral = reference;
        buildGeometry(draft,17,original.sketches,original.extrusions);
        require(!draft.forgeBody && draft.error.contains("piana"), "sformo rifiuta ancora faccia libera come piano neutro");
        ExtrusionObject thicken; thicken.feature = BodyFeature::Thicken; thicken.firstBody = 16; thicken.thickenDirection = reference;
        buildGeometry(thicken,17,original.sketches,original.extrusions);
        require(!thicken.forgeBody && thicken.error.contains("direzione"), "ispessimento non inventa una direzione");
    }
    // I ruoli preesistenti di piani e cilindri restano disponibili.
    ExtrusionObject cylinder; cylinder.forgeBody = std::make_shared<const Body>(makeCylinder(Frame3(),2,5));
    QVector<ExtrusionObject> synthetic{cylinder};
    for (FaceId face : cylinder.forgeBody->faces()) {
        const auto type = cylinder.forgeBody->face(face).surface->type();
        if (type != SurfaceType::Plane && type != SurfaceType::Cylinder) continue;
        const auto fin = cylinder.forgeBody->loop(cylinder.forgeBody->face(face).loops.front()).first;
        GeometryRef reference; reference.kind = 5; reference.index = 0;
        reference.point = faceReference(*cylinder.forgeBody,face,cylinder.forgeBody->finPoint(fin,0.5));
        ResolvedRef resolved; QString error;
        require(resolveGeometryRef(reference,1,{},synthetic,resolved,&error), "facce analitiche ancora risolte");
        require(type == SurfaceType::Plane ? resolved.hasPlane && !resolved.hasLine : resolved.hasLine && !resolved.hasPlane,
                "ruoli analitici piano e asse cilindrico preservati");
    }
    std::cout << "PASS consumer: datum/pattern/draft/thicken prudenti, ruoli analitici preservati" << std::endl;
    if (qEnvironmentVariableIsSet("FACE_REF_RESOLVE_ONLY")) return;
    QTemporaryDir files;
    require(files.isValid(), "directory temporanea per persistenza");
    for (int selected = 0; selected < references.size(); ++selected) {
        CadViewport view; view.tessellationQuality_ = 0; view.loadDocument(original);
        ExtrusionObject definition;
        definition.feature = BodyFeature::Extrusion; definition.sketchIndex = 2;
        definition.extent = 3; definition.distance = -1; definition.extentRef = references.at(selected);
        definition.mergeOperation = 0;
        view.requestPreview(definition);
        QElapsedTimer wait; wait.start();
        while ((view.previewPending() || view.previewRunning_ || (view.previewTimer_ && view.previewTimer_->isActive()))
               && wait.elapsed() < 45000) QApplication::processEvents();
        std::cout << "PREVIEW selected=" << selected << " valid=" << view.preview_.valid
                  << " error=" << view.previewError().toStdString() << std::endl;
        require(view.preview_.valid && view.preview_.geometry && !view.previewRunning_, "anteprima reale extent3 su faccia libera");
        const double previewVolume = massProperties(*view.preview_.geometry).volume;
        require(previewVolume > 0 && std::isfinite(previewVolume), "volume dell'anteprima finito e positivo");
        const auto createError = view.createExtrusion(definition,QStringLiteral("Faccia libera %1").arg(selected));
        require(createError.isEmpty(),qPrintable(createError));
        require(view.extrusions_.size() == 18 && view.extrusions_.last().forgeBody, "estrusione extent3 realmente creata");
        const auto &created = view.extrusions_.last();
        const auto bytes = writeBodyBinary(*created.forgeBody);
        const auto id = created.featureId;
        const auto savedReference = created.extentRef;
        const double volume = massProperties(*created.forgeBody).volume;
        require(std::fabs(volume-previewVolume) < 1e-8, "anteprima e risultato creato coerenti");
        view.undo(); require(view.extrusions_.size() == 17, "Undo della creazione fino a faccia libera");
        view.redo(); require(view.extrusions_.size() == 18 && view.extrusions_.last().featureId == id
                                && writeBodyBinary(*view.extrusions_.last().forgeBody) == bytes,
                            "Redo preserva identita' e B-rep esatta");
        const QString file = files.filePath(QStringLiteral("faccia-%1.prt").arg(selected));
        require(saveDocumentFile(file,view.currentDocument()).isEmpty(), "salvataggio esclusivamente nella copia temporanea");
        DocumentState loaded;
        require(loadDocumentFile(file,loaded).isEmpty() && loaded.extrusions.size() == 18, "riapertura del risultato extent3");
        const auto &reopened = loaded.extrusions.last();
        ResolvedRef reopenedReference; QString referenceError;
        require(reopened.extent == 3 && reopened.extentRef.kind == 5
                    && reopened.extentRef.featureId == savedReference.featureId
                    && !reopened.extentRef.point.name.isEmpty() && reopened.forgeBody
                    && writeBodyBinary(*reopened.forgeBody) == bytes
                    && resolveGeometryRef(reopened.extentRef,17,loaded.sketches,loaded.extrusions,reopenedReference,&referenceError)
                    && reopenedReference.face == savedReference.point.subshape,
                "codec conserva proprietario, nome genealogico e faccia selezionata esatta");
        // Il primo salvataggio assegna i nomi topologici alle vecchie cache
        // che ne erano prive; dal secondo giro il nome resta identico.
        QByteArray encoded; DocumentState decoded;
        require(encodeDocument(loaded,encoded).isEmpty() && decodeDocument(encoded,decoded).isEmpty()
                    && decoded.extrusions.last().extentRef.point.name == reopened.extentRef.point.name,
                "nome genealogico stabile al secondo ciclo codec");
        auto rebuilt = reopened;
        buildGeometry(rebuilt,17,loaded.sketches,loaded.extrusions);
        require(rebuilt.forgeBody && rebuilt.error.isEmpty()
                    && std::fabs(massProperties(*rebuilt.forgeBody).volume-volume) < 1e-8,
                "ricalcolo dopo riapertura risolve ancora la faccia libera");
        std::cout << "PASS extent3 selected=" << selected << " volume=" << volume
                  << " preview/create/Undo/Redo/save/reopen/rebuild" << std::endl;
    }
}
};
int main(int argc,char **argv) {
    QApplication application(argc,argv);
    QCoreApplication::setOrganizationName("ForgeCADFaceRefProbe");
    QCoreApplication::setApplicationName("Tests");
    try { require(argc>1,"percorso copia congelata richiesto"); ViewportInteractionTest::run(QString::fromLocal8Bit(argv[1])); }
    catch (const std::exception &error) { std::cerr << "FAIL " << error.what() << std::endl; return 1; }
    return 0;
}
