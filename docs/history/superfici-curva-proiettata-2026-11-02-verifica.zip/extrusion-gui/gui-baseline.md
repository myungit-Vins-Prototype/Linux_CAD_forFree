# QA GUI indipendente — Schizzo3 fino a Corpo1

Sonda `/tmp/forgecad-superfici-fix/gui-probe`, collegata agli oggetti del runner completo attuale. Nessun sorgente modificato. Documento caricato con `CadViewport::loadDocument`, pannello reale `extrusionDialog`, chiuso con Annulla. I file congelati sono rimasti identici al manifesto `fixtures.json`.

## File recente `Superfici.prt`

17 feature; Corpo1 logico termina in Svuota1, indice16. Schizzo3 circolare nel piano z=-10, normale-Z. Il verso che sale verso Corpo1 è **Invertito**.

- Extent4, Positivo: anteprima non valida, `Nessun corpo incontra il profilo nel verso dell'estrusione.`
- Extent4, Invertito: anteprima non valida, `Le superfici incontrate hanno sottosquadri o una forma non certificabile fino al primo incontro.`
- Extent3, faccia18 del corpo16 al primo incontro sopra il centro del cerchio: `Riferimento della fine non valido: la faccia scelta non e' piana ne' cilindrica o conica.`

Confermati gli stessi primi due esiti sia offscreen sia con vero rendering Wayland. Il pannello mostra Direzione e non richiede un riferimento per extent4. Catture pannello e viewport in `gui-current-wayland`; ispezionate visivamente.

Raggi B-rep esatti lungo+Z: centro(-27.74674219,61.05967827,-10) incontra faccia18, ExtrusionSurface, z19.9533. Gli8punti di bordo, raggio5, incontrano tutti il corpo fra z19.5445 e19.9969; uno colpisce la faccia8 BSpline. Campionamento utile per QA, non prova analitica di copertura completa. Log `gui-current-face.log`.

## File vecchio `superifici.prt`

9 feature; Schizzo3 poligonale z≈0, normale+Z. Estrusione8, indice7, salvata con extent3, riferimento faccia body4, punto≈(0.0440378,0.381045,-1.73362). Anteprima valida: volume0.433405,6facce, solido, bounds z[-1.73362,0].

- Passaggio extent4 Positivo: `Nessun corpo incontra il profilo nel verso dell'estrusione.`
- Passaggio extent4 Invertito: `Un corpo limite attraversa il piano iniziale del profilo.`

Log `gui-old.log`; pannelli catturati in `gui-old`.

La GUI rigenera le cache e ripristina `solid=!isSheet()` nel percorso `buildFeature`, quindi oltrepassa il difetto di flag segnalato dal coordinatore nel decoder. Le chiamate dirette a `buildGeometry` dopo il solo decoder possono osservare quel difetto prima della rigenerazione.
