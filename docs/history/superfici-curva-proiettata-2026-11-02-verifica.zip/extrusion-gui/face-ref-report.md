# Riferimenti a facce libere — 2 novembre 2026

## Richiesta e copia di prova

Verificata l'estrusione «Fino a una faccia o a un piano» (`extent=3`) su
Schizzo 3 del documento corrente `Superfici.prt`: cerchio sul piano z=-10,
normale -Z, limite Corpo 1 / Svuota 1 (feature index 16, ID 18).
Usata esclusivamente la copia congelata
`/tmp/forgecad-superfici-fix/Superfici.prt`, SHA256
`c5666c219d013c190fd5d3da34eb92ebc438d04b33f9e2eeef997dc7128b9dca`.
L'originale non e' stato scritto. I documenti prodotti dai test sono in una
`QTemporaryDir` separata.

## Causa e correzione

`cad_datum.cpp::resolveForgeBody` risolveva gia' l'identita' esatta della
faccia e assegnava `ResolvedRef::face`, ma restituiva errore se la superficie
non era un piano, un cilindro o un cono. Il ramo `curvedFace` gia' presente
nell'estrusione non poteva quindi elaborare una faccia Extrusion o B-spline.
L'errore riprodotto era: «la faccia scelta non e' piana ne' cilindrica o
conica».

La modifica restituisce successo per una faccia B-rep valida gia' risolta,
lasciando falsi `hasPlane`, `hasLine`, `hasPoint` e `hasCurve`. Non costruisce
un piano tangente, un asse o altre geometrie sostitutive. Piani, cilindri e
coni conservano i loro rami precedenti. Non cambia API, formato, tolleranze,
geometria dell'estrusione o associazione genealogica.

Il contratto era gia' espresso da `DatumRoleFace` in `cad_datum.h` («una
faccia qualsiasi, anche curva»). Verificati i consumer del resolver: datum,
piani di appoggio/sezione, sformo, rivoluzione, direzioni di ispessimento,
pattern e trasformazioni controllano i relativi flag prima di usare piano,
asse, curva o punto. La sezione associativa di una faccia usa invece
correttamente l'identita' della faccia B-rep.

## Prove differenziali effettive

Sonde Qt offscreen collegate agli oggetti della build Release finale
esistente; nella variante corretta e' sostituito il solo oggetto
`cad_datum.cpp`. Non e' una ricompilazione dell'app completa e non certifica
il rendering OpenGL o la scelta tramite mouse del pannello.

Test dedicato: `/tmp/forgecad-superfici-fix/face-ref-tests.cpp`.
Build riproducibile: `/tmp/forgecad-superfici-fix/face-ref-build.py`.
Eseguibili distinti `face-ref-before` e `face-ref-after`.

- Prima: il test fallisce sulla faccia 18, tipo Extrusion, con l'errore sopra.
- Dopo: raggio esatto da `(-27.74674219,61.05967827,-10)` verso +Z incontra
  faccia 18, tipo Extrusion; raggio da y+5 incontra faccia 8, tipo B-spline.
  Entrambi i riferimenti risolvono la faccia attesa senza flag spurii.
- Per entrambe le facce: anteprima reale tramite `requestPreview`, creazione
  extent3, volume positivo e coerente anteprima/risultato (2348,73), Undo e
  Redo con identita' e B-rep binaria invariate, salvataggio su file temporaneo,
  riapertura, risoluzione della stessa faccia e ricostruzione dopo riapertura
  con volume invariato: PASS.
- Il primo salvataggio promuove correttamente a nomi genealogici le vecchie
  cache prive di nome. Il secondo ciclo codec conserva esattamente il nome;
  identita' del proprietario e faccia selezionata restano le stesse.
- Per entrambe le facce libere: datum per piano/curva/retta, pattern
  lineare/circolare/specchio, piano neutro dello sformo e direzione di
  ispessimento continuano a rifiutare il riferimento con errore: PASS.
- Controlli analitici su cilindro sintetico: piano di base ancora `hasPlane`,
  fianco cilindrico ancora `hasLine`, senza scambio di ruoli: PASS.

Comando della sonda completa (variabili Qt isolate):

```sh
env QT_QPA_PLATFORM=offscreen QT_QPA_OFFSCREEN_NO_GLX=1 \
  QT_QPA_PLATFORMTHEME= QT_STYLE_OVERRIDE=Fusion \
  XDG_CONFIG_HOME=/tmp/forgecad-superfici-fix/config \
  /tmp/forgecad-superfici-fix/face-ref-after \
  /tmp/forgecad-superfici-fix/Superfici.prt
```

## Consegna e limiti

Sorgente da integrare: `/tmp/forgecad-superfici-fix/cad_datum.cpp`, SHA256
`62359b0a8e33bbf25d76abc02f0c962afe7af4b50c5b11ab449459b7ceba3844`.
Non modificati cad_extrude.cpp, cad_document_io.cpp, header comuni,
script condivisi o documenti originali. Le correzioni separate della
certificazione `extent=4` sono di competenza del coordinatore. L'estrusione
extent3 continua a usare il ramo geometrico preesistente: questa modifica
rimuove il rifiuto improprio del riferimento, senza dichiarare supporto
universale per ogni possibile configurazione di superfici libere.
