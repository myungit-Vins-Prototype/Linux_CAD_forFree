# Certificazione delle normali sulla faccia limitata — 2 novembre 2026

## Problema e contratto

Il certificatore precedente controllava tutte le pezze Bezier del supporto
B-spline, comprese quelle che la faccia B-rep non utilizza. Sul risultato
intermedio dell'estrusione di Schizzo 3 verso Corpo 1 in `Superfici.prt`, una
coppia di poli derivati negativa appartiene a una parte del supporto esterna
alla faccia. Questo produceva un rifiuto della superficie limite corretta.

Nuova API pura C++17, namespace `ForgeCad::Kernel`:

```cpp
bool faceHasNonnegativeNormalProjection(const Body &, FaceId, const Vec3 &direction);
```

Implementazione e header isolati in
`/tmp/forgecad-superfici-fix/kernel/fk_face_normal_bounds.{h,cpp}`. Nessun
riferimento a Qt, OCCT, mesh, visualizzazione o campioni di superficie.
L'API include `face.sense`, normalizza una direzione finita e non nulla,
usa `kAngularResolution` invariato e conserva la cancellazione kernel.

## Metodo implementato

1. Ogni SP-curve supportata viene sollevata esattamente in z=0 e ritagliata
   con `rationalBezierPieces` al range del suo edge. Non si usano i poli
   globali della curva oltre il tratto. Sono gestite rette, B-spline,
   wrapper Trimmed, cerchi ed ellissi; per i bounds razionali occorrono
   pesi positivi. Dominio del wrapper e dominio della spline devono coprire
   l'intero range richiesto.
2. L'hull dei poli delle pezze ritagliate racchiude il contorno in UV. Prima
   di restringere il supporto si certifica il verso totale dei contorni:
   area Bernstein polinomiale, o bound conservativo omogeneo per le
   SP-curve razionali, con intervalli arrotondati verso l'esterno.
   L'orientamento considera i versi delle fin e della faccia. Fori interni
   non vengono scambiati con contorni esterni; un complemento descritto da
   soli fori non restringe il dominio.
3. SP-curve mancanti, sconosciute o fuori dominio, loop con vertice isolato,
   area non certificabile e superfici periodiche usano il supporto intero.
   Un supporto infinito che non consente conversione rimane non certificato.
4. Si saltano soltanto le pezze Bezier con intersezione UV vuota rispetto
   alla finestra conservativa. Le pezze sovrapposte, incluso il contatto sul
   bordo, vengono controllate per intero. Ogni coppia di poli derivati U/V
   deve avere proiezione del prodotto vettoriale non negativa entro la
   risoluzione angolare esistente. Le combinazioni convesse delle derivate
   danno il certificato sull'intera pezza: nessun controllo per campioni.
5. Per `ExtrusionSurface` non parallela alla direzione richiesta si usa
   `toBSplineSurface` esatto su una finestra finita e la stessa prova. Le
   normali di qualsiasi estrusione sono invece ortogonali alla generatrice:
   il caso parallelo e' certificato prima del controllo del tipo di curva,
   preservando estrusioni ellittiche e razionali gia' ammesse.

Superfici B-spline con pesi variabili e basi di estrusione non polinomiali
nel verso trasversale restano rifiutate conservativamente. Pesi uguali sono
riconosciuti come polinomiali; i pesi variabili non sono ignorati.

## Test effettivi

Nuovo test permanente proposto:
`/tmp/forgecad-superfici-fix/kernel/tests/test_face_normal_bounds.cpp`.
Compilato come standalone con `kernel/tests/fk_test_main.cpp`, nuovo modulo
e `forgecad-release/kernel/libforgekernel.a`, usando C++17, `-O2`,
`-Wall -Wextra -Wpedantic -ffp-contract=off`, senza OCCT. Nessun warning.

**8/8 PASS**, con verifiche di:

- supporto ripiegato fuori dalla faccia trimmed accettato; normale negativa
  dentro la faccia e finestra che attraversa il ripiegamento rifiutate;
- `face.sense` invertito, versi opposti e direzione non unitaria;
- SP-curve con dominio globale [-10,10] e soli range edge ristretti, senza
  usare i poli globali esterni al tratto;
- SP-curve mancanti, sconosciute o con wrapper/spline che non coprono il
  range: fallback conservativo; supporto intero positivo ancora accettato;
- faccia con foro, complemento descritto dal solo foro, vertice isolato;
- superficie polinomiale, pesi costanti, pesi variabili rifiutati, direzioni
  nulle/non finite e ID faccia invalido;
- graph di `ExtrusionSurface` B-spline, supporto ripiegato esterno al trim,
  pcurve mancante e periodicita' conservativa;
- SP-curve conica, propagazione di `OperationCancelled`;
- estrusioni razionali ed ellittiche: entrambi i versi della generatrice
  accettati anche senza pcurve, verso trasversale non certificato.

Sonda separata sul B-rep intermedio congelato
`/tmp/forgecad-superfici-fix/before-certificate.body`: **3/3 facce libere
PASS**, faccia 2 B-spline, faccia 3 B-spline, faccia 4 Extrusion con
`sense=false`. Le facce analitiche restano gestite dal chiamante. Questa
sonda non riscrive il documento originale.

Questi esiti riguardano il modulo e le sonde collegate al kernel esistente,
non una compilazione completa dell'app. Il coordinatore integra il modulo,
il target CMake standalone, il chiamante dell'estrusione e la validazione
delle shell; esegue poi le suite comuni e le prove native.

## Limiti espliciti e consegna

Il certificatore e' sufficiente, non necessario: una pezza sovrapposta viene
verificata per intero, e un bound UV, un'area o un caso razionale non
certificabili possono causare un rifiuto prudente. Non sono introdotti
suddivisione adattiva, stime da mesh o tolleranze piu' permissive. Come le
altre operazioni kernel, si assume valida l'orientazione B-rep fornita.

SHA256 fonti stabili:

- header: `3a285c749e77063be48cd739e9460b5063630f8d5444406ab470e708f957cf2f`
- cpp: `b889e753bd07f42d50a7cb9e3694a27e0c6f18d1136cc07b48ef2eb07fabaebc`
- test: `dada522bb7e2cdbd87e2724d69fca1318d72c1ea2c0ad294d5037a2e4d4ad58f`

Non modificati sorgenti del checkout effettivo, cad_extrude.cpp,
cad_document_io.cpp, CMake, script condivisi, documenti originali o processi
utente. Il coordinatore centralizza memoria e mappa architetturale.
