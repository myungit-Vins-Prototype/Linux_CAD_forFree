#!/usr/bin/env python3
"""Ripete tre sonde rapide sullo snapshot congelato e salva comandi/ambiente/esiti."""
from pathlib import Path
import os,json,hashlib,datetime,subprocess,shlex
snapshot=Path(__file__).resolve().parent
evidence=snapshot/'evidence';evidence.mkdir(exist_ok=True)
manifest=json.loads((snapshot/'manifest.json').read_text())
for item in manifest['files']:
    if hashlib.sha256((snapshot/item['path']).read_bytes()).hexdigest()!=item['sha256']:
        raise SystemExit('Snapshot mutato: '+item['path'])
manifest_hash=hashlib.sha256((snapshot/'manifest.json').read_bytes()).hexdigest()
commands=[
 ('kernel-21',snapshot/'kernel/tests_sketch_projection',{},[]),
 ('asan-ubsan-21',snapshot/'kernel/tests_sketch_projection_asan',{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'},['kernel/fk_sketch_projection.cpp','kernel/tests/test_sketch_projection.cpp']),
 ('gui-offscreen',snapshot/'gui_probe',{'QT_QPA_PLATFORM':'offscreen','QT_QPA_PLATFORMTHEME':'generic','QT_STYLE_OVERRIDE':'Fusion','XDG_CONFIG_HOME':str(snapshot/'config')},[])
]
summary=[]
for name,binary,overrides,instrumented in commands:
    env=dict(os.environ);env.update(overrides)
    command=[str(binary)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    command_text='env '+shlex.join([*[key+'='+value for key,value in overrides.items()],*command]) if overrides else shlex.join(command)
    header=[
        'UTC '+started,'CWD '+str(snapshot),'SNAPSHOT_MANIFEST_SHA256 '+manifest_hash,
        'BINARY_SHA256 '+hashlib.sha256(binary.read_bytes()).hexdigest(),'COMMAND '+command_text,
        'ENVIRONMENT_OVERRIDES '+json.dumps(overrides,sort_keys=True),'TIMEOUT_SECONDS 45',
        'INSTRUMENTED_TU '+json.dumps(instrumented),
        'UNINSTRUMENTED kernel/fk_step.cpp; kernel/fk_iges.cpp; existing libforgekernel.a; GUI objects',
        'LEAK_SANITIZER disabled: environment is under ptrace; this is not a full-app sanitizer certification.',
        'GUI_NOTE offscreen does not certify native OpenGL rendering.'
    ]
    try:
        result=subprocess.run(command,cwd=snapshot,env=env,text=True,capture_output=True,timeout=45)
        code=result.returncode;stdout=result.stdout;stderr=result.stderr
    except subprocess.TimeoutExpired as failure:
        code=124;stdout=str(failure.stdout or '');stderr=str(failure.stderr or '')+'\nTIMEOUT'
    body='\n'.join(header)+'\n\nSTDOUT\n'+stdout+'\nSTDERR\n'+stderr+'\nEXITCODE '+str(code)+'\n'
    (evidence/(name+'.log')).write_text(body)
    summary.append({'name':name,'command':command,'environment_overrides':overrides,'exitcode':code,'instrumented_TU':instrumented,'log':name+'.log','utc':started,'binary_sha256':header[3].split(' ',1)[1]})
    print(name+': exitcode='+str(code)+' '+stdout.strip())
(evidence/'summary.json').write_text(json.dumps({'manifest_sha256':manifest_hash,'source_files_verified':len(manifest['files']),'runs':summary},indent=2)+'\n')
raise SystemExit(0 if all(item['exitcode']==0 for item in summary) else 1)
