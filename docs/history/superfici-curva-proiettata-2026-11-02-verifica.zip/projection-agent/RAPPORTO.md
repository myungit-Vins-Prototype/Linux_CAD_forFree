# Curva proiettata da due schizzi — 2 novembre 2026

## Richiesta e interpretazione

L'immagine fornita e' stata ispezionata: input solo le due curve azzurre indicate dalle frecce arancione/verde; risultato la curva gialla indicata dalla freccia scura. Le curve grigie sono escluse. Non si sommano punti con parametri uguali arbitrari.

La modalita' SolidWorks **Sketch on sketch** interseca le superfici implicite ottenute proiettando ciascuna curva normalmente al proprio piano. Semantica confermata dalla [documentazione primaria SolidWorks](https://help.solidworks.com/2024/english/SolidWorks/sldworks/HIDD_DVE_PROJ_SKETCH.htm): due schizzi su piani incidenti e anteprima della curva 3D. Questa implementazione usa proiezione bidirezionale; non aggiunge un taglio per semirette positive/invertite alla modalita' nuova.

## Implementato

- La funzione esistente **Curva proiettata** conserva Schizzo su corpo e aggiunge **Schizzo su schizzo (curva 3D)**. Il pannello si apre anche senza solidi o superfici.
- Due gruppi distinti: scelta dello schizzo, elenco delle curve/segmenti con spunte, pulsanti Tutte/Nessuna e selezione nella vista. Quando si sceglie una curva nella vista, le altre entita' dello schizzo restano escluse. La preselezione di due schizzi interi inizializza i due gruppi.
- Anteprima asincrona, conferma, modifica, Undo/Redo e storyboard riusano i flussi esistenti. Tooltips e dettagli distinguono le due modalita'.
- `projectionMode=0` conserva il comportamento storico; `1` ha significato nuovo soltanto per `BodyFeature::ProjectedCurve`. `ruledFirst`/`ruledSecond` contengono i due gruppi di `GeometryRef` kind 7; enum persistite e formato nativo **60 invariati**. Le liste erano gia' serializzate e visitate dalle rimappature generiche. `firstBody`/`sketchIndex` sono -1 per la nuova modalita'.
- Dipendenze/rigenerazione/storia riferiscono entrambi gli schizzi e nessun corpo. Curve multiple restano una feature con `curves` e prima curva in `curve`, come le curve proiettate precedenti.
- Nuovo kernel puro C++17 `fk_sketch_projection`, senza Qt/OCCT; modulo applicativo `cad_projected_curve` per la risoluzione dei riferimenti; dialogo separato `forgeCad2026_dialogs_projection`.

## Geometria

Date le normali n1 e n2, la coordinata comune e' lungo l'asse normalizzato n1×n2. Le coppie di parametri soddisfano `asse·C1(t) = asse·C2(s)`. Ciascuna sorgente analitica/NURBS viene convertita in tratti razionali di Bezier esatti; le radici Bernstein della derivata razionale della coordinata comune separano i rami monotoni. I domini risultanti sono limitati all'intervallo comune reale. Le coniche conservano la geometria esatta anche quando cambia il parametro nella conversione razionale.

L'intersezione viene ricostruita con un lift lineare stabile sulle due normali. Se uno degli input e' rettilineo, o se le due coordinate comuni coincidono come funzioni razionali del parametro normalizzato, il risultato e' una **NURBS esatta**, ottenuta dai poli/coordinate omogenee e non da fit. Il controllo d'identita' e di coordinata costante usa budget relativi ai pesi locali, senza un floor assoluto che nasconda differenze con pesi piccoli.

Altrimenti una **curva implicita esatta** conserva le due sorgenti razionali e risolve l'inversa scalare monotona in `double` per ogni valutazione. Sono disponibili derivate analitiche fino all'ordine 3 tramite differenziazione implicita. Non sono introdotte spline d'approssimazione, mesh o accoppiamenti a pari parametro. Quando l'inversa non puo' ottenere un residuo affidabile con un parametro rappresentabile in double, l'operazione fallisce esplicitamente.

Tutti i rami vengono conservati e collegati tramite gli estremi entro la risoluzione kernel, senza decidere la geometria dai campioni di display. Adiacenze precomputate O(N²), massimo 1024 tratti generati, limiti ulteriori sui rami sorgenti/coppie e cancellazione nei cicli. I punti fisici risultanti devono stare nella sizeBox del kernel; per i rami impliciti un inviluppo convesso sulle due curve viene certificato con suddivisione e budget limitato. Numeratori omogenei e derivate non ricevono impropriamente il limite spaziale. I pesi sono normalizzati con un fattore comune, senza cambiare geometria o parametro.

## Errori e limiti espliciti

- Piani paralleli, nessun intervallo comune, soli contatti puntuali, sorgenti mancanti/duplicate, gruppi che mescolano schizzi diversi e superfici coincidenti su un'area non producono risultati parziali.
- Tangenze comuni non regolari non riconducibili ai casi NURBS esatti sono rifiutate. Non viene dichiarato un risolutore universale di intersezioni algebriche singolari.
- I piani arbitrariamente orientati sono supportati entro la risolubilita' dei double. Piani quasi paralleli possono produrre geometria fuori sizeBox o un problema non certificabile entro il budget: l'errore e' esplicito.
- Le curve implicite generali sono mostrate, selezionabili e misurabili. Nell'app, sweep, conversione in schizzo e STEP/IGES sono rifiutati con messaggio esplicito quando richiederebbero un fit non autorizzato. I risultati NURBS esatti mantengono tali usi.
- Il salvataggio nativo memorizza gli input e rigenera le curve; `curves` non viene serializzato come un edge B-rep. Non viene invocato il codec B-rep su `CurveType::Other` per questa feature. Provati salvataggio/lettura sia con cache che senza.
- Anche i writer kernel STEP/IGES grezzi rifiutano direttamente questa nuova curva implicita, incluse le forme Trimmed/Transformed, prima di raggiungere i catch che attivano il fit. La guardia e' specifica: il fallback legacy degli altri tipi Other, comprese le eliche, resta invariato ed e' coperto dalla regressione.
- Le operazioni che richiedono una prova esaustiva dei minimi su curve razionali non acquisiscono automaticamente tale garanzia per la curva implicita; il picking/nearest riusa il fallback parametrico esistente.

## Verifiche effettivamente eseguite

Linux, GCC C++17, Qt 6.12.0; sorgenti preparati sotto `/tmp/forgecad-projected-curve`. Tutte le unita' applicative modificate/nuove sono state compilate individualmente con `-Wall -Wextra -Wpedantic`, senza warning.

**Kernel: 21 gruppi PASS**, compresi:

1. Intervallo comune limitato e parametri di input diversi; NURBS esatta da retta.
2. Intersezione implicita spline/spline, residuo sulle due proiezioni e derivate finite.
3. Piani inclinati, non ortogonali, ruotati e traslati.
4. Piani paralleli e intervallo comune assente.
5. Due rami distinti di una curva ripiegata.
6. Generatrice costante finita e coincidenza su area.
7. NURBS esatta da parametro razionale comune.
8. Derivate implicite confrontate con differenze finite indipendenti in punti interni.
9. Tangenza comune non regolare rifiutata; generatrice critica non duplicata.
10. 40 coppie quadratiche casuali riproducibili: residui di proiezione e invarianza allo scambio degli input.
11. Domini `Trimmed` conservati.
12. Output quasi parallelo fuori sizeBox rifiutato prima del display.
13. Tetto 1024 sui tratti generati, prima della connessione.
14. Pesi comuni 1e200 normalizzati e pesi locali 1e-40 rifiutati quando non risolvibili senza falsificare la curva.
15. Cancellazione kernel propagata.
16. Writer grezzi STEP/IGES: intersezione implicita diretta, limitata e trasformata rifiutate con errore specifico; NURBS esatte ed eliche legacy ancora esportabili.

**Sonda GUI con oggetti di produzione sostituiti dai nuovi moduli: PASS** (`Qt offscreen`, Fusion): curve entity0 scelte ed entity1 escluse in entrambi gli schizzi; preview asincrona; creazione Undo/Redo con identita' conservata; rigenerazione indipendente da ciascuno dei due schizzi; codec cache/no-cache e riapertura; riferimenti mancanti; piani paralleli; guardie STEP/conversione/sweep; pannello senza solidi, spunte precise, conferma e ripristino del picking/lock.

**ASan + UBSan mirati: 21 gruppi PASS** sul nuovo modulo/test kernel, collegati alla libreria kernel esistente non strumentata. `detect_leaks=0`: LeakSanitizer non e' eseguibile sotto ptrace nella sandbox (tentativo con detect_leaks=1 terminato con errore ambientale LSAN). Non e' una certificazione sanitizer dell'app completa o dei vecchi moduli kernel.

Non certificata qui la resa OpenGL nativa: display desktop non accessibile dalla sandbox, `xvfb-run` assente. Root integra e compila l'app/runner completi; un altro agente esegue QA nativa. Non viene attribuito a questa sonda l'aggiornamento dell'eseguibile finale o dell'app gia' aperta.

## Consegna e lavoro comune ancora richiesto

`manifest.json` e `FILES.txt` elencano i 18 sorgenti con SHA256; `CMAKE-INTEGRATION.md` contiene gli inserimenti CMake e dispatch test. Dopo l'integrazione iniziale, `delta-final.patch` e `delta-final-manifest.json` comprendono i quattro file definitivi (modulo, regressione, writer STEP e IGES), con impronte prima/dopo; sostituiscono il delta intermedio dei pesi. Nessun altro sorgente congelato e' cambiato. La build finale comune, CTest, QA nativa, aggiornamento mappa architetturale e memoria compatta sono coordinati da root. Nessun originale CAD, processo utente, commit o push modificato da questo agente.

## Archivio evidenze riproducibili

Le tre sonde rapide sono state ripetute sul manifest congelato: **kernel21, ASan/UBSan21 e GUI offscreen PASS, exit code0**. Log con comandi, ambiente, impronte e strumentazione in `evidence/`; riepilogo in `evidence/summary.json`, ripetizione con `run-final-evidence.py`, ricostruzione con `build-final-probes.py`. Prima della ripetizione GUI e' stato eseguito un nuovo relink includendo anche gli oggetti dei writer finali; nessun sorgente di produzione modificato.
