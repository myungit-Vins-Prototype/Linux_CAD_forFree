from pathlib import Path
import shlex,subprocess
r=Path('/tmp/forgecad-projected-curve');build=Path('/home/myungit/Linux_CAD_forFree/forgecad-release')
args=['-I'+str(r),'-I'+str(r/'kernel')]
flags=(build/'CMakeFiles/forgecad_view_tests.dir/flags.make').read_text()
for label in ('CXX_DEFINES = ', 'CXX_INCLUDES = '):
 for line in flags.splitlines():
  if line.startswith(label):args+=shlex.split(line[len(label):])
for f in ['gui_probe','cad_projected_curve','cad_feature_build']:
 print('compile',f,flush=True)
 subprocess.run(['/usr/bin/c++','-std=c++17','-O0','-Wall','-Wextra','-Wpedantic','-mno-direct-extern-access',*args,'-c',str(r/(f+'.cpp')),'-o',str(r/(f+'.o'))],check=True)
link=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text())
link=[arg for arg in link if not arg.startswith('-Wl,--dependency-file=')]
link=[str(r/'gui_probe.o') if arg=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o' else arg for arg in link]
for source in ['cad_feature_build','cad_feature_dependencies','cad_history_graph','forgeCad2026_dialogs_surfaces','forgeCad2026_gui','cad_export','cad_sketch_refs','cad_projected_curve','forgeCad2026_dialogs_projection']:
 link=[str(r/(source+'.o')) if arg=='CMakeFiles/forgecad_view_tests.dir/'+source+'.cpp.o' else arg for arg in link]
link=list(dict.fromkeys(link))
link[link.index('-o')+1]=str(r/'gui_probe')
link=[arg for arg in link if not arg.startswith('CMakeFiles/forgecad_view_tests.dir/cad_projected_curve.cpp.o') and not arg.startswith('CMakeFiles/forgecad_view_tests.dir/forgeCad2026_dialogs_projection.cpp.o')]
link=[arg for arg in link if arg not in [str(r/'cad_projected_curve.o'),str(r/'forgeCad2026_dialogs_projection.o')]]
link.extend([str(r/'cad_projected_curve.o'),str(r/'forgeCad2026_dialogs_projection.o'),str(r/'kernel/fk_sketch_projection.o')])
# Gli oggetti nuovi devono precedere la libreria statica che risolve i simboli.
extra=link[-3:];link=link[:-3];position=next(i for i,a in enumerate(link) if 'libforgekernel.a' in a);link[position:position]=extra
print('link probe',flush=True)
subprocess.run(link,cwd=build,check=True)
