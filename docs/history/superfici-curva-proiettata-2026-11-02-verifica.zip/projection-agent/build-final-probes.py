#!/usr/bin/env python3
"""Ricostruisce solo le sonde dallo snapshot congelato; nessun sorgente modificato."""
from pathlib import Path
import argparse, json, shlex, subprocess, datetime, hashlib
parser=argparse.ArgumentParser()
parser.add_argument('--repo',default='/home/myungit/Linux_CAD_forFree')
parser.add_argument('--build-dir',default='/home/myungit/Linux_CAD_forFree/forgecad-release')
parser.add_argument('--relink-gui-only',action='store_true')
options=parser.parse_args()
snapshot=Path(__file__).resolve().parent
repo=Path(options.repo);build=Path(options.build_dir)
evidence=snapshot/'evidence';evidence.mkdir(exist_ok=True)
log=[]
def run(command,cwd=None):
    entry={'command':command,'cwd':str(cwd or snapshot)}
    print('COMMAND '+shlex.join(command),flush=True)
    result=subprocess.run(command,cwd=cwd or snapshot,text=True,capture_output=True)
    entry.update(exitcode=result.returncode,stdout=result.stdout,stderr=result.stderr)
    log.append(entry)
    print(result.stdout,end='');print(result.stderr,end='')
    print('EXITCODE '+str(result.returncode),flush=True)
    (evidence/'build-final-probes.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'asan_target_instrumented_TU':['kernel/fk_sketch_projection.cpp','kernel/tests/test_sketch_projection.cpp'],'uninstrumented':['kernel/fk_step.cpp','kernel/fk_iges.cpp','libreria kernel esistente','oggetti GUI'],'commands':log},indent=2)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
base=['/usr/bin/c++','-std=c++17','-O0','-g','-Wall','-Wextra','-Wpedantic','-ffp-contract=off','-I'+str(snapshot/'kernel'),'-I'+str(repo/'kernel')]
if not options.relink_gui_only:
    for unit in ['fk_sketch_projection','fk_step','fk_iges']:
        run(base+['-c',str(snapshot/'kernel'/(unit+'.cpp')),'-o',str(snapshot/'kernel'/(unit+'.o'))])
    test=str(snapshot/'kernel/tests/test_sketch_projection.cpp')
    objects=[str(snapshot/'kernel'/(unit+'.o')) for unit in ['fk_sketch_projection','fk_step','fk_iges']]
    library=str(build/'kernel/libforgekernel.a')
    run(base+[test,*objects,library,'-lpthread','-o',str(snapshot/'kernel/tests_sketch_projection')])
    # SOLO queste due TU ricevono ASan/UBSan; i writer e la lib restano non strumentati.
    run(['/usr/bin/c++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffp-contract=off','-I'+str(snapshot/'kernel'),'-I'+str(repo/'kernel'),test,str(snapshot/'kernel/fk_sketch_projection.cpp'),*objects[1:],library,'-lpthread','-o',str(snapshot/'kernel/tests_sketch_projection_asan')])
flags=(build/'CMakeFiles/forgecad_view_tests.dir/flags.make').read_text()
qt=['-I'+str(snapshot),'-I'+str(snapshot/'kernel')]
for label in ['CXX_DEFINES = ','CXX_INCLUDES = ']:
    for line in flags.splitlines():
        if line.startswith(label):qt+=shlex.split(line[len(label):])
units=['cad_projected_curve','cad_feature_build','cad_feature_dependencies','cad_history_graph','forgeCad2026_dialogs_projection','forgeCad2026_gui','cad_export','cad_sketch_refs','forgeCad2026_dialogs_surfaces']
if not options.relink_gui_only:
    for unit in ['gui_probe',*units]:
        run(['/usr/bin/c++','-std=c++17','-O0','-g','-Wall','-Wextra','-Wpedantic','-mno-direct-extern-access','-ffp-contract=off',*qt,'-c',str(snapshot/(unit+'.cpp')),'-o',str(snapshot/(unit+'.o'))])
link=shlex.split((build/'CMakeFiles/forgecad_view_tests.dir/link.txt').read_text())
link=[arg for arg in link if not arg.startswith('-Wl,--dependency-file=')]
link=[str(snapshot/'gui_probe.o') if arg=='CMakeFiles/forgecad_view_tests.dir/tests/test_viewport.cpp.o' else arg for arg in link]
missing=[]
for unit in units:
    old='CMakeFiles/forgecad_view_tests.dir/'+unit+'.cpp.o'
    replacement=str(snapshot/(unit+'.o'))
    if old in link:link=[replacement if arg==old else arg for arg in link]
    else:missing.append(replacement)
link[link.index('-o')+1]=str(snapshot/'gui_probe')
position=next(i for i,arg in enumerate(link) if 'libforgekernel.a' in arg)
extra=[*missing,*[str(snapshot/'kernel'/(unit+'.o')) for unit in ['fk_sketch_projection','fk_step','fk_iges']]]
link[position:position]=extra
run(link,build)
print('BUILD PROBES PASS')
