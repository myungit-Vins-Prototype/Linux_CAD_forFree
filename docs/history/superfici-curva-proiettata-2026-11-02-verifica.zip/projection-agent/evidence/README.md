# Evidenze finali dello snapshot congelato

Le tre sonde sono state ripetute dopo verifica SHA256 di tutti i 18 sorgenti di `manifest.json`. Tutti gli exit code sono 0.

- `kernel-21.log`: comando, SHA del binario, ambiente, 21 gruppi PASS.
- `asan-ubsan-21.log`: comando, ambiente ASan/UBSan, SHA del binario, 21 gruppi PASS e TU strumentate.
- `gui-offscreen.log`: comando e variabili Qt/Fusion/offscreen, SHA del binario, esito GUI PASS.
- `summary.json`: riepilogo strutturato, con impronta del manifest.
- `build-final-probes.json` e `../relink-final-gui.log`: comando di relink realmente eseguito prima della ripetizione GUI; include gli oggetti dei due writer finali con guardie.

## Ripetizione rapida

```sh
python3 /tmp/forgecad-projected-curve/run-final-evidence.py
```

## Ricostruzione delle sonde

Serve la build configurata esistente `forgecad-release`, per la libreria kernel e gli oggetti applicativi non modificati; i sorgenti congelati sono presi da questa cartella temporanea.

```sh
python3 /tmp/forgecad-projected-curve/build-final-probes.py
python3 /tmp/forgecad-projected-curve/run-final-evidence.py
```

Il primo script stampa ogni comando ed exit code e salva `build-final-probes.json`; i percorsi repo/build sono sovrascrivibili con `--repo`/`--build-dir`. Non cambia i sorgenti e scrive soltanto oggetti, binari e log nella cartella dello snapshot.

Nel binario ASan/UBSan sono strumentate **soltanto** `kernel/fk_sketch_projection.cpp` e `kernel/tests/test_sketch_projection.cpp`, compilate con `-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer`. I writer `fk_step.cpp`/`fk_iges.cpp` sono oggetti non strumentati e il resto di `libforgekernel.a` e' la libreria esistente non strumentata. Le sonde kernel normale e GUI non sono strumentate. `detect_leaks=0` perche' LSAN non funziona sotto ptrace nella sandbox; non viene certificata l'assenza di leak.

La GUI offscreen non certifica rendering OpenGL nativo o build/esecuzione dell'app completa. La verifica completa finale resta quella coordinata da root.
