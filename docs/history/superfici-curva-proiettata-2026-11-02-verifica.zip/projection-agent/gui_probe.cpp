#include "forgeCad2026_dialogs.h"
#include "cad_feature_build.h"
#include "cad_feature_dependencies.h"
#include "cad_document_io.h"
#include "cad_export.h"
#include "cad_sketch_refs.h"
#include "fk_sketch_projection.h"
#include <QThread>
#include <QTemporaryDir>
#include <iostream>
#include <stdexcept>
static void require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
class ViewportInteractionTest {public:
#include "tests/test_sketch_projection_gui.h"
};
int main(int argc,char **argv){QApplication app(argc,argv);QCoreApplication::setOrganizationName("ForgeCADProjectionTest");QCoreApplication::setApplicationName("ProjectionProbe");try{ViewportInteractionTest::sketchProjection();return 0;}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}}
