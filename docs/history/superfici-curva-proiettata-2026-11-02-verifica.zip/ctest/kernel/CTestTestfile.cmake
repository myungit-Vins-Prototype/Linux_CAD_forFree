# CMake generated Testfile for 
# Source directory: /home/myungit/Linux_CAD_forFree/kernel
# Build directory: /home/myungit/Linux_CAD_forFree/forgecad-release/kernel
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("forgekernel_exchange_robustness_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_exchange_robustness_tests")
set_tests_properties("forgekernel_exchange_robustness_tests" PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;169;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_history_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_history_tests")
set_tests_properties("forgekernel_history_tests" PROPERTIES  _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;182;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_blend_probe_self_test" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_blend_probe" "--self-test")
set_tests_properties("forgekernel_blend_probe_self_test" PROPERTIES  _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;193;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_tolerance_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_tolerance_tests")
set_tests_properties("forgekernel_tolerance_tests" PROPERTIES  _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;203;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_surface_tools_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_surface_tools_tests")
set_tests_properties("forgekernel_surface_tools_tests" PROPERTIES  TIMEOUT "180" _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;210;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_blend_profile_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_blend_profile_tests")
set_tests_properties("forgekernel_blend_profile_tests" PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;218;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_face_normal_bounds_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_face_normal_bounds_tests")
set_tests_properties("forgekernel_face_normal_bounds_tests" PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;226;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
add_test("forgekernel_sketch_projection_tests" "/home/myungit/Linux_CAD_forFree/forgecad-release/kernel/forgekernel_sketch_projection_tests")
set_tests_properties("forgekernel_sketch_projection_tests" PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;233;add_test;/home/myungit/Linux_CAD_forFree/kernel/CMakeLists.txt;0;")
subdirs("occt_tests")
