#include "cad_icons.h"

#include <QFont>
#include <QApplication>
#include <QPalette>
#include <QIconEngine>
#include <QImage>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPolygonF>

#include <cmath>
#include <functional>
#include <map>

namespace ForgeCad {
namespace {

// Colori di un'icona: tratto principale, accento (l'entita' o la parte che il
// comando crea), costruzione, rimozione, conferma, e i toni delle facce dei solidi.
struct IconPalette {
    QColor ink, accent, construction, remove, confirm, faceLight, faceMid, faceDark;
};

IconPalette palette(QIcon::Mode mode) {
    const QPalette theme = QApplication::palette();
    const bool dark = theme.color(QPalette::Window).lightness() < 128;
    if (mode == QIcon::Disabled) {
        const QColor grey = theme.color(QPalette::Disabled, QPalette::WindowText);
        return {grey, grey, grey, grey, grey,
                dark ? QColor(90, 98, 105) : QColor(211, 218, 224),
                dark ? QColor(75, 82, 88) : QColor(187, 196, 205),
                dark ? QColor(62, 68, 74) : QColor(161, 174, 186)};
    }
    if (!dark)
        return {theme.color(QPalette::WindowText), QColor(184, 106, 12), QColor(36, 112, 188), QColor(194, 58, 50),
                QColor(32, 139, 70), QColor(211, 232, 247), QColor(158, 198, 226), QColor(109, 160, 199)};
    return {theme.color(QPalette::WindowText), QColor(255, 176, 74), QColor(96, 170, 255), QColor(255, 104, 96),
            QColor(96, 214, 138), QColor(150, 186, 212), QColor(104, 140, 168), QColor(72, 102, 128)};
}

using Draw = std::function<void(QPainter &, const IconPalette &)>;

// Strumenti di disegno comuni (coordinate in una griglia di 24 x 24).
QPen stroke(const QColor &color, double width = 1.6, Qt::PenStyle style = Qt::SolidLine) {
    QPen pen(color, width, style, Qt::RoundCap, Qt::RoundJoin);
    if (style == Qt::DashLine) pen.setDashPattern({2.2, 1.8});
    return pen;
}

// Badge comune ai comandi spaziali, con contrasto per entrambi i temi.
void badge3D(QPainter &p,const IconPalette &c) {
        p.save();
        p.setPen(stroke(c.accent,0.7));
        p.setBrush(c.ink.lightness()<128 ? QColor(225,235,245) : QColor(24,39,52));
        p.drawRoundedRect(QRectF(8.5,13,15,10.5),1.5,1.5);
        QFont font=QApplication::font();font.setBold(true);font.setPixelSize(9);
        p.setFont(font);p.setPen(c.ink);
        p.drawText(QRectF(8.5,13,15,10.5),Qt::AlignCenter,QStringLiteral("3D"));
        p.restore();
}

void dot(QPainter &p, const QPointF &center, const QColor &color, double radius = 1.9) {
    p.save();
    p.setPen(Qt::NoPen);
    p.setBrush(color);
    p.drawEllipse(center, radius, radius);
    p.restore();
}

void square(QPainter &p, const QPointF &center, const QColor &color, double half = 1.6) {
    p.save();
    p.setPen(Qt::NoPen);
    p.setBrush(color);
    p.drawRect(QRectF(center.x() - half, center.y() - half, 2 * half, 2 * half));
    p.restore();
}

void line(QPainter &p, const QPointF &a, const QPointF &b, const QPen &pen) {
    p.setPen(pen);
    p.drawLine(a, b);
}

void arrowHead(QPainter &p, const QPointF &tip, const QPointF &from, const QColor &color, double size = 3.6) {
    const QPointF d = tip - from;
    const double l = std::hypot(d.x(), d.y());
    if (l <= 0.0) return;
    const QPointF u = d / l, n(-u.y(), u.x());
    p.save();
    p.setPen(Qt::NoPen);
    p.setBrush(color);
    p.drawPolygon(QPolygonF({tip, tip - u * size + n * size * 0.55, tip - u * size - n * size * 0.55}));
    p.restore();
}

void polygon(QPainter &p, const QPolygonF &points, const QColor &fill, const QPen &pen) {
    p.setPen(pen);
    p.setBrush(fill);
    p.drawPolygon(points);
}

// Cubo in assonometria: facce superiore, sinistra (frontale) e destra.
// `highlight` 0/1/2 colora una faccia con l'accento (-1 nessuna); `faces`
// falso = solo spigoli; `edges` falso = solo facce.
void cube(QPainter &p, const IconPalette &c, int highlight = -1, bool faces = true, bool edges = true, double scale = 1.0,
          const QPointF &offset = QPointF()) {
    const auto at = [&](double x, double y) { return offset + QPointF(12 + (x - 12) * scale, 12 + (y - 12) * scale); };
    const QPolygonF top({at(12, 3), at(20.5, 7.2), at(12, 11.4), at(3.5, 7.2)});
    const QPolygonF left({at(3.5, 7.2), at(12, 11.4), at(12, 21), at(3.5, 16.8)});
    const QPolygonF right({at(12, 11.4), at(20.5, 7.2), at(20.5, 16.8), at(12, 21)});
    const QPolygonF polys[3] = {top, left, right};
    const QColor tones[3] = {c.faceLight, c.faceMid, c.faceDark};
    const QPen edgePen = edges ? stroke(c.ink, 1.1) : QPen(Qt::NoPen);
    for (int k = 0; k < 3; ++k) {
        QColor fill = faces ? tones[k] : QColor(Qt::transparent);
        if (k == highlight) fill = c.accent;
        polygon(p, polys[k], fill, edgePen);
    }
}

std::map<QString, Draw> &registry() {
    static std::map<QString, Draw> icons;
    if (!icons.empty()) return icons;

    // --- Schizzo: disegno ---------------------------------------------------
    icons["select"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{6, 3}, {6, 19}, {10, 15.2}, {13, 21}, {15.6, 19.8}, {12.7, 14.2}, {18, 14}}), c.ink,
                stroke(QColor(20, 30, 40), 1.0));
    };
    icons["line"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4, 19}, {20, 5}, stroke(c.accent, 1.8));
        dot(p, {4, 19}, c.ink);
        dot(p, {20, 5}, c.ink);
    };
    icons["polyline"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        const QPolygonF points({{3, 18}, {9, 6}, {15, 16}, {21, 5}});
        p.drawPolyline(points);
        for (const QPointF &point : points) dot(p, point, c.ink, 1.7);
    };
    icons["constructionLine"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4, 19}, {20, 5}, stroke(c.construction, 1.8, Qt::DashLine));
        dot(p, {4, 19}, c.ink);
        dot(p, {20, 5}, c.ink);
    };
    icons["spline"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath path({3, 17});
        path.cubicTo({7, 3}, {13, 23}, {21, 7});
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        for (const QPointF &point : {QPointF(3, 17), QPointF(10.5, 12.75), QPointF(21, 7)}) dot(p, point, c.ink, 1.7);
    };
    icons["nurbs"] = [](QPainter &p, const IconPalette &c) {
        const QPolygonF poles({{3, 19}, {7, 4}, {17, 20}, {21, 5}});
        p.setPen(stroke(c.construction, 1.0, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(poles);
        QPainterPath path(poles.at(0));
        path.cubicTo(poles.at(1), poles.at(2), poles.at(3));
        p.setPen(stroke(c.accent, 1.8));
        p.drawPath(path);
        for (const QPointF &point : poles) square(p, point, c.ink, 1.5);
    };
    icons["circle"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 8.5, 8.5);
        line(p, {12, 12}, {18, 6}, stroke(c.ink, 1.0, Qt::DashLine));
        dot(p, {12, 12}, c.ink, 1.7);
    };
    icons["arcCenter"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        QPainterPath path;
        path.arcMoveTo(QRectF(-3, 6, 22, 22), 0);
        path.arcTo(QRectF(-3, 6, 22, 22), 0, 90);
        p.drawPath(path);
        line(p, {8, 17}, {19, 17}, stroke(c.ink, 1.0, Qt::DashLine));
        line(p, {8, 17}, {8, 6}, stroke(c.ink, 1.0, Qt::DashLine));
        dot(p, {8, 17}, c.ink, 1.8);
        dot(p, {19, 17}, c.ink, 1.6);
        dot(p, {8, 6}, c.ink, 1.6);
    };
    icons["arcThreePoint"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath path;
        const QRectF box(3, 8, 18, 18);
        path.arcMoveTo(box, 20);
        path.arcTo(box, 20, 140);
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        for (const QPointF &point : {QPointF(20.46, 13.92), QPointF(12, 8), QPointF(3.54, 13.92)}) dot(p, point, c.ink, 1.8);
    };
    icons["arcTangent"] = [](QPainter &p, const IconPalette &c) {
        line(p, {2.5, 18}, {11, 18}, stroke(c.ink, 1.8));
        QPainterPath path;
        const QRectF box(4, 4, 14, 14);
        path.arcMoveTo(box, -90);
        path.arcTo(box, -90, 180);
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        dot(p, {11, 18}, c.ink, 1.8);
        dot(p, {11, 4}, c.ink, 1.6);
    };
    icons["polygon"] = [](QPainter &p, const IconPalette &c) {
        QPolygonF hexagon;
        for (int k = 0; k < 6; ++k) hexagon << QPointF(12 + 9 * std::cos(M_PI / 3 * k + M_PI / 6), 12 + 9 * std::sin(M_PI / 3 * k + M_PI / 6));
        polygon(p, hexagon, Qt::NoBrush, stroke(c.accent, 1.8));
        dot(p, {12, 12}, c.ink, 1.6);
    };
    icons["rectangle"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawRect(QRectF(4, 6, 16, 12));
        dot(p, {4, 18}, c.ink);
        dot(p, {20, 6}, c.ink);
    };
    icons["centerRectangle"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawRect(QRectF(4, 6, 16, 12));
        line(p, {12, 12}, {20, 6}, stroke(c.ink, 1.0, Qt::DashLine));
        dot(p, {12, 12}, c.ink);
        dot(p, {20, 6}, c.ink);
    };
    icons["ellipse"] = [](QPainter &p, const IconPalette &c) {
        line(p, {2.5, 12}, {21.5, 12}, stroke(c.ink, 0.9, Qt::DashLine));
        line(p, {12, 5.5}, {12, 18.5}, stroke(c.ink, 0.9, Qt::DashLine));
        p.setPen(stroke(c.accent, 1.8));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 9.5, 6);
        dot(p, {12, 12}, c.ink, 1.6);
    };

    // --- Schizzo: modifica -----------------------------------------------------
    icons["toggleConstruction"] = [](QPainter &p, const IconPalette &c) {
        line(p, {3, 14}, {12, 5}, stroke(c.accent, 1.8));
        line(p, {12, 19}, {21, 10}, stroke(c.construction, 1.8, Qt::DashLine));
        line(p, {8.5, 12.5}, {12.5, 15.5}, stroke(c.ink, 1.2));
        arrowHead(p, {13.5, 16.3}, {8.5, 12.5}, c.ink, 3.0);
        arrowHead(p, {7.5, 11.7}, {12.5, 15.5}, c.ink, 3.0);
    };
    icons["trim"] = [](QPainter &p, const IconPalette &c) {
        line(p, {12, 3}, {12, 21}, stroke(c.ink, 1.8));
        line(p, {3, 12}, {12, 12}, stroke(c.accent, 1.8));
        line(p, {12, 12}, {21, 12}, stroke(c.remove, 1.8, Qt::DashLine));
        line(p, {16, 8}, {20, 16}, stroke(c.remove, 1.2));
        line(p, {20, 8}, {16, 16}, stroke(c.remove, 1.2));
    };
    icons["extend"] = [](QPainter &p, const IconPalette &c) {
        line(p, {20, 3}, {20, 21}, stroke(c.ink, 1.8));
        line(p, {3, 12}, {10, 12}, stroke(c.accent, 1.8));
        line(p, {10, 12}, {16, 12}, stroke(c.accent, 1.4, Qt::DashLine));
        arrowHead(p, {19.2, 12}, {12, 12}, c.accent);
    };
    icons["split"] = [](QPainter &p, const IconPalette &c) {
        line(p, {3, 18}, {10.2, 13.2}, stroke(c.accent, 1.8));
        line(p, {13.8, 10.8}, {21, 6}, stroke(c.accent, 1.8));
        line(p, {8.5, 5.5}, {15.5, 18.5}, stroke(c.ink, 1.0, Qt::DashLine));
        dot(p, {10.2, 13.2}, c.ink, 1.7);
        dot(p, {13.8, 10.8}, c.ink, 1.7);
    };
    icons["sketchFillet"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink, 0.9, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{5, 12}, {5, 5}, {12, 5}}));
        line(p, {5, 21}, {5, 12}, stroke(c.ink, 1.8));
        line(p, {12, 5}, {21, 5}, stroke(c.ink, 1.8));
        QPainterPath path;
        const QRectF box(5, 5, 14, 14);
        path.arcMoveTo(box, 180);
        path.arcTo(box, 180, -90);
        p.setPen(stroke(c.accent, 1.9));
        p.drawPath(path);
    };
    icons["sketchChamfer"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink, 0.9, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{5, 12}, {5, 5}, {12, 5}}));
        line(p, {5, 21}, {5, 12}, stroke(c.ink, 1.8));
        line(p, {12, 5}, {21, 5}, stroke(c.ink, 1.8));
        line(p, {5, 12}, {12, 5}, stroke(c.accent, 1.9));
    };

    // --- Schizzo: vincoli e quote ------------------------------------------------
    icons["constraints"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink, 1.2));
        p.setBrush(QColor(255, 255, 255, 18));
        p.drawRoundedRect(QRectF(2.5, 3.5, 19, 17), 2.5, 2.5);
        line(p, {5.5, 16.5}, {11.5, 16.5}, stroke(c.accent, 1.6));
        line(p, {8.5, 16.5}, {8.5, 8}, stroke(c.accent, 1.6));
        line(p, {13.5, 16.5}, {15.5, 8}, stroke(c.accent, 1.6));
        line(p, {16.8, 16.5}, {18.8, 8}, stroke(c.accent, 1.6));
    };
    icons["dimension"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4.5, 7}, {4.5, 20}, stroke(c.ink, 1.1));
        line(p, {19.5, 7}, {19.5, 20}, stroke(c.ink, 1.1));
        line(p, {6, 11}, {18, 11}, stroke(c.accent, 1.3));
        arrowHead(p, {4.8, 11}, {10, 11}, c.accent);
        arrowHead(p, {19.2, 11}, {14, 11}, c.accent);
        line(p, {4.5, 17}, {19.5, 17}, stroke(c.ink, 1.8));
    };
    const auto letter = [](const QString &text, bool framed) {
        return [text, framed](QPainter &p, const IconPalette &c) {
            if (framed) {
                p.setPen(stroke(c.ink, 1.1));
                p.setBrush(QColor(255, 255, 255, 18));
                p.drawRoundedRect(QRectF(3, 3, 18, 18), 3, 3);
            }
            QFont font;
            font.setPixelSize(13);
            font.setBold(true);
            p.setFont(font);
            p.setPen(c.accent);
            p.drawText(QRectF(3, 3, 18, 18), Qt::AlignCenter, text);
        };
    };
    icons["constraintAuto"] = letter(QStringLiteral("A"), true);
    icons["constraintFree"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4, 19}, {20, 5}, stroke(c.accent, 1.8));
        p.setPen(stroke(c.ink, 1.1));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(7, 7), 3.5, 3.5);
        line(p, {4.5, 9.5}, {9.5, 4.5}, stroke(c.ink, 1.1));
    };
    icons["constraintHorizontal"] = [](QPainter &p, const IconPalette &c) {
        line(p, {3, 15}, {21, 15}, stroke(c.accent, 1.8));
        dot(p, {3, 15}, c.ink, 1.6);
        dot(p, {21, 15}, c.ink, 1.6);
        QFont font;
        font.setPixelSize(10);
        font.setBold(true);
        p.setFont(font);
        p.setPen(c.ink);
        p.drawText(QRectF(6, 1, 12, 11), Qt::AlignCenter, QStringLiteral("H"));
    };
    icons["constraintVertical"] = [](QPainter &p, const IconPalette &c) {
        line(p, {9, 3}, {9, 21}, stroke(c.accent, 1.8));
        dot(p, {9, 3}, c.ink, 1.6);
        dot(p, {9, 21}, c.ink, 1.6);
        QFont font;
        font.setPixelSize(10);
        font.setBold(true);
        p.setFont(font);
        p.setPen(c.ink);
        p.drawText(QRectF(11, 6, 11, 12), Qt::AlignCenter, QStringLiteral("V"));
    };
    icons["constraintLength"] = [](QPainter &p, const IconPalette &c) {
        line(p, {3, 18}, {21, 18}, stroke(c.ink, 1.8));
        line(p, {5, 11}, {19, 11}, stroke(c.accent, 1.2));
        arrowHead(p, {3.5, 11}, {9, 11}, c.accent, 3.2);
        arrowHead(p, {20.5, 11}, {15, 11}, c.accent, 3.2);
        line(p, {3, 8}, {3, 16}, stroke(c.ink, 1.0));
        line(p, {21, 8}, {21, 16}, stroke(c.ink, 1.0));
        QFont font;
        font.setPixelSize(8);
        font.setBold(true);
        p.setFont(font);
        p.setPen(c.ink);
        p.drawText(QRectF(4, 1, 16, 8), Qt::AlignCenter, QStringLiteral("L"));
    };
    icons["constraintAngle"] = [](QPainter &p, const IconPalette &c) {
        line(p, {3, 20}, {21, 20}, stroke(c.ink, 1.8));
        line(p, {3, 20}, {17, 5}, stroke(c.ink, 1.8));
        QPainterPath path;
        const QRectF box(-7, 10, 20, 20);
        path.arcMoveTo(box, 0);
        path.arcTo(box, 0, 47);
        p.setPen(stroke(c.accent, 1.5));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
    };
    icons["snap"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath path({6, 4});
        path.lineTo(6, 12);
        path.arcTo(QRectF(6, 6, 12, 12), 180, 180);
        path.lineTo(18, 4);
        p.setPen(stroke(c.remove, 3.4));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        line(p, {6, 3}, {6, 6.5}, QPen(c.ink, 3.4, Qt::SolidLine, Qt::FlatCap));
        line(p, {18, 3}, {18, 6.5}, QPen(c.ink, 3.4, Qt::SolidLine, Qt::FlatCap));
        dot(p, {12, 21.5}, c.accent, 1.6);
    };
    icons["gridSnap"] = [](QPainter &p, const IconPalette &c) {
        const QPen grid = stroke(c.ink, 1.0);
        for (double x : {4.0, 12.0, 20.0}) line(p, {x, 3}, {x, 21}, grid);
        for (double y : {4.0, 12.0, 20.0}) line(p, {3, y}, {21, y}, grid);
        p.setPen(stroke(c.accent, 1.6));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 4, 4);
        dot(p, {12, 12}, c.accent, 1.8);
    };
    icons["originSnap"] = [](QPainter &p, const IconPalette &c) {
        line(p, {12, 2.5}, {12, 21.5}, stroke(c.ink, 1.0));
        line(p, {2.5, 12}, {21.5, 12}, stroke(c.ink, 1.0));
        p.setPen(stroke(c.accent, 1.6));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 5, 5);
        dot(p, {12, 12}, c.accent, 1.8);
    };
    icons["polygonSides"] = [](QPainter &p, const IconPalette &c) {
        QPolygonF pentagon;
        for (int k = 0; k < 5; ++k) pentagon << QPointF(10 + 7.5 * std::cos(2 * M_PI / 5 * k - M_PI / 2), 11 + 7.5 * std::sin(2 * M_PI / 5 * k - M_PI / 2));
        polygon(p, pentagon, Qt::NoBrush, stroke(c.accent, 1.6));
        QFont font;
        font.setPixelSize(9);
        font.setBold(true);
        p.setFont(font);
        p.setPen(c.ink);
        p.drawText(QRectF(13, 13, 11, 11), Qt::AlignCenter, QStringLiteral("n"));
    };
    icons["exitSketch"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.confirm, 3.0));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{4.5, 12.5}, {10, 18}, {20, 6}}));
    };

    // --- Documento e modifica -------------------------------------------------
    icons["new"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{5, 2.5}, {14, 2.5}, {19, 7.5}, {19, 21.5}, {5, 21.5}}), QColor(255, 255, 255, 25), stroke(c.ink, 1.3));
        p.setPen(stroke(c.ink, 1.1));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{14, 2.5}, {14, 7.5}, {19, 7.5}}));
        line(p, {12, 11}, {12, 18}, stroke(c.accent, 1.7));
        line(p, {8.5, 14.5}, {15.5, 14.5}, stroke(c.accent, 1.7));
    };
    icons["open"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{2.5, 5}, {9, 5}, {11, 7.5}, {20, 7.5}, {20, 19}, {2.5, 19}}), c.faceMid, stroke(c.ink, 1.2));
        polygon(p, QPolygonF({{5, 11}, {22, 11}, {19.5, 19}, {2.5, 19}}), c.accent, stroke(c.ink, 1.2));
    };
    icons["save"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{3, 3}, {18, 3}, {21, 6}, {21, 21}, {3, 21}}), c.faceMid, stroke(c.ink, 1.2));
        polygon(p, QPolygonF({{7, 3}, {16, 3}, {16, 9}, {7, 9}}), c.faceLight, QPen(Qt::NoPen));
        polygon(p, QPolygonF({{6, 13}, {18, 13}, {18, 21}, {6, 21}}), QColor(235, 240, 244), QPen(Qt::NoPen));
        square(p, {13.5, 6}, c.faceDark, 1.3);
        line(p, {8, 16}, {16, 16}, stroke(c.faceMid, 1.0));
        line(p, {8, 18.5}, {16, 18.5}, stroke(c.faceMid, 1.0));
    };
    const auto curvedArrow = [](bool redo) {
        return [redo](QPainter &p, const IconPalette &c) {
            p.save();
            if (redo) {
                p.translate(24, 0);
                p.scale(-1, 1);
            }
            QPainterPath path({8, 8});
            path.lineTo(14, 8);
            path.cubicTo({22, 8}, {22, 19}, {14, 19});
            path.lineTo(7, 19);
            p.setPen(stroke(c.ink, 2.0));
            p.setBrush(Qt::NoBrush);
            p.drawPath(path);
            arrowHead(p, {3, 8}, {9, 8}, c.accent, 5.0);
            p.restore();
        };
    };
    icons["undo"] = curvedArrow(false);
    icons["redo"] = curvedArrow(true);
    icons["rebuild"] = [](QPainter &p, const IconPalette &c) {
        // Due frecce in cerchio (ricalcolo) attorno a un cubo (in arancio).
        polygon(p, QPolygonF({{9, 10}, {15, 10}, {15, 16}, {9, 16}}), c.faceMid, stroke(c.accent, 1.4));
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.7));
        p.drawArc(QRectF(3.5, 3.5, 17, 17), 30 * 16, 150 * 16);
        p.drawArc(QRectF(3.5, 3.5, 17, 17), 210 * 16, 150 * 16);
        polygon(p, QPolygonF({{19.8, 5.2}, {20.8, 10.5}, {15.6, 9.2}}), c.ink, Qt::NoPen);
        polygon(p, QPolygonF({{4.2, 18.8}, {3.2, 13.5}, {8.4, 14.8}}), c.ink, Qt::NoPen);
    };
    icons["delete"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4, 6}, {20, 6}, stroke(c.ink, 1.6));
        line(p, {9.5, 6}, {10, 3.5}, stroke(c.ink, 1.4));
        line(p, {10, 3.5}, {14, 3.5}, stroke(c.ink, 1.4));
        line(p, {14, 3.5}, {14.5, 6}, stroke(c.ink, 1.4));
        polygon(p, QPolygonF({{6, 8}, {18, 8}, {17, 21}, {7, 21}}), QColor(255, 104, 96, 60), stroke(c.remove, 1.4));
        line(p, {10, 11}, {10.3, 18}, stroke(c.remove, 1.1));
        line(p, {14, 11}, {13.7, 18}, stroke(c.remove, 1.1));
    };
    icons["edit"] = [](QPainter &p, const IconPalette &c) {
        p.save();
        p.translate(12, 12);
        p.rotate(-45);
        polygon(p, QPolygonF({{-2.4, -8}, {2.4, -8}, {2.4, 6}, {0, 9}, {-2.4, 6}}), c.accent, stroke(c.ink, 1.1));
        line(p, {-2.4, -4.5}, {2.4, -4.5}, stroke(c.ink, 1.0));
        p.restore();
    };
    icons["visibility"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath eye(QPointF(2.5, 12));
        eye.cubicTo({6, 5.5}, {18, 5.5}, {21.5, 12});
        eye.cubicTo({18, 18.5}, {6, 18.5}, {2.5, 12});
        p.setPen(stroke(c.ink, 1.4));
        p.setBrush(c.faceDark);
        p.drawPath(eye);
        dot(p, {12, 12}, c.accent, 3.2);
        dot(p, {12, 12}, c.faceDark, 1.2);
    };
    icons["rename"] = [](QPainter &p, const IconPalette &c) {
        line(p, {4, 5}, {15, 5}, stroke(c.ink, 1.2));
        line(p, {9.5, 5}, {9.5, 17}, stroke(c.ink, 2.0));
        line(p, {6.5, 17}, {12.5, 17}, stroke(c.ink, 1.2));
        line(p, {4, 20}, {20, 20}, stroke(c.accent, 2.0));
        arrowHead(p, {20, 20}, {14, 20}, c.accent, 3.2);
    };
    icons["meshColor"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c, -1, true, true, 0.72, QPointF(-3, -1));
        dot(p, {17.5, 16.5}, c.accent, 4.3);
        dot(p, {17.5, 16.5}, c.construction, 2.0);
    };

    // --- Modellazione ---------------------------------------------------------
    icons["newSketch"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{1.5, 19}, {7.5, 13}, {22.5, 13}, {16.5, 19}}), QColor(96, 170, 255, 70), stroke(c.construction, 1.2));
        p.save();
        p.translate(14, 11);
        p.rotate(-50);
        polygon(p, QPolygonF({{-1.8, -9}, {1.8, -9}, {1.8, 3}, {0, 6}, {-1.8, 3}}), c.accent, stroke(QColor(40, 30, 20), 0.8));
        p.restore();
        dot(p, {9.3, 15.5}, c.ink, 1.1);
    };
    // Etichetta distinta per lo schizzo spaziale, leggibile anche nell'albero.
    icons["newSketch3D"] = [sketch=icons["newSketch"]](QPainter &p, const IconPalette &c) {
        sketch(p,c);
        badge3D(p,c);
    };
    icons["faceSketch"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c, 0, true, true, 0.85, QPointF(-2, 2));
        p.save();
        p.translate(17, 7);
        p.rotate(-40);
        polygon(p, QPolygonF({{-1.6, -6.5}, {1.6, -6.5}, {1.6, 3}, {0, 5.5}, {-1.6, 3}}), c.ink, stroke(QColor(20, 30, 40), 0.8));
        p.restore();
    };
    icons["extrude"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{3, 12}, {12, 12}, {12, 21}, {3, 21}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{3, 12}, {7, 8}, {16, 8}, {12, 12}}), c.faceLight, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 12}, {16, 8}, {16, 17}, {12, 21}}), c.faceDark, stroke(c.ink, 1.0));
        line(p, {3, 21}, {12, 21}, stroke(c.accent, 1.8));
        line(p, {20.5, 21}, {20.5, 7}, stroke(c.accent, 1.8));
        arrowHead(p, {20.5, 2.5}, {20.5, 8}, c.accent, 4.2);
    };
    // Inverti il verso: il piano dello schizzo e le due frecce opposte.
    icons["reverseDirection"] = [](QPainter &p, const IconPalette &c) {
        line(p, {2.5, 12}, {21.5, 12}, stroke(c.ink, 1.4));
        line(p, {8, 12}, {8, 6}, stroke(c.accent, 1.8));
        arrowHead(p, {8, 2}, {8, 7}, c.accent, 4.0);
        line(p, {16, 12}, {16, 18}, stroke(c.construction, 1.8));
        arrowHead(p, {16, 22}, {16, 17}, c.construction, 4.0);
    };
    icons["revolve"] = [](QPainter &p, const IconPalette &c) {
        line(p, {8, 1.5}, {8, 22.5}, stroke(c.construction, 1.1, Qt::DashLine));
        polygon(p, QPolygonF({{10.5, 6}, {15, 6}, {17, 11}, {15, 17}, {10.5, 17}}), c.faceMid, stroke(c.ink, 1.1));
        QPainterPath path;
        const QRectF box(0.5, 16, 15, 6);
        path.arcMoveTo(box, 200);
        path.arcTo(box, 200, 150);
        p.setPen(stroke(c.accent, 1.7));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        arrowHead(p, {15.6, 17.6}, {14, 21}, c.accent, 4.0);
    };
    icons["fillet"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath body({3, 21});
        body.lineTo(3, 12);
        body.arcTo(QRectF(3, 3, 18, 18), 180, -90);
        body.lineTo(21, 3);
        body.lineTo(21, 21);
        body.closeSubpath();
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(body);
        p.setPen(stroke(c.ink, 1.0, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{3, 11}, {3, 3}, {11, 3}}));
        QPainterPath arc;
        arc.arcMoveTo(QRectF(3, 3, 18, 18), 180);
        arc.arcTo(QRectF(3, 3, 18, 18), 180, -90);
        p.setPen(stroke(c.accent, 2.6));
        p.drawPath(arc);
    };
    icons["chamfer"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{3, 21}, {3, 12}, {12, 3}, {21, 3}, {21, 21}}), c.faceMid, stroke(c.ink, 1.0));
        p.setPen(stroke(c.ink, 1.0, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPolyline(QPolygonF({{3, 11}, {3, 3}, {11, 3}}));
        line(p, {3, 12}, {12, 3}, stroke(c.accent, 2.6));
    };
    const auto booleanIcon = [](int operation) {
        return [operation](QPainter &p, const IconPalette &c) {
            QPainterPath a, b;
            a.addEllipse(QPointF(9, 12), 6.8, 6.8);
            b.addEllipse(QPointF(15, 12), 6.8, 6.8);
            const QPainterPath result = operation == 0 ? a.united(b) : operation == 1 ? a.intersected(b) : a.subtracted(b);
            p.setPen(Qt::NoPen);
            p.setBrush(c.accent);
            p.drawPath(result);
            p.setBrush(Qt::NoBrush);
            p.setPen(stroke(c.ink, 1.1));
            p.drawPath(a);
            p.setPen(stroke(c.ink, 1.1, operation == 2 ? Qt::DashLine : Qt::SolidLine));
            p.drawPath(b);
        };
    };
    icons["union"] = booleanIcon(0);
    icons["intersection"] = booleanIcon(1);
    icons["difference"] = booleanIcon(2);
    icons["trimSurface"] = [](QPainter &p, const IconPalette &c) {
        // Superficie divisa da una curva: la parte tenuta piena, quella tolta tratteggiata.
        QPainterPath kept({3, 9});
        kept.lineTo(10, 6);
        kept.cubicTo({11, 11}, {9, 15}, {12, 20});
        kept.lineTo(5, 21);
        kept.closeSubpath();
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(kept);
        QPainterPath removed({10, 6});
        removed.lineTo(20, 3);
        removed.lineTo(21, 17);
        removed.lineTo(12, 20);
        p.setPen(stroke(c.ink, 1.0, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawPath(removed);
        QPainterPath cut({10, 6});
        cut.cubicTo({11, 11}, {9, 15}, {12, 20});
        p.setPen(stroke(c.remove, 2.0));
        p.drawPath(cut);
    };
    icons["extendSurface"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{2, 9}, {12, 6}, {12, 19}, {2, 21}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 6}, {21, 3.5}, {21, 16.5}, {12, 19}}), QColor(255, 176, 74, 60), stroke(c.accent, 1.2, Qt::DashLine));
        line(p, {12, 6}, {12, 19}, stroke(c.accent, 2.0));
        line(p, {13.5, 12.5}, {18, 11.3}, stroke(c.accent, 1.4));
        arrowHead(p, {20, 10.8}, {14, 12.4}, c.accent, 3.4);
    };
    icons["offsetSurface"] = [](QPainter &p, const IconPalette &c) {
        // Una superficie curva e la sua copia a distanza, con la freccia della normale.
        QPainterPath base;
        base.moveTo(2, 18);
        base.cubicTo(7, 11, 14, 22, 21, 14);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.8));
        p.drawPath(base);
        QPainterPath copy;
        copy.moveTo(2, 10);
        copy.cubicTo(7, 3, 14, 14, 21, 6);
        p.setPen(stroke(c.accent, 1.8));
        p.drawPath(copy);
        line(p, {11.5, 16.5}, {11.5, 10.5}, stroke(c.accent, 1.2));
        arrowHead(p, {11.5, 8.6}, {11.5, 13}, c.accent, 3.0);
    };
    icons["draft"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{3, 21}, {7, 5}, {17, 5}, {21, 21}}), c.faceMid, stroke(c.ink, 1.2));
        p.setPen(stroke(c.accent, 1.6));
        p.drawLine(QPointF(2, 21), QPointF(22, 21));
        p.drawLine(QPointF(12, 17), QPointF(12, 2));
        p.drawLine(QPointF(12, 2), QPointF(9, 6));
        p.drawLine(QPointF(12, 2), QPointF(15, 6));
    };
    icons["thicken"] = [](QPainter &p, const IconPalette &c) {
        // Superficie curva (sotto) e la sua copia sopra: la lastra tra le due, con la freccia dello spessore.
        QPainterPath slab;
        slab.moveTo(2, 19);
        slab.cubicTo(8, 13, 15, 22, 22, 15);
        slab.lineTo(22, 9);
        slab.cubicTo(15, 16, 8, 7, 2, 13);
        slab.closeSubpath();
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(255, 176, 74, 70));
        p.drawPath(slab);
        QPainterPath base;
        base.moveTo(2, 19);
        base.cubicTo(8, 13, 15, 22, 22, 15);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.8));
        p.drawPath(base);
        QPainterPath top;
        top.moveTo(2, 13);
        top.cubicTo(8, 7, 15, 16, 22, 9);
        p.setPen(stroke(c.accent, 1.8));
        p.drawPath(top);
        line(p, {2, 13}, {2, 19}, stroke(c.accent, 1.2));
        line(p, {22, 9}, {22, 15}, stroke(c.accent, 1.2));
        line(p, {12, 16.5}, {12, 7}, stroke(c.accent, 1.2));
        arrowHead(p, {12, 4.6}, {12, 9}, c.accent, 3.0);
    };
    icons["projectedCurve"] = [](QPainter &p, const IconPalette &c) {
        // Curva dello schizzo in alto proiettata sulla superficie (arancio).
        QPainterPath sketch;
        sketch.moveTo(4, 5);
        sketch.cubicTo(8, 1.5, 15, 7.5, 20, 3.5);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.construction, 1.3, Qt::DashLine));
        p.drawPath(sketch);
        QPainterPath surface;
        surface.moveTo(2, 18);
        surface.cubicTo(7, 12, 17, 12, 22, 18);
        surface.lineTo(22, 22);
        surface.lineTo(2, 22);
        surface.closeSubpath();
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(surface);
        QPainterPath curve;
        curve.moveTo(4, 16.3);
        curve.cubicTo(8, 12.4, 15, 15.4, 20, 15.2);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.accent, 2.0));
        p.drawPath(curve);
        line(p, {12, 6.5}, {12, 12}, stroke(c.accent, 1.1));
        arrowHead(p, {12, 13.4}, {12, 9}, c.accent, 2.6);
    };
    icons["shell"] = [](QPainter &p, const IconPalette &c) {
        // Scatola svuotata e aperta in alto: il bordo delle pareti in arancio.
        polygon(p, QPolygonF({{3, 9}, {12, 13}, {12, 22}, {3, 18}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 13}, {21, 9}, {21, 18}, {12, 22}}), c.faceDark, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{3, 9}, {12, 5}, {21, 9}, {12, 13}}), c.faceLight, stroke(c.accent, 1.4));
        polygon(p, QPolygonF({{6, 9}, {12, 6.4}, {18, 9}, {12, 11.6}}), c.faceDark, stroke(c.accent, 1.2));
    };
    icons["boundarySurface"] = [](QPainter &p, const IconPalette &c) {
        // Patch curva tesa tra quattro curve del contorno (in arancio).
        QPainterPath patch;
        patch.moveTo(3, 15);
        patch.cubicTo(6, 9, 9, 7, 12, 4);
        patch.cubicTo(15, 7, 18, 8, 21, 10);
        patch.cubicTo(19, 14, 18, 17, 17, 21);
        patch.cubicTo(12, 20, 8, 18, 3, 15);
        p.setPen(Qt::NoPen);
        p.setBrush(c.faceMid);
        p.drawPath(patch);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.accent, 1.8));
        p.drawPath(patch);
        // Isoparametriche interne.
        QPainterPath iso;
        iso.moveTo(7.5, 9.5);
        iso.cubicTo(10, 12, 12, 17, 12.5, 19.5);
        iso.moveTo(5, 13);
        iso.cubicTo(10, 11.5, 15, 11, 19.5, 12.5);
        p.setPen(stroke(c.ink, 0.9));
        p.drawPath(iso);
    };
    icons["fillSurface"] = [](QPainter &p, const IconPalette &c) {
        // Bordo di una superficie esistente (in basso) chiuso da una calotta
        // (in arancio) che passa per due curve guida incrociate.
        QPainterPath wall;
        wall.moveTo(3, 15);
        wall.cubicTo(3, 18, 4, 20, 5, 22);
        wall.lineTo(19, 22);
        wall.cubicTo(20, 20, 21, 18, 21, 15);
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceDark);
        p.drawPath(wall);
        QPainterPath cap;
        cap.moveTo(3, 15);
        cap.cubicTo(3, 6, 21, 6, 21, 15);
        cap.cubicTo(17, 18, 7, 18, 3, 15);
        p.setPen(Qt::NoPen);
        p.setBrush(c.faceMid);
        p.drawPath(cap);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.accent, 1.8));
        p.drawPath(cap);
        QPainterPath guides;
        guides.moveTo(5.5, 13);
        guides.cubicTo(9, 7.5, 15, 7.5, 18.5, 13);
        guides.moveTo(12, 16.7);
        guides.cubicTo(11.5, 13, 11.5, 10, 12, 8.3);
        p.setPen(stroke(c.ink, 0.9));
        p.drawPath(guides);
    };
    icons["copyFaces"] = [](QPainter &p, const IconPalette &c) {
        // Stesso cubo di Elimina facce, con la faccia originale colorata
        // e una seconda faccia uguale sollevata sopra il corpo.
        polygon(p, QPolygonF({{3, 11}, {12, 15}, {12, 22}, {3, 18}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 15}, {21, 11}, {21, 18}, {12, 22}}), c.faceDark, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{3, 11}, {12, 7}, {21, 11}, {12, 15}}), c.accent.lighter(125), stroke(c.ink, 1.0));
        line(p, {3, 11}, {3, 5}, stroke(c.construction, 0.8, Qt::DashLine));
        line(p, {21, 11}, {21, 5}, stroke(c.construction, 0.8, Qt::DashLine));
        polygon(p, QPolygonF({{3, 5}, {12, 1}, {21, 5}, {12, 9}}), c.accent, stroke(c.ink, 1.0));
    };
    icons["deleteFace"] = [](QPainter &p, const IconPalette &c) {
        // Un cubo aperto: la faccia superiore tolta (tratteggiata in rosso) e la croce.
        polygon(p, QPolygonF({{3, 9}, {12, 13}, {12, 22}, {3, 18}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 13}, {21, 9}, {21, 18}, {12, 22}}), c.faceDark, stroke(c.ink, 1.0));
        QPen dashed = stroke(c.remove, 1.3);
        dashed.setStyle(Qt::DashLine);
        p.setBrush(Qt::NoBrush);
        p.setPen(dashed);
        p.drawPolygon(QPolygonF({{3, 9}, {12, 5}, {21, 9}, {12, 13}}));
        line(p, {9, 3.5}, {15, 9.5}, stroke(c.remove, 1.8));
        line(p, {15, 3.5}, {9, 9.5}, stroke(c.remove, 1.8));
    };
    icons["sewSurfaces"] = [](QPainter &p, const IconPalette &c) {
        // Due superfici che si toccano lungo un bordo cucito.
        polygon(p, QPolygonF({{2, 8}, {12, 4}, {12, 17}, {2, 21}}), c.faceMid, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{12, 4}, {22, 8}, {22, 21}, {12, 17}}), c.faceDark, stroke(c.ink, 1.0));
        line(p, {12, 4}, {12, 17}, stroke(c.accent, 2.2));
        for (double y : {6.5, 10.5, 14.5}) line(p, {10, y}, {14, y + 1.5}, stroke(c.accent, 1.2));
    };
    icons["ruledSurface"] = [](QPainter &p, const IconPalette &c) {
        // Superficie tra due curve: le rette della rigata dall'una all'altra.
        QPainterPath top({3, 7}), bottom({3, 18});
        top.cubicTo({8, 2}, {15, 10}, {21, 4});
        bottom.cubicTo({9, 21}, {14, 14}, {21, 19});
        QPainterPath face = top;
        face.lineTo(21, 19);
        face.cubicTo({14, 14}, {9, 21}, {3, 18});
        face.closeSubpath();
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(255, 176, 74, 70));
        p.drawPath(face);
        for (double t : {0.0, 0.25, 0.5, 0.75, 1.0}) {
            const QPointF a = top.pointAtPercent(t), b = bottom.pointAtPercent(t);
            line(p, a, b, stroke(c.accent, 1.0));
        }
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.8));
        p.drawPath(top);
        p.drawPath(bottom);
    };
    icons["planarSurface"] = [](QPainter &p, const IconPalette &c) {
        // Lamina piana che riempie un contorno chiuso, con un foro.
        QPainterPath face;
        face.addPolygon(QPolygonF({{2, 17}, {8, 5}, {22, 5}, {16, 17}}));
        face.closeSubpath();
        QPainterPath hole;
        hole.addEllipse(QRectF(9.5, 8.6, 5.5, 4.4));
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(255, 176, 74, 90));
        p.drawPath(face.subtracted(hole));
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.6));
        p.drawPath(face);
        p.setPen(stroke(c.ink, 1.2));
        p.drawEllipse(QRectF(9.5, 8.6, 5.5, 4.4));
        line(p, {4, 21}, {14, 21}, stroke(c.accent, 1.4));
    };
    icons["loftSurface"] = [](QPainter &p, const IconPalette &c) {
        // Loft senza coperchi: il fianco tra il cerchio in basso e il quadrato in alto, aperto.
        polygon(p, QPolygonF({{4, 17}, {7, 5}, {17, 5}, {20, 17}}), QColor(255, 176, 74, 70), QPen(Qt::NoPen));
        line(p, {4, 17}, {7, 5}, stroke(c.accent, 1.4));
        line(p, {20, 17}, {17, 5}, stroke(c.accent, 1.4));
        line(p, {12, 19.5}, {12, 3}, stroke(c.accent, 0.9, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.4));
        p.drawRect(QRectF(7, 3, 10, 4));
        p.drawEllipse(QRectF(4, 14.5, 16, 5));
    };
    icons["sweepSurface"] = [](QPainter &p, const IconPalette &c) {
        // Tubo aperto lungo un percorso: il profilo e' solo un bordo.
        QPainterPath path({4, 19});
        path.cubicTo({8, 8}, {14, 20}, {20, 6});
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(QColor(255, 176, 74, 90), 7.0));
        p.drawPath(path);
        p.setPen(stroke(c.accent, 1.0));
        p.drawPath(path);
        p.setPen(stroke(c.ink, 1.6));
        p.drawEllipse(QRectF(0.8, 15.5, 6.4, 6.4));
        p.drawEllipse(QRectF(16.8, 2.8, 6.4, 6.4));
    };
    icons["sketchMove"] = [](QPainter &p, const IconPalette &c) {
        // Un segmento (grigio) e la sua posizione nuova (arancio), con la freccia dello spostamento.
        line(p, {3, 20}, {10, 13}, stroke(c.ink, 1.8));
        line(p, {13, 11}, {20, 4}, stroke(c.accent, 1.8, Qt::DashLine));
        line(p, {8, 21}, {18, 11}, stroke(c.ink, 1.2));
        arrowHead(p, {19.5, 9.5}, {15, 14}, c.accent, 3.4);
    };
    icons["sketchOffset"] = [](QPainter &p, const IconPalette &c) {
        // Una catena di segmenti e la sua parallela tratteggiata.
        p.setBrush(Qt::NoBrush);
        QPainterPath chain;
        chain.moveTo(3, 20);
        chain.lineTo(3, 11);
        chain.arcTo(QRectF(3, 6, 10, 10), 180, -90);
        chain.lineTo(20, 6);
        p.setPen(stroke(c.ink, 1.8));
        p.drawPath(chain);
        QPainterPath copy;
        copy.moveTo(6, 20);
        copy.lineTo(6, 11);
        copy.arcTo(QRectF(6, 9, 4, 4), 180, -90);
        copy.lineTo(20, 9);
        p.setPen(stroke(c.accent, 1.6, Qt::DashLine));
        p.drawPath(copy);
    };
    // --- Ripetizioni (schizzo: entita' piane; funzioni: cubi) --------------------
    icons["sketchPatternLinear"] = [](QPainter &p, const IconPalette &c) {
        // Un cerchio pieno e le sue copie tratteggiate lungo una freccia.
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.7));
        p.drawEllipse(QPointF(5.5, 15), 3, 3);
        p.setPen(stroke(c.accent, 1.5, Qt::DashLine));
        p.drawEllipse(QPointF(12, 15), 3, 3);
        p.drawEllipse(QPointF(18.5, 15), 3, 3);
        line(p, {4, 7}, {18, 7}, stroke(c.accent, 1.3));
        arrowHead(p, {21, 7}, {16, 7}, c.accent, 3.4);
    };
    icons["sketchPatternCircular"] = [](QPainter &p, const IconPalette &c) {
        // Sei piccoli cerchi attorno a un centro.
        dot(p, {12, 12}, c.ink, 1.5);
        p.setBrush(Qt::NoBrush);
        for (int k = 0; k < 6; ++k) {
            const double a = k * M_PI / 3.0 - M_PI / 2.0;
            p.setPen(k == 0 ? stroke(c.ink, 1.6) : stroke(c.accent, 1.3, Qt::DashLine));
            p.drawEllipse(QPointF(12 + 7.5 * std::cos(a), 12 + 7.5 * std::sin(a)), 2.3, 2.3);
        }
    };
    icons["sketchMirror"] = [](QPainter &p, const IconPalette &c) {
        // Retta di simmetria e un triangolo con la sua immagine.
        line(p, {12, 2.5}, {12, 21.5}, stroke(c.construction, 1.1, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 1.7));
        p.drawPolygon(QPolygonF({{9.5, 6}, {9.5, 18}, {3, 18}}));
        p.setPen(stroke(c.accent, 1.5, Qt::DashLine));
        p.drawPolygon(QPolygonF({{14.5, 6}, {14.5, 18}, {21, 18}}));
    };
    icons["patternLinear"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c, -1, true, true, 0.42, QPointF(-6.5, 3));
        cube(p, c, 0, true, true, 0.42, QPointF(0, 3));
        cube(p, c, 0, true, true, 0.42, QPointF(6.5, 3));
        line(p, {3, 4.5}, {18, 4.5}, stroke(c.accent, 1.3));
        arrowHead(p, {21, 4.5}, {16, 4.5}, c.accent, 3.4);
    };
    icons["patternCircular"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.construction, 1.0, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 7.5, 7.5);
        for (int k = 0; k < 4; ++k) {
            const double a = k * M_PI / 2.0 - M_PI / 2.0;
            cube(p, c, k == 0 ? -1 : 0, true, true, 0.32, QPointF(7.5 * std::cos(a), 7.5 * std::sin(a)));
        }
    };
    icons["mirror"] = [](QPainter &p, const IconPalette &c) {
        polygon(p, QPolygonF({{9, 2.5}, {15, 5.5}, {15, 21.5}, {9, 18.5}}), QColor(96, 170, 255, 70), stroke(c.construction, 1.0));
        cube(p, c, -1, true, true, 0.4, QPointF(-6, 0));
        cube(p, c, 0, true, true, 0.4, QPointF(6, 0));
    };
    icons["symmetryAxis"] = [](QPainter &p, const IconPalette &c) {
        // Linea d'asse (tratto e punto) con due punti simmetrici.
        QPen axis = stroke(QColor(90, 225, 200), 1.6);
        axis.setDashPattern({6, 2, 1.5, 2});
        p.setPen(axis);
        p.drawLine(QPointF(12, 2), QPointF(12, 22));
        dot(p, {6, 9}, c.ink, 2.0);
        dot(p, {18, 9}, c.accent, 2.0);
        p.setPen(stroke(c.construction, 1.0, Qt::DashLine));
        p.drawLine(QPointF(6, 9), QPointF(18, 9));
        p.setPen(stroke(c.accent, 1.4));
        p.drawLine(QPointF(5, 17), QPointF(9, 17));
        p.drawLine(QPointF(15, 17), QPointF(19, 17));
    };
    icons["convertEdges"] = [](QPainter &p, const IconPalette &c) {
        // Spigolo di un cubo portato nel piano: il bordo in arancio e la sua proiezione.
        cube(p, c, 0, true, true, 0.5, QPointF(-2, -3));
        line(p, {3, 20}, {20, 20}, stroke(c.accent, 1.8));
        p.setPen(stroke(c.construction, 1.0, Qt::DashLine));
        p.drawLine(QPointF(5, 14), QPointF(5, 19));
        p.drawLine(QPointF(17, 14), QPointF(17, 19));
        arrowHead(p, {11, 19}, {11, 13}, c.accent, 3.0);
    };
    icons["sectionCurves"] = [](QPainter &p, const IconPalette &c) {
        // Cilindro tagliato dal piano: la curva di sezione in arancio.
        p.setBrush(c.faceMid);
        p.setPen(stroke(c.ink, 1.2));
        p.drawRect(QRectF(6, 5, 12, 15));
        polygon(p, QPolygonF({{2, 13}, {17, 9}, {22, 11}, {7, 15}}), QColor(96, 170, 255, 70), stroke(c.construction, 1.0));
        p.setPen(stroke(c.accent, 2.0));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(QPointF(12, 12), 6, 1.8);
    };
    icons["move"] = [](QPainter &p, const IconPalette &c) {
        // Cubo con la copia spostata tratteggiata e le frecce di traslazione e rotazione.
        cube(p, c, -1, true, true, 0.42, QPointF(-5, 4));
        p.setPen(stroke(c.accent, 1.2, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawRect(QRectF(12.5, 2.5, 8, 8));
        line(p, {9, 12}, {14, 7}, stroke(c.accent, 1.6));
        arrowHead(p, {16, 5}, {11, 10}, c.accent, 3.6);
        QPainterPath arc;
        arc.arcMoveTo(QRectF(11, 11, 10, 10), 200);
        arc.arcTo(QRectF(11, 11, 10, 10), 200, -150);
        p.setPen(stroke(c.accent, 1.5));
        p.drawPath(arc);
        arrowHead(p, arc.currentPosition(), arc.pointAtPercent(0.85), c.accent, 3.2);
    };
    icons["section"] = [](QPainter &p, const IconPalette &c) {
        // Un cubo tagliato: la faccia di sezione tratteggiata e il piano.
        cube(p, c, 0, true, true, 0.62, QPointF(-1.5, 1.5));
        const QPolygonF cut({{11.5, 5}, {19, 2.5}, {19, 15.5}, {11.5, 18}});
        polygon(p, cut, QColor(200, 92, 76, 150), stroke(c.accent, 1.3));
        p.save();
        p.setClipRegion(QRegion(cut.toPolygon()));
        p.setPen(stroke(QColor(120, 36, 30), 1.0));
        for (int k = -4; k < 6; ++k) line(p, {11.0 + 3.0 * k, 20}, {21.0 + 3.0 * k, 0}, stroke(QColor(120, 36, 30), 0.9));
        p.restore();
    };
    icons["scale"] = [](QPainter &p, const IconPalette &c) {
        // Quadrato piccolo pieno, quadrato grande tratteggiato, freccia in diagonale.
        p.setPen(stroke(c.accent, 1.2, Qt::DashLine));
        p.setBrush(Qt::NoBrush);
        p.drawRect(QRectF(3, 3, 18, 18));
        polygon(p, QPolygonF({{3, 12}, {12, 12}, {12, 21}, {3, 21}}), c.faceMid, stroke(c.ink, 1.1));
        line(p, {10, 14}, {17, 7}, stroke(c.accent, 1.6));
        arrowHead(p, {19, 5}, {14, 10}, c.accent, 4.0);
    };
    icons["helix"] = [](QPainter &p, const IconPalette &c) {
        // Asse tratteggiato e tre giri di elica (la parte davanti piena, dietro sottile).
        line(p, {12, 2}, {12, 22}, stroke(c.construction, 1.0, Qt::DashLine));
        for (int turn = 0; turn < 3; ++turn) {
            const double y = 5.0 + 5.5 * turn;
            QPainterPath front({4, y}), back({20, y + 2.75});
            front.cubicTo({4, y + 2.4}, {20, y + 0.4}, {20, y + 2.75});
            back.cubicTo({20, y + 5.1}, {4, y + 3.1}, {4, y + 5.5});
            p.setBrush(Qt::NoBrush);
            p.setPen(stroke(c.accent, 1.9));
            p.drawPath(front);
            p.setPen(stroke(c.accent, 0.9));
            p.drawPath(back);
        }
    };
    icons["thread"] = [](QPainter &p, const IconPalette &c) {
        // Albero cilindrico con profilo elicoidale a V.
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawRoundedRect(QRectF(4, 3, 16, 18), 3, 3);
        p.setBrush(c.faceLight);
        p.drawEllipse(QRectF(4, 2, 16, 5));
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.accent, 1.5));
        QPainterPath teeth({4, 7});
        for (int k = 0; k < 4; ++k) {
            const qreal y = 7.0 + 3.4 * k;
            teeth.lineTo(8, y + 1.7);
            teeth.lineTo(4, y + 3.4);
            teeth.moveTo(20, y);
            teeth.lineTo(16, y + 1.7);
            teeth.lineTo(20, y + 3.4);
        }
        p.drawPath(teeth);
    };
    icons["sweep"] = [](QPainter &p, const IconPalette &c) {
        // Tubo lungo un percorso curvo, con il profilo circolare all'inizio.
        QPainterPath path({4, 19});
        path.cubicTo({8, 8}, {14, 20}, {20, 6});
        QPen tube = stroke(c.faceMid, 7.0);
        p.setBrush(Qt::NoBrush);
        p.setPen(tube);
        p.drawPath(path);
        p.setPen(stroke(c.ink, 1.0, Qt::DashLine));
        p.drawPath(path);
        p.setPen(stroke(c.accent, 1.6));
        p.setBrush(c.faceLight);
        p.drawEllipse(QRectF(0.8, 15.5, 6.4, 6.4));
    };
    icons["loft"] = [](QPainter &p, const IconPalette &c) {
        // Dal cerchio in basso al quadrato in alto.
        polygon(p, QPolygonF({{4, 17}, {7, 5}, {17, 5}, {20, 17}}), c.faceMid, QPen(Qt::NoPen));
        line(p, {4, 17}, {7, 5}, stroke(c.ink, 1.0));
        line(p, {20, 17}, {17, 5}, stroke(c.ink, 1.0));
        polygon(p, QPolygonF({{7, 3}, {17, 3}, {17, 7}, {7, 7}}), c.faceLight, stroke(c.accent, 1.4));
        p.setPen(stroke(c.accent, 1.4));
        p.setBrush(c.faceLight);
        p.drawEllipse(QRectF(4, 14.5, 16, 5));
    };
    icons["measure"] = [](QPainter &p, const IconPalette &c) {
        // Calibro: righello obliquo con le tacche e la quota tra due punti.
        QPolygonF ruler({{3, 15}, {15, 3}, {21, 9}, {9, 21}});
        p.setPen(stroke(c.ink, 1.4));
        p.setBrush(Qt::NoBrush);
        p.drawPolygon(ruler);
        for (int k = 1; k <= 4; ++k) {
            const QPointF base(3 + 2.4 * k, 15 - 2.4 * k);
            line(p, base, base + QPointF(k % 2 ? 1.6 : 2.8, k % 2 ? 1.6 : 2.8), stroke(c.ink, 1.1));
        }
        line(p, {4.5, 21}, {20, 21}, stroke(c.accent, 1.4, Qt::DashLine));
        arrowHead(p, {3.5, 21}, {8, 21}, c.accent, 3.0);
        arrowHead(p, {21, 21}, {16.5, 21}, c.accent, 3.0);
    };
    icons["massProperties"] = [](QPainter &p, const IconPalette &c) {
        // Solido con il baricentro (cerchio a quarti) e il peso.
        cube(p, c);
        const QRectF r(8.5, 10.5, 7, 7);
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(Qt::white);
        p.drawEllipse(r);
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(20, 24, 28));
        p.drawPie(r, 0, 90 * 16);
        p.drawPie(r, 180 * 16, 90 * 16);
        p.setPen(c.accent);
        QFont font;
        font.setPixelSize(7);
        font.setBold(true);
        p.setFont(font);
        p.drawText(QRectF(13, 0, 11, 8), Qt::AlignCenter, QStringLiteral("kg"));
    };
    icons["datumPlane"] = [](QPainter &p, const IconPalette &c) {
        // Piano di riferimento (tratteggiato) e il piano nuovo parallelo, spostato dalla freccia.
        polygon(p, QPolygonF({{1.5, 21}, {7.5, 15.5}, {22.5, 15.5}, {16.5, 21}}), QColor(96, 170, 255, 50), stroke(c.construction, 1.0, Qt::DashLine));
        polygon(p, QPolygonF({{1.5, 10}, {7.5, 4.5}, {22.5, 4.5}, {16.5, 10}}), QColor(255, 176, 74, 90), stroke(c.accent, 1.4));
        line(p, {12, 18.2}, {12, 10.5}, stroke(c.ink, 1.3));
        arrowHead(p, {12, 8}, {12, 12}, c.ink, 3.2);
    };
    icons["import"] = [](QPainter &p, const IconPalette &c) {
        // Documento con la freccia che entra nel solido.
        polygon(p, QPolygonF({{2.5, 2.5}, {10, 2.5}, {13, 5.5}, {13, 14}, {2.5, 14}}), c.faceLight, stroke(c.ink, 1.1));
        line(p, {4.5, 7}, {10.5, 7}, stroke(c.faceDark, 1.0));
        line(p, {4.5, 9.5}, {10.5, 9.5}, stroke(c.faceDark, 1.0));
        cube(p, c, -1, true, true, 0.55, QPointF(5.5, 5));
        line(p, {6.5, 11}, {10.5, 15}, stroke(c.accent, 1.8));
        arrowHead(p, {13, 17.5}, {9.5, 14}, c.accent, 4.0);
    };
    icons["box"] = [](QPainter &p, const IconPalette &c) { cube(p, c); };
    icons["cylinder"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath side({4, 6});
        side.lineTo(4, 18);
        side.arcTo(QRectF(4, 15, 16, 6), 180, 180);
        side.lineTo(20, 6);
        side.closeSubpath();
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(side);
        p.setBrush(c.faceLight);
        p.drawEllipse(QRectF(4, 3, 16, 6));
    };
    icons["sphere"] = [](QPainter &p, const IconPalette &c) {
        QRadialGradient gradient(QPointF(9, 8), 13);
        gradient.setColorAt(0, c.faceLight);
        gradient.setColorAt(1, c.faceDark);
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(gradient);
        p.drawEllipse(QPointF(12, 12), 9, 9);
        p.setBrush(Qt::NoBrush);
        p.setPen(stroke(c.ink, 0.7));
        p.drawEllipse(QRectF(3, 9.5, 18, 5));
    };
    icons["cone"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath side({12, 2.5});
        side.lineTo(3.5, 18);
        side.arcTo(QRectF(3.5, 15, 17, 6), 180, 180);
        side.closeSubpath();
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(side);
        p.setBrush(Qt::NoBrush);
        QPainterPath back;
        back.arcMoveTo(QRectF(3.5, 15, 17, 6), 0);
        back.arcTo(QRectF(3.5, 15, 17, 6), 0, 180);
        p.setPen(stroke(c.ink, 0.7, Qt::DashLine));
        p.drawPath(back);
    };
    icons["torus"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath ring;
        ring.addEllipse(QRectF(2, 5, 20, 14));
        QPainterPath hole;
        hole.addEllipse(QRectF(8, 10, 8, 4));
        p.setPen(stroke(c.ink, 1.0));
        p.setBrush(c.faceMid);
        p.drawPath(ring.subtracted(hole));
        p.setBrush(Qt::NoBrush);
        QPainterPath highlight;
        highlight.arcMoveTo(QRectF(4.5, 7, 15, 10), 20);
        highlight.arcTo(QRectF(4.5, 7, 15, 10), 20, 140);
        p.setPen(stroke(c.faceLight, 1.2));
        p.drawPath(highlight);
    };

    // --- Vista ------------------------------------------------------------------
    icons["zoomAll"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.construction, 1.3));
        p.setBrush(Qt::NoBrush);
        for (const QPointF &corner : {QPointF(2.5, 2.5), QPointF(21.5, 2.5), QPointF(2.5, 21.5), QPointF(21.5, 21.5)}) {
            const double sx = corner.x() < 12 ? 1 : -1, sy = corner.y() < 12 ? 1 : -1;
            p.drawPolyline(QPolygonF({corner + QPointF(0, 5 * sy), corner, corner + QPointF(5 * sx, 0)}));
        }
        p.setPen(stroke(c.ink, 1.6));
        p.drawEllipse(QPointF(10.5, 10.5), 4.8, 4.8);
        line(p, {14, 14}, {18.5, 18.5}, stroke(c.accent, 2.6));
    };
    icons["viewFront"] = [](QPainter &p, const IconPalette &c) { cube(p, c, 1); };
    icons["viewTop"] = [](QPainter &p, const IconPalette &c) { cube(p, c, 0); };
    icons["viewRight"] = [](QPainter &p, const IconPalette &c) { cube(p, c, 2); };
    icons["viewIso"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c);
        line(p, {12, 11.4}, {12, 21}, stroke(c.accent, 1.5));
        line(p, {12, 11.4}, {3.5, 7.2}, stroke(c.accent, 1.5));
        line(p, {12, 11.4}, {20.5, 7.2}, stroke(c.accent, 1.5));
    };
    icons["viewRear"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c, -1, true, true);
        polygon(p, QPolygonF({{3.5, 7.2}, {12, 3}, {12, 12.6}, {3.5, 16.8}}), QColor(0, 0, 0, 0), stroke(c.accent, 1.2, Qt::DashLine));
    };
    icons["viewTrimetric"] = [](QPainter &p, const IconPalette &c) {
        p.save();
        p.translate(12, 12);
        p.rotate(-12);
        p.translate(-12, -12);
        cube(p, c);
        p.restore();
    };
    icons["displayWireframe"] = [](QPainter &p, const IconPalette &c) {
        cube(p, c, -1, false, true);
        p.setPen(stroke(c.ink, 0.8, Qt::DashLine));
        p.drawLine(QPointF(3.5, 16.8), QPointF(12, 12.6));
        p.drawLine(QPointF(12, 12.6), QPointF(20.5, 16.8));
        p.drawLine(QPointF(12, 12.6), QPointF(12, 3));
    };
    icons["displayShaded"] = [](QPainter &p, const IconPalette &c) { cube(p, c, -1, true, false); };
    icons["displayShadedEdges"] = [](QPainter &p, const IconPalette &c) { cube(p, c, -1, true, true); };
    icons["panelOpacity"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath panel;
        panel.addRoundedRect(QRectF(3.5, 4, 17, 16), 2.5, 2.5);
        p.setPen(stroke(c.ink, 1.4));
        p.setBrush(c.faceDark);
        p.drawPath(panel);
        p.save();
        p.setClipPath(panel);
        p.setPen(Qt::NoPen);
        p.setBrush(c.accent);
        p.drawRect(QRectF(3.5, 4, 8.5, 16));
        p.restore();
        line(p, {12, 5}, {12, 19}, stroke(c.construction, 1.1, Qt::DashLine));
    };
    icons["panelBlur"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.faceMid, 1.0));
        p.setBrush(c.faceDark);
        p.drawRoundedRect(QRectF(3.5, 4, 17, 16), 2.5, 2.5);
        for (int row = 0; row < 3; ++row) {
            QPainterPath wave(QPointF(6, 8 + row * 4));
            wave.cubicTo({8, 5.5 + row * 4.0}, {10, 10.5 + row * 4.0}, {12, 8.0 + row * 4.0});
            wave.cubicTo({14, 5.5 + row * 4.0}, {16, 10.5 + row * 4.0}, {18, 8.0 + row * 4.0});
            p.setPen(stroke(row == 1 ? c.accent : c.construction, row == 1 ? 1.8 : 1.1));
            p.drawPath(wave);
        }
    };
    icons["panelCorners"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink, 1.5));
        p.setBrush(c.faceDark);
        p.drawRoundedRect(QRectF(3.5, 4, 17, 16), 4.5, 4.5);
        p.setPen(stroke(c.accent, 2.0));
        p.setBrush(Qt::NoBrush);
        p.drawArc(QRectF(3.5, 4, 9, 9), 90 * 16, 90 * 16);
        p.drawArc(QRectF(11.5, 11, 9, 9), -90 * 16, 90 * 16);
        dot(p, {8, 8.5}, c.construction, 1.3);
        dot(p, {16, 15.5}, c.construction, 1.3);
    };
    icons["viewOptions"] = [](QPainter &p, const IconPalette &c) {
        QPainterPath eye({2,12}); eye.cubicTo({7,3},{17,3},{22,12}); eye.cubicTo({17,21},{7,21},{2,12});
        p.setPen(stroke(c.ink,1.5)); p.setBrush(Qt::NoBrush); p.drawPath(eye); dot(p,{12,12},c.accent,3);
    };
    icons["viewGrid"] = [](QPainter &p, const IconPalette &c) {
        for(int i=4;i<=20;i+=4){line(p,{double(i),4},{double(i),20},stroke(c.ink,1));line(p,{4,double(i)},{20,double(i)},stroke(c.ink,1));}
        dot(p,{12,12},c.accent,2);
    };
    icons["viewAxes"] = [](QPainter &p, const IconPalette &c) {
        for(QPointF tip : {QPointF(20,18),QPointF(4,4),QPointF(14,3)}) {line(p,{8,17},tip,stroke(c.ink,1.5));arrowHead(p,tip,{8,17},c.accent,3);}
    };
    icons["viewLight"] = [](QPainter &p, const IconPalette &c) {
        dot(p,{12,12},c.accent,4);for(int i=0;i<8;++i){double a=i*3.141592653589793/4;line(p,{12+7*cos(a),12+7*sin(a)},{12+10*cos(a),12+10*sin(a)},stroke(c.ink,1.5));}
    };
    icons["viewQuality"] = [](QPainter &p, const IconPalette &c) {
        for(int i=0;i<3;++i){p.setPen(Qt::NoPen);p.setBrush(i==2?c.accent:c.ink);p.drawRect(QRectF(4+i*6,16-i*5,4,5+i*5));}
    };
    icons["viewColor"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink,1.4));p.setBrush(c.faceDark);p.drawEllipse(QRectF(3,3,18,18));
        dot(p,{8,8},c.accent,2);dot(p,{16,8},c.construction,2);dot(p,{8,16},c.confirm,2);dot(p,{16,16},c.remove,2);
    };
    icons["viewBackground"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink,1.3));p.setBrush(c.faceDark);p.drawRect(QRectF(3,4,18,16));
        p.setBrush(c.faceLight);p.drawPolygon(QPolygonF({{4,19},{10,11},{14,16},{17,12},{20,19}}));dot(p,{17,8},c.accent,2);
    };
    icons["viewTheme"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink,1.5));p.setBrush(c.faceDark);p.drawEllipse(QRectF(4,4,16,16));p.setBrush(c.accent);p.drawPie(QRectF(4,4,16,16),90*16,180*16);
    };
    icons["viewHighlight"] = [](QPainter &p, const IconPalette &c) {cube(p,c,-1,true,true);dot(p,{16,8},c.accent,3);};
    icons["viewLayers"] = [](QPainter &p, const IconPalette &c) {
        for(int i=2;i>=0;--i){p.setPen(stroke(i==0?c.accent:c.ink,1.4));p.setBrush(c.faceDark);p.drawPolygon(QPolygonF({{3,7.0+i*4},{12,3.0+i*4},{21,7.0+i*4},{12,11.0+i*4}}));}
    };
    icons["viewAntialias"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink,1.5));p.drawPolyline(QPolygonF({{3,19},{8,19},{8,14},{13,14},{13,9},{18,9},{18,4}}));line(p,{4,20},{20,4},stroke(c.accent,2));
    };
    icons["viewTopology"] = [](QPainter &p, const IconPalette &c) {
        line(p,{5,18},{12,5},stroke(c.ink,1.4));line(p,{12,5},{20,18},stroke(c.ink,1.4));line(p,{5,18},{20,18},stroke(c.ink,1.4));
        for(QPointF point : {QPointF(5,18),QPointF(12,5),QPointF(20,18)})dot(p,point,c.accent,2);
    };
    icons["viewWheel"] = [](QPainter &p, const IconPalette &c) {
        p.setPen(stroke(c.ink,1.5));p.setBrush(c.faceDark);p.drawRoundedRect(QRectF(6,2,12,20),6,6);p.setBrush(c.accent);p.drawRoundedRect(QRectF(10,5,4,6),2,2);
    };
    for(bool plus : {false,true}) icons[plus?"zoomIn":"zoomOut"] = [plus](QPainter &p,const IconPalette &c){
        p.setPen(stroke(c.ink,1.6));p.setBrush(Qt::NoBrush);p.drawEllipse(QRectF(3,3,12,12));line(p,{14,14},{21,21},stroke(c.ink,2));
        line(p,{6,9},{12,9},stroke(c.accent,1.8));if(plus)line(p,{9,6},{9,12},stroke(c.accent,1.8));
    };
    icons["viewInspect"] = icons["zoomIn"];
    for(int mode=0;mode<3;++mode) icons[mode==0?"storyboardHorizontal":mode==1?"storyboardLeft":"storyboardRight"] = [mode](QPainter &p,const IconPalette &c){
        for(int y : {5,12,19})line(p,{7,double(y)},{20,double(y)},stroke(c.ink,1.4));
        if(mode==0)line(p,{3,15},{21,15},stroke(c.accent,2));
        else {const double x=mode==1?3:22;line(p,{x,3},{x,21},stroke(c.construction,1.2));dot(p,{x,12},c.accent,2);}
    };
    icons["extractEdge3D"] = [base=icons["convertEdges"]](QPainter &p,const IconPalette &c){base(p,c);badge3D(p,c);};
    icons["trimEdge3D"] = [base=icons["trim"]](QPainter &p,const IconPalette &c){base(p,c);badge3D(p,c);};
    icons["storyboard"] = icons["storyboardLeft"];
    return icons;
}

// Motore dell'icona: disegna a ogni dimensione richiesta (anche con il
// rapporto dei pixel dello schermo), niente immagini scalate.
class PaintedIconEngine : public QIconEngine {
public:
    explicit PaintedIconEngine(Draw draw) : draw_(std::move(draw)) {}
    void paint(QPainter *painter, const QRect &rect, QIcon::Mode mode, QIcon::State) override {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing);
        painter->setRenderHint(QPainter::TextAntialiasing);
        const double side = std::min(rect.width(), rect.height());
        painter->translate(rect.x() + (rect.width() - side) / 2.0, rect.y() + (rect.height() - side) / 2.0);
        painter->scale(side / 24.0, side / 24.0);
        draw_(*painter, palette(mode));
        painter->restore();
    }
    QPixmap pixmap(const QSize &size, QIcon::Mode mode, QIcon::State state) override { return scaledPixmap(size, mode, state, 1.0); }
    QPixmap scaledPixmap(const QSize &size, QIcon::Mode mode, QIcon::State state, qreal scale) override {
        QImage image(size * scale, QImage::Format_ARGB32_Premultiplied);
        image.fill(Qt::transparent);
        {
            QPainter painter(&image);
            paint(&painter, QRect(QPoint(), image.size()), mode, state);
        }
        image.setDevicePixelRatio(scale);
        return QPixmap::fromImage(image);
    }
    QIconEngine *clone() const override { return new PaintedIconEngine(draw_); }

private:
    Draw draw_;
};

}

QIcon commandIcon(const QString &name) {
    const auto &icons = registry();
    const auto found = icons.find(name);
    if (found == icons.end()) return {};
    return QIcon(new PaintedIconEngine(found->second));
}

QStringList commandIconNames() {
    QStringList names;
    for (const auto &entry : registry()) names.append(entry.first);
    return names;
}

}
