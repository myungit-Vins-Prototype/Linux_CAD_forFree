#include "cuda_support.h"
#include <cuda_runtime_api.h>
#include <vector>
#include <cstdio>
std::size_t freeBytes(){std::size_t f=0,t=0;cudaMemGetInfo(&f,&t);return f;}
int main(){if(!forgecad_cuda_available())return 2;const double k[]={0,0,0,0,1,1,1,1};double p[48];for(int i=0;i<4;++i)for(int j=0;j<4;++j){int a=3*(4*i+j);p[a]=i;p[a+1]=j;p[a+2]=0;}auto before=freeBytes();ForgeCudaBSplineSurface s{3,3,4,4,k,k,p,nullptr};void *h=forgecad_cuda_upload_surface(s);if(!h)return 3;const std::size_t count=1048576;std::vector<double> uv(2*count,0.5),points(3*count),normals(3*count);bool ok=forgecad_cuda_evaluate_surface(h,uv.data(),count,points.data(),normals.data());auto after=freeBytes();forgecad_cuda_release_surface(h);auto released=freeBytes();std::printf("ok=%d count=%zu consumed_after_batch_MiB=%.3f retained_after_surface_release_MiB=%.3f point=%g,%g,%g normal=%g,%g,%g\n",ok,count,double(before-after)/1048576,double(before-released)/1048576,points[0],points[1],points[2],normals[0],normals[1],normals[2]);return ok?0:1;}
