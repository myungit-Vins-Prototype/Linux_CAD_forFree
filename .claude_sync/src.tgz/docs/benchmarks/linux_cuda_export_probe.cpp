#include "cad_export.h"
#include "cad_cuda_tessellation.h"
#include "fk_loft.h"
#include <QApplication>
#include <cmath>
#include <cstdio>
int main(int argc,char**argv){QApplication app(argc,argv);using namespace ForgeCad;using namespace Kernel;
std::vector<LoftSection> sections;for(int k=0;k<4;++k){LoftSection s;s.frame=Frame3(Vec3(0.4*k,0,3.0*k),Vec3(0,0,1),Vec3(1,0,0));s.loop.segments={ProfileSegment{std::make_shared<Circle<2>>(Vec2(),Vec2(1,0),Vec2(0,1),4.0+std::sin(double(k))),Interval{0,kTwoPi}}};sections.push_back(s);}
QVector<ExportBody> bodies{{QStringLiteral("Loft CUDA"),std::make_shared<const Body>(loftSolid(sections,false)),{},QColor(Qt::white)}};StlExportOptions o;o.maxEdgeLength=0;o.deflection=1e-3;o.angle=5.7;
setCudaTessellationEnabled(false);auto cpu=buildBinaryStl(bodies,o);auto cpuObj=buildQuadObj(bodies,o);
setCudaTessellationEnabled(true);auto before=cudaTessellationPoints();auto gpu=buildBinaryStl(bodies,o);auto middle=cudaTessellationPoints();auto gpuObj=buildQuadObj(bodies,o);auto after=cudaTessellationPoints();
bool valid=cpu.error.isEmpty()&&gpu.error.isEmpty()&&cpuObj.error.isEmpty()&&gpuObj.error.isEmpty()&&middle>before&&after>middle&&cpu.triangleCount==gpu.triangleCount&&cpuObj.quadCount==gpuObj.quadCount&&cpuObj.triangleCount==gpuObj.triangleCount&&cpu.preview.vertices.size()==gpu.preview.vertices.size();double worst=0;if(valid)for(qsizetype i=0;i<cpu.preview.vertices.size();++i){double d=(cpu.preview.vertices[i]-gpu.preview.vertices[i]).length();valid=valid&&std::isfinite(d);worst=std::max(worst,d);}valid=valid&&worst<1e-5;
std::printf("cuda_available=%d STL_triangles_CPU=%llu GPU=%llu OBJ_quads_CPU=%llu GPU=%llu OBJ_triangles_CPU=%llu GPU=%llu gpu_points_STL=%llu OBJ=%llu worst_preview_distance=%g valid=%d\n",cudaTessellationAvailable(),(unsigned long long)cpu.triangleCount,(unsigned long long)gpu.triangleCount,(unsigned long long)cpuObj.quadCount,(unsigned long long)gpuObj.quadCount,(unsigned long long)cpuObj.triangleCount,(unsigned long long)gpuObj.triangleCount,(unsigned long long)(middle-before),(unsigned long long)(after-middle),worst,valid);
return valid?0:1;}
