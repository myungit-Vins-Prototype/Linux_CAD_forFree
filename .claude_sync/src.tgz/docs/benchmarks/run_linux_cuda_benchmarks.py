import subprocess,json,statistics,platform
from pathlib import Path
workloads=[('iso',['iso','512']),('boxes_serial',['boxes','1','5000']),('boxes_auto',['boxes','0','5000']),('disjoint_serial',['disjoint','1024','1']),('disjoint_auto',['disjoint','1024','0']),('sparse_auto',['sparse','1024','0']),('spring_auto',['spring','0','10']),('fillet',['fillet','1000'])]
def parse(output):
    result={}
    for token in output.split():
        if '=' not in token: continue
        key,value=token.split('=',1)
        try: result[key]=float(value)
        except ValueError: result[key]=value
    return result
records=[]
for repeat in range(5):
    for name,args in workloads:
        p=subprocess.run(['/tmp/forgecad-linux-review-probe']+args,capture_output=True,text=True)
        record={'workload':name,'repeat':repeat+1,'argv':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        record['values']=parse(p.stdout)
        records.append(record)
        print(name,repeat+1,p.stdout.strip(),flush=True)
    for threads in (1,0):
        for name,exe in [('tess_cuda_gpu','/tmp/forgecad-tessellation-benchmark'),('tess_cpu_backend','/tmp/forgecad-tessellation-cpu-benchmark')]:
            p=subprocess.run([exe,str(threads)],capture_output=True,text=True)
            records.append({'workload':name+'_'+str(threads),'repeat':repeat+1,'argv':[str(threads)],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'values':parse(p.stdout)})
            print(name,threads,repeat+1,p.stdout.strip(),flush=True)
summary={}
for name in dict.fromkeys(x['workload'] for x in records):
    rows=[r for r in records if r['workload']==name]; metric='first_ms' if name=='iso' else 'seconds'
    if name=='iso':metric=next(k for k in rows[0]['values'] if 'first' in k)
    times=[r['values'][metric] for r in rows]
    summary[name]={'metric':metric,'median':statistics.median(times),'min':min(times),'max':max(times),'peak_MiB_median':statistics.median(r['values']['after_peak_MiB'] for r in rows),'valid':all(r['exit_code']==0 and r['values'].get('valid')==1 for r in rows)}
Path('/tmp/forgecad-linux-performance-2026-10-10.json').write_text(json.dumps({'platform':platform.platform(),'protocol':'5 processi nuovi per workload; controlli geometrici fuori dal timer; nessuna build simultanea','records':records,'summary':summary},indent=2))
print(json.dumps(summary,indent=2),flush=True)

raise SystemExit(0 if all(r["valid"] for r in summary.values()) else 1)
