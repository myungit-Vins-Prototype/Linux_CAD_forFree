// Diagnostica manuale: mouse_mesh_probe finale.body [qualita 0..2] [gpu].
// Confronta ogni vertice con la propria superficie usando i parametri UV;
// una bounding box globale non rileva i vertici spurii prossimi all'origine.
#include "fk_body_io.h"
#include "fk_tessellate.h"
#include "fk_classify.h"
#include "cad_cuda_tessellation.h"
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
using namespace ForgeCad::Kernel;
int main(int argc, char **argv) {
    try {
        if (argc < 2) throw std::runtime_error("uso: mouse_mesh_probe finale.body [0..2] [gpu]");
        std::ifstream input(argv[1], std::ios::binary);
        if (!input) throw std::runtime_error("file B-rep non leggibile");
        const Body body = readBodyBinary(std::string(std::istreambuf_iterator<char>(input), {}));
        const int quality = argc > 2 ? std::stoi(argv[2]) : 2;
        if (quality < 0 || quality > 2) throw std::runtime_error("qualita' non valida");
        const bool useGpu = argc > 3 && std::string(argv[3]) == "gpu";
        auto accelerator = useGpu ? ForgeCad::makeTessellationAccelerator() : nullptr;
        if (useGpu && !accelerator) throw std::runtime_error("acceleratore CUDA non disponibile");
        TessellationOptions options;
        RayFaceIndex bounds(body);
        options.deflection = bounds.bounds.diagonal() * (quality == 0 ? 4e-3 : quality == 1 ? 1e-3 : 2e-4);
        options.angle = quality == 0 ? 0.5 : quality == 1 ? 0.25 : 0.1;
        options.accelerator = accelerator.get();
        const auto mesh = tessellate(body, options);
        double maximum = 0;
        std::size_t bad = 0, triangles = 0;
        for (const auto &face : mesh.faces) {
            double worst = 0;
            std::size_t at = 0, count = 0;
            for (std::size_t i = 0; i < face.points.size(); ++i) {
                const auto uv = face.parameters[i];
                const auto exact = body.face(face.face).surface->point(uv[0], uv[1]);
                const double error = distance(exact, face.points[i]);
                if (!std::isfinite(error) || error > worst) {
                    worst = std::isfinite(error) ? error : std::numeric_limits<double>::infinity();
                    at = i;
                }
                count += !std::isfinite(error) || error > 1e-3;
            }
            if (worst > 1e-4 || count) {
                const auto p = face.points[at];
                const auto uv = face.parameters[at];
                std::cout << "F" << face.face.index << " points=" << face.points.size()
                          << " triangles=" << face.triangles.size() << " bad=" << count << " worst=" << worst
                          << " at=" << at << " xyz=" << p[0] << ',' << p[1] << ',' << p[2]
                          << " uv=" << uv[0] << ',' << uv[1] << std::endl;
            }
            maximum = std::max(maximum, worst);
            bad += count;
            triangles += face.triangles.size();
        }
        const auto gpuPoints = ForgeCad::cudaTessellationPoints();
        std::cout << "gpu_points=" << gpuPoints << " triangles=" << triangles << " failed=" << mesh.failedFaces
                  << " bad=" << bad << " maximum=" << maximum << std::endl;
        if (useGpu && gpuPoints == 0) throw std::runtime_error("nessun punto valutato sulla GPU");
        return bad == 0 && mesh.failedFaces == 0 ? 0 : 1;
    } catch (const std::exception &error) {
        std::cerr << error.what() << std::endl;
        return 1;
    }
}
