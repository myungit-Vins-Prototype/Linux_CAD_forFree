#include "cad_cuda_tessellation.h"
#include "cuda_support.h"
#include "fk_loft.h"
#include "fk_tessellate.h"
#include <chrono>
#include <cmath>
#include <iostream>
#include <sys/resource.h>
using namespace ForgeCad::Kernel;
int main(int argc, char **argv) {
    const int threads = argc > 1 ? std::stoi(argv[1]) : 0;
    std::vector<LoftSection> sections;
    for (int k = 0; k < 4; ++k) {
        LoftSection s;
        s.frame = Frame3(Vec3(0.4*k,0,3.0*k),Vec3(0,0,1),Vec3(1,0,0));
        s.loop.segments = {ProfileSegment{std::make_shared<Circle<2>>(Vec2(0,0),Vec2(1,0),Vec2(0,1),4.0+std::sin(double(k))),Interval{0,kTwoPi}}};
        sections.push_back(s);
    }
    const Body body = loftSolid(sections,false);
    auto gpu = ForgeCad::makeTessellationAccelerator();
    TessellationOptions options;
    options.deflection=1e-3; options.angle=0.1; options.threads=threads; options.accelerator=gpu.get();
    const auto start=std::chrono::steady_clock::now();
    const auto mesh=tessellate(body,options);
    const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::size_t triangles=0; double deviation=0; bool valid=mesh.failedFaces==0;
    for(const auto &face:mesh.faces) {
        triangles+=face.triangles.size();
        const auto &surface=*body.face(face.face).surface;
        for(std::size_t i=0;i<face.points.size();++i) {
            const double error=distance(face.points[i],surface.point(face.parameters[i][0],face.parameters[i][1]));
            valid=valid && std::isfinite(error);
            deviation=std::max(deviation,error);
        }
    }
    valid=valid && triangles>0 && deviation<1e-7;
    rusage usage{}; getrusage(RUSAGE_SELF,&usage);
    std::cout << "threads=" << threads << " seconds=" << seconds << " after_peak_MiB=" << double(usage.ru_maxrss)/1024
              << " triangles=" << triangles << " deviation=" << deviation << " gpu_points=" << ForgeCad::cudaTessellationPoints()
              << " cuda_available=" << ForgeCad::cudaTessellationAvailable() << " valid=" << valid << '\n';
    return valid ? 0:1;
}
