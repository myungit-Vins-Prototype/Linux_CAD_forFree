#include "cad_model_history.h"
#include "cad_feature_dependencies.h"

#include <algorithm>

#include <QHash>
#include <QSet>

namespace ForgeCad {
namespace {

bool isReferenceFeature(const ExtrusionObject &feature) {
    return feature.operation < 0
        && (feature.feature == BodyFeature::DatumPlane || feature.feature == BodyFeature::Helix || feature.feature == BodyFeature::ProjectedCurve || feature.feature == BodyFeature::ExtractedCurve || feature.feature == BodyFeature::SpatialSketch);
}

bool isValidHistoryStage(const ExtrusionObject &feature) {
    if (feature.suppressed || !feature.error.isEmpty()) return false;
    if (feature.operation < 0 && feature.feature == BodyFeature::DatumPlane) return feature.datumValid;
    if (feature.operation < 0 && (feature.feature == BodyFeature::Helix || feature.feature == BodyFeature::ProjectedCurve || feature.feature == BodyFeature::ExtractedCurve || feature.feature == BodyFeature::SpatialSketch))
        return feature.curve != nullptr;
    return feature.forgeBody != nullptr;
}

quint64 inheritedBody(const QVector<ExtrusionObject> &features, const ExtrusionObject &feature) {
    const auto owner = [&](int index) {
        return index >= 0 && index < features.size() ? features.at(index).modelBodyId : quint64(0);
    };
    if (isReferenceFeature(feature)) return 0;
    if (feature.operation >= 0) return owner(feature.firstBody);
    switch (feature.feature) {
    case BodyFeature::Blend:
    case BodyFeature::SheetTrim:
    case BodyFeature::SheetExtend:
    case BodyFeature::Scale:
    case BodyFeature::Sew:
    case BodyFeature::DeleteFace:
    case BodyFeature::Draft:
    case BodyFeature::Shell:
    case BodyFeature::Thread:
        return owner(feature.firstBody);
    case BodyFeature::Transform:
        return feature.move.copy ? 0 : owner(feature.firstBody);
    case BodyFeature::Pattern:
        return owner(feature.firstBody);
    case BodyFeature::Thicken:
        // Tutta la superficie diventa un solido: lo stesso corpo; facce scelte: un corpo nuovo.
        return feature.offsetFaces.isEmpty() ? owner(feature.firstBody) : 0;
    case BodyFeature::Ruled:
    case BodyFeature::PlanarSurface:
    case BodyFeature::BoundarySurface:
    case BodyFeature::FillSurface:
        return 0;  // superfici nuove: le curve e i bordi scelti restano dei loro corpi
    case BodyFeature::Extrusion:
    case BodyFeature::Revolution:
    case BodyFeature::Sweep:
        if (feature.mergeOperation != 0 && !feature.mergeBodies.isEmpty()) return owner(feature.mergeBodies.first());
        return 0;
    default:
        return 0;
    }
}

}

quint64 inheritedModelBody(const QVector<ExtrusionObject> &features, const ExtrusionObject &feature) {
    return inheritedBody(features, feature);
}

QVector<int> modelBodyFeatures(const DocumentState &state, quint64 bodyId) {
    QVector<int> result;
    if (bodyId == 0) return result;
    for (int index = 0; index < state.extrusions.size(); ++index)
        if (state.extrusions.at(index).modelBodyId == bodyId) result.append(index);
    return result;
}

int modelBodyTipIndex(const DocumentState &state, quint64 bodyId) {
    for (int index = state.extrusions.size() - 1; index >= 0; --index)
        if (state.extrusions.at(index).modelBodyId == bodyId && isValidHistoryStage(state.extrusions.at(index))) return index;
    return -1;
}

void normalizeModelHistory(QVector<ExtrusionObject> &features, QVector<ModelBody> &modelBodies) {
    quint64 nextFeature = 1, nextBody = 1;
    QSet<quint64> featureIds, bodyIds;
    for (const ExtrusionObject &feature : features) {
        if (feature.featureId) nextFeature = std::max(nextFeature, feature.featureId + 1);
        if (feature.modelBodyId) nextBody = std::max(nextBody, feature.modelBodyId + 1);
    }
    for (const ModelBody &body : modelBodies)
        if (body.id) nextBody = std::max(nextBody, body.id + 1);

    for (int index = 0; index < features.size(); ++index) {
        ExtrusionObject &feature = features[index];
        if (!feature.featureId || featureIds.contains(feature.featureId)) feature.featureId = nextFeature++;
        featureIds.insert(feature.featureId);
        if (isReferenceFeature(feature)) {
            feature.modelBodyId = 0;
            continue;
        }
        if (!feature.modelBodyId) feature.modelBodyId = inheritedBody(features, feature);
        if (!feature.modelBodyId) feature.modelBodyId = nextBody++;
        bodyIds.insert(feature.modelBodyId);
    }

    // Migrazione dei riferimenti nati prima della storyboard: l'indice resta
    // la cache usata dal grafo, l'ID impedisce che un riordino li leghi a una
    // feature diversa.
    const auto bindOwner = [&](GeometryRef &ref) {
        if (isBodyRef(ref) && !ref.featureId && ref.index >= 0 && ref.index < features.size())
            ref.featureId = features.at(ref.index).featureId;
    };
    for (ExtrusionObject &feature : features) {
        for (GeometryRef &ref : feature.datum.refs) bindOwner(ref);
        for (GeometryRef &ref : feature.pattern.refs) bindOwner(ref);
        for (QVector<GeometryRef> *refs : {&feature.ruledFirst, &feature.ruledSecond, &feature.planarRefs, &feature.loftStartFaces, &feature.loftEndFaces, &feature.loftSections, &feature.loftEdgeGuides})
            for (GeometryRef &ref : *refs) bindOwner(ref);
        bindOwner(feature.extentRef);
        bindOwner(feature.move.axis);
        bindOwner(feature.revolveAxisRef);
        bindOwner(feature.draftNeutral);
        bindOwner(feature.thickenDirection);
        bindOwner(feature.sweepProfileRef);
        bindOwner(feature.sweepPathRef);
        bindOwner(feature.curveExtraction.source);
        for(auto &ref:feature.curveExtraction.sources)bindOwner(ref);
        bindOwner(feature.curveExtraction.tool);
    }

    QHash<quint64, ModelBody> existing;
    for (const ModelBody &body : modelBodies)
        if (body.id && bodyIds.contains(body.id)) existing.insert(body.id, body);
    // Raggruppa una volta gli stadi: evita di scandire l'intera storia per
    // ogni corpo e conserva l'ordine della prima apparizione nel documento.
    QVector<quint64> ordered;
    QHash<quint64, QVector<int>> stages;
    for (int index = 0; index < features.size(); ++index) {
        const quint64 id = features.at(index).modelBodyId;
        if (!id) continue;
        auto found = stages.find(id);
        if (found == stages.end()) {
            ordered.append(id);
            found = stages.insert(id, {});
        }
        found.value().append(index);
    }

    QVector<ModelBody> bodies;
    int number = 1;
    for (quint64 id : ordered) {
        const bool hadBody = existing.contains(id);
        ModelBody body = existing.value(id);
        const quint64 previousTip = body.tipFeatureId;
        body.id = id;
        if (body.name.trimmed().isEmpty()) body.name = QStringLiteral("Corpo %1").arg(number);
        const QVector<int> &indices = stages[id];
        int tip = -1, lastActive = -1, lastWithoutError = -1, savedTip = -1;
        for (int index : indices) {
            const ExtrusionObject &feature = features.at(index);
            if (feature.suppressed) continue;
            lastActive = index;
            if (!feature.error.isEmpty()) continue;
            lastWithoutError = index;
            if (feature.featureId == previousTip) savedTip = index;
            if (isValidHistoryStage(feature)) tip = index;
        }
        // Durante la lettura le definizioni precedono la cache geometrica:
        // conserva il tip serializzato, o l'ultimo stadio senza errore dei
        // vecchi documenti, quando la geometria non e' ancora disponibile.
        if (tip < 0) tip = savedTip >= 0 ? savedTip : lastWithoutError;
        body.tipFeatureId = tip >= 0 ? features.at(tip).featureId : 0;
        // Il flag storico del tip registra la visibilita' del corpo anche per
        // i documenti precedenti al formato storyboard e quando un altro
        // corpo lo consuma. Se pero' la coda della storia e' fallita, il flag
        // del vecchio stadio valido era stato spento quando quella feature
        // era ancora il tip: in quel solo caso lo stato del corpo e'
        // autorevole e va conservato.
        const bool failedTail = lastActive >= 0 && lastActive != tip && !features.at(lastActive).error.isEmpty();
        // Lo stesso quando il tip si sposta da solo: una feature fallita che ora
        // riesce (riattivata, o corretta in "Modifica parametri") ha il flag
        // spento, perche' finche' falliva si mostrava lo stadio precedente.
        const bool tipMoved = hadBody && previousTip && tip >= 0 && features.at(tip).featureId != previousTip;
        if ((!hadBody || (!failedTail && !tipMoved)) && tip >= 0) body.visible = features.at(tip).visible;
        for (int index : indices) features[index].visible = index == tip && body.visible;
        bodies.append(body);
        ++number;
    }
    modelBodies = std::move(bodies);
}

void normalizeModelHistory(DocumentState &state) { normalizeModelHistory(state.extrusions, state.modelBodies); }

}
