#ifndef FORGECAD_PATTERN_H
#define FORGECAD_PATTERN_H

#include <QString>
#include <QVector>
#include <vector>

#include "cad_types.h"
#include "fk_math.h"

// Ripetizione dei corpi e delle funzioni (BodyFeature::Pattern, vedi
// PatternParameters): movimenti esatti (traslazioni, rotazioni, simmetrie di
// fk_transform), unione dei solidi e raccolta delle superfici in shell separate.
namespace ForgeCad {

// Le trasformazioni delle istanze oltre all'originale (per lo specchio la
// simmetria), dai riferimenti risolti sulla geometria del corpo `owner`
// (i corpi dei riferimenti hanno indice minore).
bool patternPlacements(const PatternParameters &pattern, int owner, const QVector<SketchObject> &sketches, const QVector<ExtrusionObject> &bodies,
                       std::vector<Kernel::Transform3> &placements, QString *error);

// Il corpo con le sue copie (unione dei solidi, shell separate per le superfici;
// senza l'originale se !keepOriginal).
ForgeBody forgePattern(const ForgeBody &base, const std::vector<Kernel::Transform3> &placements, bool keepOriginal, QString *error);

// Ripetizione della funzione: `target` unito (operation Union) o meno
// (Difference) lo strumento e tutte le sue copie.
ForgeBody forgePatternFeature(const ForgeBody &target, const ForgeBody &tool, BooleanOperation operation,
                              const std::vector<Kernel::Transform3> &placements, QString *error);

// Spostamento del corpo (BodyFeature::Transform, `move`): rotazione attorno
// all'asse risolto, poi traslazione (transformBody: esatto).
ForgeBody forgeMoveBody(const ForgeBody &base, const TransformParameters &move, int owner, const QVector<SketchObject> &sketches,
                        const QVector<ExtrusionObject> &bodies, QString *error);

}

#endif
